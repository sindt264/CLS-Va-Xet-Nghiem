﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ykhoanet.DB.XetNghiem.BLL
{
    public class KetQua
    {
        public string KQ { get; set; }

        public string Value { get; set; }
    }
}
