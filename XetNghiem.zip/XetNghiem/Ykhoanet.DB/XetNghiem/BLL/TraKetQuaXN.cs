﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity;
using System.Data.Objects;
using Ykhoanet.DB.XetNghiem.DAL;
using System.Collections;

namespace Ykhoanet.DB.XetNghiem.BLL
{        
     public static class Group_Lambda
     {  
         public  static bool  In<T>(this T source, params T[] list)
        {
            return list.Contains(source);
        }

         public static IEnumerable<TResult>
        LeftJoin<TSource, TInner, TKey, TResult>(this IEnumerable<TSource> source,
                                         IEnumerable<TInner> inner,
                                         Func<TSource, TKey> pk,
                                         Func<TInner, TKey> fk,
                                         Func<TSource, TInner, TResult> result)
         {
             IEnumerable<TResult> _result = Enumerable.Empty<TResult>();

             _result = from s in source
                       join i in inner
                       on pk(s) equals fk(i) into joinData
                       from left in joinData.DefaultIfEmpty()
                       select result(s, left);

             return _result;
         }
        
    }
    public class TraKetQuaXN
    {


        public CanLamSangEntities dbxn = new CanLamSangEntities();

        public XN_KQ_BenhNhan TaoDong()
        {
            return dbxn.XN_KQ_BenhNhan.Create();
        }

        #region Cac phuong thuc doc dich vu


        public List<XN_DM_XetNghiem> DocDanhSachTenXN(string tukhoa, string manhom)
        {
            return dbxn.XN_DM_XetNghiem.Where(x => x.TenXetNghiem.Contains(tukhoa) && x.XNChinh == true && x.Nhom_XN.Contains(manhom) == true).Take(10).ToList();
        }

        public List<XN_DM_XetNghiem> DocDanhSachTenXNTheoNhomXN(string tukhoa, string manhom)
        {
            return dbxn.XN_DM_XetNghiem.Where(x => x.TenXetNghiem.Contains(tukhoa) && x.Nhom_XN.Contains(manhom)).ToList();
        }

        public XN_KQ_BenhNhan DocThongTin_BN_BP(string mabp)
        {
            return dbxn.XN_KQ_BenhNhan.Where(x => x.MaBP == mabp).FirstOrDefault();
        }

        public List<XN_KQ_XetNghiem> DocDichVuVDaChiDinh(string mabp)
        {
            return dbxn.XN_KQ_XetNghiem.Where(x => x.MaBP == mabp).ToList();//.Select(y => new { y.MaXN,y.TenXetNghiem });
        }

        public XN_KQ_XetNghiem DocTenXetNghiemDaXoa(string mabp, string maxn)
        {
            return dbxn.XN_KQ_XetNghiem.SingleOrDefault(x => x.MaBP == mabp && x.MaXN == maxn);
        }

        public void LuuChiDinhXetNghiem(string mabn, string maba, string mabp, string maxn)
        {
            try
            {
                List<XN_DM_XetNghiem> dsDMXN = null;
                List<XN_KQ_XetNghiem> dsCD = new List<XN_KQ_XetNghiem>();
                XN_KQ_BenhNhan bn = null;

                dsDMXN = dbxn.XN_DM_XetNghiem.Where(x => x.MaXNCha == maxn).OrderBy(x => x.ThuTu).ToList();
                bn = dbxn.XN_KQ_BenhNhan.FirstOrDefault(x => x.MaBP == mabp);

                bool gioitinh = (bool)bn.GioiTinh;

                foreach (var item in dsDMXN)
                {
                    XN_KQ_XetNghiem xn = new XN_KQ_XetNghiem();
                    xn.MaBN = mabn;
                    xn.MaBA = maba;
                    xn.MaBP = mabp;
                    xn.MaXNCha = maxn;
                    xn.MaDV = item.MaDV;
                    xn.MaXN = item.MaXN;
                    xn.TenXetNghiem = item.TenXetNghiem;
                    xn.KetQua = item.KQMacDinh;
                    xn.KetQuaMacDinh = "";
                    xn.DonVi = item.DonVi;
                    if (gioitinh==true)
                    {
                        xn.ChiSoBinhThuong = item.ChiSoBinhThuongNam;
                        xn.GHTren = item.GHTrenNam;
                        xn.GHDuoi = item.GHDuoiNam;
                    }
                    else
                    {
                        xn.ChiSoBinhThuong = item.ChiSoBinhThuongNu;
                        xn.GHTren = item.GHTrenNu;
                        xn.GHDuoi = item.GHDuoiNu;
                    }

                    xn.GHTrenCanhBao = item.GHTrenCanhBao;
                    xn.GHDuoiCanhBao = item.GHDuoiCanhBao;
                    xn.GhiChu = "";
                    xn.XNChinh = item.XNChinh;
                    xn.NguoiIn = "";
                    xn.TGInTraKQ = Convert.ToDateTime("1900-01-01 00:00:00");
                    xn.NguoiDuyet = "";
                    xn.TGDuyet = Convert.ToDateTime("1900-01-01 00:00:00");
                    xn.TGMayXNTraKQ = Convert.ToDateTime("1900-01-01 00:00:00");
                    xn.LayChiDinh = false;
                    xn.InDam = item.InDam;
                    xn.ChonIn = true;
                    xn.LoaiMau = item.LoaiMau;
                    xn.MaXNCha = item.MaXNCha;
                    xn.AD = "";
                    xn.KSTSR = null;
                    xn.SL_HoaChat = item.SL_HoaChat;
                    xn.DVHoaChat = item.DVHoaChat;
                    xn.NhomXN = item.Nhom_XN;
                    xn.ThuTu = item.ThuTu;
                    xn.NhomIn = "";
                    xn.AD_SoiCay = "";
                    xn.AD_SoiDom = "";
                    xn.AD_NCVKLao = "";
                    xn.MauControl = null;
                    xn.TGCapMa = bn.TGCapMa;
                    xn.TGChiDinh = DateTime.Now;
                    xn.SL_HoaChat_TieuHao = 0;
                    xn.MaVK = "";
                    dsCD.Add(xn);
                    //ghichidinhxn(xn, true);
                }
                ghichidinhxn(dsCD, true);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        //public KQ_XetNghiem SuDungDV(string idct)
        //{

        //}

        //public KQ_XetNghiem HuyDV(string idct)
        //{

        //}

        public XN_KQ_BenhNhan LayThongTinBenhNhanCM(string mabp)
        {
            return dbxn.XN_KQ_BenhNhan.FirstOrDefault(x => x.MaBP == mabp);
        }

        public View_XN_KQ_BenhNhan_MCD LayThongTinBenhNhanCD_CM(string macd)
        {
            return dbxn.View_XN_KQ_BenhNhan_MCD.FirstOrDefault(x => x.MaCD.Trim() == macd.Trim());
        }

        public sp_XN_LayThongTinBNDSCho_Result LayThongTinBenhNhanChoCM(string macd,string chuoimakhoa)
        {
            try
            {
                var a = dbxn.sp_XN_LayThongTinBNDSCho(macd, chuoimakhoa).FirstOrDefault();
                return a;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        //mabn: 12345678//maba: 14212/15//mabp: 151104-123
        public List<XN_KQ_XetNghiem> LoadChiDinhXetNghiem(string mabn, string maba, string mabp, int page, int sodong)
        {
            try
            {
                List<XN_KQ_XetNghiem> ds = dbxn.XN_KQ_XetNghiem.Where(x => x.MaBP == mabp && x.XNChinh == true).OrderBy(x => x.TGChiDinh).Skip((page - 1) * sodong).Take(sodong).ToList();
                return ds;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


        public List<XN_KQ_XetNghiem> LoadChiDinhXetNghiem_CM(string mabn, string maba, string macd, int page, int sodong)
        {
            try
            {
                List<XN_KQ_XetNghiem> ds = dbxn.XN_KQ_XetNghiem.Where(x => x.MaChiDinh == macd && x.XNChinh == true).OrderBy(x => x.TGChiDinh).Skip((page - 1) * sodong).Take(sodong).ToList();
                return ds;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<sp_XN_GomCacDVChiDinh_Result> LoadChiDinhXetNghiemBNCho(string mabn, string maba, string macd, string chuoimakhoa,string idcoso, int page, int sodong)
        {
            try
            {
                List<sp_XN_GomCacDVChiDinh_Result> ds = dbxn.sp_XN_GomCacDVChiDinh(macd, chuoimakhoa, idcoso).Skip((page - 1) * sodong).Take(sodong).ToList();
                return ds;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }



        public List<sp_XN_kqxn_HienThiDSTraKQXN_Result> LoadDanhSachBenhNhanCM(string mabn, string macap, string hoten, string chuoimakhoa, string idcoso, DateTime tungay, DateTime denngay, int page, int sodong)
        {
            var ds = dbxn.sp_XN_kqxn_HienThiDSTraKQXN(mabn, macap, hoten, chuoimakhoa, idcoso, tungay, denngay).Skip((page - 1) * sodong).Take(sodong).ToList();
            return ds;
            //.OrderByDescending(x => x.MaChiDinh).Skip((page - 1) * sodong).Take(sodong).ToList();
        }


        public List<sp_XN_kqxn_HienThiDSTraKQXN_ALL_Result> LoadDanhSachBenhNhanCMAll(string mabn, string macap, string hoten, string chuoimakhoa, string idcoso, DateTime tungay, DateTime denngay, int page, int sodong)
        {
            var ds = dbxn.sp_XN_kqxn_HienThiDSTraKQXN_ALL(mabn, macap, hoten, chuoimakhoa, idcoso, tungay, denngay).Skip((page - 1) * sodong).Take(sodong).ToList();
            return ds;
            //.OrderByDescending(x => x.MaChiDinh).Skip((page - 1) * sodong).Take(sodong).ToList();
        }

        public List<sp_XN_HienThiCapMaBN_TN_Result> LoadDanhSachBenhNhanCM_TN(string macd, string macap, string hoten, DateTime tungay, DateTime denngay, int page, int sodong)
        {
            var ds = dbxn.sp_XN_HienThiCapMaBN_TN(macd, macap, hoten, tungay, denngay).OrderByDescending(x => x.MaChiDinh).Skip((page - 1) * sodong).Take(sodong).ToList();
            return ds;
            //.OrderByDescending(x => x.MaChiDinh).Skip((page - 1) * sodong).Take(sodong).ToList();

        }

        public List<sp_XN_HienThiDSChoBN_Result> LoadDanhSachBenhNhanCho(string macd, string mabn, string hoten,string chuoimakhoa, string idcoso, DateTime tungay, DateTime denngay, int page, int sodong)
        {
            //try
            //{
            //}
            //catch (Exception)
            //{
            //    //throw new ;
            //}

            var ds = dbxn.sp_XN_HienThiDSChoBN(macd, mabn, hoten, chuoimakhoa, idcoso, tungay, denngay).OrderByDescending(x => x.MaChiDinh).Skip((page - 1) * sodong).Take(sodong).ToList();
            return ds;
            //.OrderByDescending(x => x.MaChiDinh).Skip((page - 1) * sodong).Take(sodong).ToList();

        }

        //public List<KQ_BenhNhan> LayMaChiDinhDauTrang(string macd, string macap, string hoten, DateTime tungay, DateTime denngay, int sotrang, int sodong)
        //{

        //    try
        //    {
        //        int sodongtrangcuoi = dbxn.KQ_BenhNhan.Where(x => x.TGCapMa >= tungay
        //                            && x.TGCapMa <= denngay
        //                            && x.MaChiDinh.Contains(macd) == true
        //                            && x.MaCap.Contains(macap) == true
        //                            && x.HoTen.Contains(hoten) == true).OrderByDescending(x => x.MaChiDinh).Skip((sotrang - 1) * sodong).Take(sodong).Count();
        //        List<KQ_BenhNhan> dsbn = new List<KQ_BenhNhan>();
        //        for (int i = 1; i <= sotrang; i++)
        //        {
        //            List<KQ_BenhNhan> sobn = null;
        //            if (i<sotrang)
        //            {
        //                sobn = dbxn.KQ_BenhNhan.Where(x => x.TGCapMa >= tungay
        //                        && x.TGCapMa <= denngay
        //                        && x.MaChiDinh.Contains(macd) == true
        //                        && x.MaCap.Contains(macap) == true
        //                        && x.HoTen.Contains(hoten) == true).OrderByDescending(x => x.MaChiDinh).Skip((i - 1) * sodong).Take(1).ToList();
        //                dsbn.AddRange(sobn);
        //                sobn = dbxn.KQ_BenhNhan.Where(x => x.TGCapMa >= tungay
        //                        && x.TGCapMa <= denngay
        //                        && x.MaChiDinh.Contains(macd) == true
        //                        && x.MaCap.Contains(macap) == true
        //                        && x.HoTen.Contains(hoten) == true).OrderByDescending(x => x.MaChiDinh).Skip(((i - 1) * sodong) + 24).Take(1).ToList();
        //                dsbn.AddRange(sobn);
        //            }
        //            else if (i==sotrang)
        //            {
        //                sobn = dbxn.KQ_BenhNhan.Where(x => x.TGCapMa >= tungay
        //                        && x.TGCapMa <= denngay
        //                        && x.MaChiDinh.Contains(macd) == true
        //                        && x.MaCap.Contains(macap) == true
        //                        && x.HoTen.Contains(hoten) == true).OrderByDescending(x => x.MaChiDinh).Skip((i - 1) * sodong).Take(1).ToList();
        //                dsbn.AddRange(sobn);
        //                sobn = dbxn.KQ_BenhNhan.Where(x => x.TGCapMa >= tungay
        //                        && x.TGCapMa <= denngay
        //                        && x.MaChiDinh.Contains(macd) == true
        //                        && x.MaCap.Contains(macap) == true
        //                        && x.HoTen.Contains(hoten) == true).OrderByDescending(x => x.MaChiDinh).Skip(((i - 1) * sodong) + sodongtrangcuoi - 1).Take(1).ToList();
        //                dsbn.AddRange(sobn);
        //            }
        //        }
        //        return dsbn;
        //    }
        //    catch (Exception ex)
        //    {

        //        return null;
        //    }

        //}

        #endregion

        #region Cac phuong thuc them - xoa - sua du lieu
        public void ghi()
        {
            dbxn.SaveChanges();

        }

        public bool ktthongtinbn(string mabp)
        {
            int kt = 0;
            kt = dbxn.XN_KQ_BenhNhan.Where(x => x.MaBP == mabp).Count();
            if (kt > 0)
                return true;
            return false;
        }

        public void themthongtinbn(XN_KQ_BenhNhan bn, bool ghi = true)
        {
            dbxn.XN_KQ_BenhNhan.Add(bn);
            if (ghi)
            {
                dbxn.SaveChanges();
            }
        }
        public void suathongtinbn(XN_KQ_BenhNhan bn, bool sua = true)
        {
            if (sua)
            {
                dbxn.Entry(bn).State = EntityState.Modified;
                dbxn.SaveChanges();
            }
        }

        public void ghichidinhxn(List<XN_KQ_XetNghiem> kqxn, bool ghi = true)
        {
            dbxn.XN_KQ_XetNghiem.AddRange(kqxn);
            if (ghi)
            {
                //dbxn.Entry(kqxn).State=EntityState.Added;    
                dbxn.SaveChanges();
            }
        }
        public void xoachidinhxn(string _mabp, string _maxn)
        {
            List<XN_KQ_XetNghiem> dskq = dbxn.XN_KQ_XetNghiem.Where(x => x.MaBP == _mabp && x.MaXNCha == _maxn).ToList();
            if (dskq == null)
                return;

            dbxn.XN_KQ_XetNghiem.RemoveRange(dskq);

            //if (dskq.Count()==1)
            //{
            //    XN_KQ_BenhNhan bn = dbxn.XN_KQ_BenhNhan.Where(x => x.MaBP == _mabp).FirstOrDefault();
            //    dbxn.XN_KQ_BenhNhan.Remove(bn);
            //}

            dbxn.SaveChanges();

        }

        public string suachidinhdv(string idct, string chon)
        {
            //int _idct = Convert.ToInt32(idct.Trim());
            //View_XN_DS_ChoCLS kq = dbxn.View_XN_DS_ChoCLS.Where(x => x.IDCT == _idct).FirstOrDefault();
            //ChiTiet_VienPhi vp = dbxn.ChiTiet_VienPhi.Where(x => x.IDCT == _idct).FirstOrDefault();
            //if (kq == null)
            //    return "err";
            //if (chon == "huy")
            //{
            //    if (vp.Huy == true)
            //    {
            //        return "errvp";
            //    }
            //    else
            //    {
            //        kq.SuDung = false;
            //        kq.Huy = true;
            //        dbxn.Entry(kq).State = EntityState.Modified;
            //        dbxn.SaveChanges();
            //        return "ok";
            //    }

            //}
            //else
            //{
            //    if (vp.Huy == true)
            //    {
            //        return "errvp";
            //    }
            //    else
            //    {
            //        kq.SuDung = false;
            //        kq.Huy = false;
            //        dbxn.Entry(kq).State = EntityState.Modified;
            //        dbxn.SaveChanges();
            //        return "ok";
            //    }
            //}

            //dbxn.Entry(kq).State = EntityState.Modified;
            return "err";
        }

        public bool kiemtrachonks(string mavk)
        {
            IEnumerable<XN_DM_ChiTiet_ViKhuan> ctvk = dbxn.XN_DM_ChiTiet_ViKhuan.Where(x => x.MaVK == mavk);
            if (ctvk != null)
            {
                return true;
            }
            return false;
        }

        public void ghichidinhks(XN_KQ_KhangSinh kqks, bool ghi = true)
        {
            if (!kiemtrachonks(kqks.MaVK))
                return;
            dbxn.XN_KQ_KhangSinh.Add(kqks);
            if (ghi)
            {
                dbxn.SaveChanges();
            }
        }

        public void xoamacapbn_theoCD(string _mabp, string _macd)
        {
            List<XN_KQ_CapMa> dscm = dbxn.XN_KQ_CapMa.Where(x => x.MaChiDinh == _macd).ToList();
            List<XN_KQ_XetNghiem> dsxn = dbxn.XN_KQ_XetNghiem.Where(x => x.MaChiDinh == _macd).ToList();
            List<XN_KQ_BenhNhan> dskq = dbxn.XN_KQ_BenhNhan.Where(x => x.MaBP == _mabp).ToList();
            if (dskq == null)
            {
                return;
            }
            else if (dscm == null)
            {
                return;
            }
            else if (dskq == null)
            {
                return;
            }

            int dem = dbxn.XN_KQ_CapMa.Where(x => x.MaBP == _mabp).Count();
            if (dem > 1)
            {
                dbxn.XN_KQ_CapMa.RemoveRange(dscm);
                dbxn.XN_KQ_XetNghiem.RemoveRange(dsxn);
            }
            else if (dem == 1)
            {
                dbxn.XN_KQ_BenhNhan.RemoveRange(dskq);
            }

            dbxn.SaveChanges();

        }

        public void xoamacapbn(string _mabp)
        {
            List<XN_KQ_BenhNhan> dskq = dbxn.XN_KQ_BenhNhan.Where(x => x.MaBP == _mabp).ToList();
            if (dskq == null)
                return;
            dbxn.XN_KQ_BenhNhan.RemoveRange(dskq);
            dbxn.SaveChanges();

        }

        #endregion

    }
}
