﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data.Entity;
using System.Data.Objects;
using Ykhoanet.DB.XetNghiem.DAL;
using System.Collections;

namespace Ykhoanet.DB.XetNghiem.BLL
{
    public class ThongTinCapMaBN
    {
        private CanLamSangEntities dbxn = new CanLamSangEntities();
        
        #region Cac phuong thuc doc du lieu
        public List<DS_ChoCLS> DocDichVuTheoMaCD(string _machidinh)
        {
            var makhoa = dbxn.XN_DM_NhomXN.Select(x=>new {x.MaNhom}).ToList();
            return dbxn.DS_ChoCLS.Where(x => x.MaChiDinh == _machidinh && x.Huy.ToString() == "0" && x.SuDung.ToString() == "0" && makhoa.Select(c => c.MaNhom).Contains(x.ChuyenKhoa)).ToList();
        }

        public List<sp_XN_DSBNChoXN_Result> DocDanhSachBNCho(DateTime tungay, DateTime denngay)
        {
            return dbxn.sp_XN_DSBNChoXN(tungay,denngay).ToList();
        }

        public List<sp_XN_ThongTinBN_Result> DocThongTinBNTheoMaCD(string _machidinh)
        {
            return dbxn.sp_XN_ThongTinBN(_machidinh).ToList();
        }

        public XN_KQ_BenhNhan TimThongTinBNTheoMaCap(string _mabp)
        {
            return dbxn.XN_KQ_BenhNhan.Where(x => x.MaCap == _mabp).FirstOrDefault();
        }

        public List<XN_KQ_XetNghiem> TimThongTinDVTheoMaCap(string _mabp)
        {
            return dbxn.XN_KQ_XetNghiem.Where(x => x.MaBP == _mabp).ToList();
        }

        #endregion

        #region Cac phuong thuc them - xoa - sua du lieu
        public void ghi()
        {
            dbxn.SaveChanges();
        }
        public void themthongtinbn(XN_KQ_BenhNhan bn, bool ghi = true)
        {
            dbxn.XN_KQ_BenhNhan.Add(bn);
            if (ghi)
            {
                dbxn.SaveChanges();
            }
        }
        public void suathongtinbn(XN_KQ_BenhNhan bn, bool sua = true)
        {
            if (sua)
            {
                dbxn.Entry(bn).State = EntityState.Modified;
                dbxn.SaveChanges();
            }
        }
        public void ghichidinhxn(XN_KQ_XetNghiem kqxn, bool ghi = true)
        {
            dbxn.XN_KQ_XetNghiem.Add(kqxn);
            if (ghi)
            {
                dbxn.SaveChanges();
            }
        }

        public bool kiemtrachonks(string mavk)
        {
            IEnumerable<XN_DM_ChiTiet_ViKhuan> ctvk = dbxn.XN_DM_ChiTiet_ViKhuan.Where(x => x.MaVK == mavk);
            if (ctvk != null)
            {
                return true;
            }
            return false;
        }

        public void themchidinhks(XN_KQ_KhangSinh kqks, bool ghi = true)
        {
            if (!kiemtrachonks(kqks.MaVK))
                return;
            dbxn.XN_KQ_KhangSinh.Add(kqks);
            if (ghi)
            {
                dbxn.SaveChanges();
            }
        }

        public void xoachidinhdv(string _mabp, string _maxn)
        {
            XN_KQ_XetNghiem kq = dbxn.XN_KQ_XetNghiem.Where(x => x.MaBP == _mabp && x.MaXN == _maxn).FirstOrDefault();
            if (kq == null)
                return;
            dbxn.XN_KQ_XetNghiem.Remove(kq);
            dbxn.Entry(kq).State = EntityState.Deleted;
            dbxn.SaveChanges();
           
        }

        #endregion
    }
}
