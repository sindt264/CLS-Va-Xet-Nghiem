﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity;
using System.Data.Objects;
using Ykhoanet.DB.XetNghiem.DAL;
using System.Collections;
namespace Ykhoanet.DB.XetNghiem.BLL
{
    public class DangNhap
    {
        private CanLamSangEntities dbxn = new CanLamSangEntities();

        public View_XN_NguoiDung kiemtranguoidung(string _mand, string _matkhau)
        {
            return dbxn.View_XN_NguoiDung.Where(x => x.MaNV == _mand && x.MatKhau == _matkhau).FirstOrDefault();
        }
    }
}
