﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ykhoanet.DB.Common
{
    public static class Utilities
    {





        /// <summary>
        /// Hàm chuyển object sang chuỗi nếu null trả về chuỗi rỗng
        /// </summary>
        public static string ObjectToString(object value)
        {
            if (value == null || value == DBNull.Value)
            {
                return "";
            }
            return Convert.ToString(value);
        }

        public static string DataTableToJson(DataTable dt)
        {
            DataSet ds = new DataSet();
            ds.Merge(dt);
            System.Text.StringBuilder JsonStr = new System.Text.StringBuilder();
            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                JsonStr.Append("[");
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    JsonStr.Append("{");
                    for (int j = 0; j < ds.Tables[0].Columns.Count; j++)
                    {
                        if (j < ds.Tables[0].Columns.Count - 1)
                        {
                            JsonStr.Append("\"" + ds.Tables[0].Columns[j].ColumnName.ToString() + "\":" + "\"" + ds.Tables[0].Rows[i][j].ToString() + "\",");
                        }
                        else if (j == ds.Tables[0].Columns.Count - 1)
                        {
                            JsonStr.Append("\"" + ds.Tables[0].Columns[j].ColumnName.ToString() + "\":" + "\"" + ds.Tables[0].Rows[i][j].ToString() + "\"");
                        }
                    }
                    if (i == ds.Tables[0].Rows.Count - 1)
                    {
                        JsonStr.Append("}");
                    }
                    else
                    {
                        JsonStr.Append("},");
                    }
                }
                JsonStr.Append("]");
                return JsonStr.ToString();
            }
            else
            {
                return null;
            }
        }  


    }
}
