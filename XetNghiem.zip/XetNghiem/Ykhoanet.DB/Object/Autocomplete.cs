﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ykhoanet.DB.Object
{
    public class Autocomplete
    {
        public string ID { get; set; }

        public string Value { get; set; }
    }
}
