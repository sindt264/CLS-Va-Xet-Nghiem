﻿using System;
using System.Text;
using System.Data.SqlClient;
using System.Collections;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for clsDBTransaction
/// </summary>
public class clsDBTransaction
{
    ArrayList arParameters;
    /// <summary>
    /// 
    /// </summary>
    string strQuery;
    string connectionString = "";

    public enum eConnectionString
    {
        Conn
    };

    public string StrQuery
    {
        get { return strQuery; }
        set { strQuery = value; }
    }
    public static string getStringConnect(eConnectionString intConn)
    {
        switch (intConn)
        {
            case eConnectionString.Conn:
                return ConfigurationManager.AppSettings["Conn"].ToString();
        }
        return "";
    }
    public clsDBTransaction()
    {
        arParameters = new ArrayList();
    }
    public clsDBTransaction(eConnectionString intConn)
    {
        arParameters = new ArrayList();
        switch (intConn)
        {
            case eConnectionString.Conn:
                connectionString = ConfigurationManager.AppSettings["Conn"].ToString();
                break;
        }
    }

    /// <summary>
    /// Uses the Eclips connection string
    /// </summary>
    /// <param name="spName">Name of the stored procedure to be executed</param>
    public clsDBTransaction(string spName)
    {
        arParameters = new ArrayList();
        this.StrQuery = spName;
        //connectionString = GetConnectionString();
    }
    /// <summary>
    /// Uses a custom connection string
    /// </summary>
    /// <param name="spName">Name of the stored procedure to be executed</param>
    /// <param name="strConnectionString">Connection string to the database</param>
    public clsDBTransaction(string spName, string strConnectionString)
    {
        arParameters = new ArrayList();
        this.StrQuery = spName;
        connectionString = strConnectionString;
    }



    /// <summary>
    /// Create parameters to put in the stored procedure
    /// </summary>
    /// <param name="ParamType">Ex: Varchar, int , DateTime</param>
    /// <param name="ParamName">Name of the parameter (Without '@' sign)</param>
    /// <param name="ParamValue">Value of the parameter</param>
    public void AddParam(SqlDbType ParamType, string ParamName, object ParamValue)
    {
        SqlParameter prm = new SqlParameter("@" + ParamName, ParamType);
        prm.Value = ParamValue;
        arParameters.Add(prm);
    }

    /// <summary>
    /// Execute stored procedures with multiple parameters
    /// </summary>
    /// <param name="spName">Name of the stored procedure</param>
    /// <param name="parameters">Pass parameters in an ArrayList</param>
    public string ExecuteStoreProcedure(CommandType type = CommandType.StoredProcedure)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            SqlCommand cmd;
            try
            {
                conn.Open();
                cmd = new SqlCommand(StrQuery, conn);
                cmd.CommandType = type;
                cmd.CommandTimeout = 0;
                if (arParameters != null)
                {
                    foreach (SqlParameter pr in arParameters)
                        cmd.Parameters.Add(pr);
                }
                var ret = cmd.ExecuteNonQuery().ToString();
                conn.Close();
                return ret;
            }
            catch (Exception ex)
            {
                return string.Format(ex.Message);
            }
        }
    }
    /// <summary>
    /// Execute stored procedures with multiple parameters
    /// </summary>
    /// <returns>Returns a dataset</returns>
    public DataSet ExecuteProReader(CommandType type = CommandType.StoredProcedure)
    {
        DataSet dsReturnedValue = new DataSet();
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            SqlCommand cmd;
            conn.Open();
            cmd = new SqlCommand(StrQuery, conn);
            cmd.CommandType = type;
            cmd.CommandTimeout = 0;

            if (arParameters != null)
            {
                foreach (SqlParameter pr in arParameters)
                    cmd.Parameters.Add(pr);
            }
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dsReturnedValue);
            conn.Close();
        }
        return dsReturnedValue;
    }

    /// <summary>
    /// Execute stored procedures with multiple parameters
    /// </summary>
    /// <returns>Returns a DataTable</returns>
    public DataTable ExecuteProDataTable(CommandType type = CommandType.StoredProcedure)
    {
        DataTable dsReturnedValue = new DataTable();
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            try
            {
                SqlCommand cmd;
                conn.Open();
                cmd = new SqlCommand(StrQuery, conn);
                cmd.CommandType = type;
                cmd.CommandTimeout = 0;

                if (arParameters != null)
                {
                    foreach (SqlParameter pr in arParameters)
                        cmd.Parameters.Add(pr);
                }
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dsReturnedValue);
                conn.Close();
            }
            catch (Exception ex)
            {
                DataTable db = new DataTable();
                db.Columns.Add(new DataColumn("status"));
                db.Rows.Add(ex.Message);
                return db;
            }
        }
        return dsReturnedValue;
    }
    /// <summary>
    /// Execute stored procedures with multiple parameters
    /// </summary>
    /// <returns>Returns a Json</returns>
    public string ExecuteProJson()
    {
        DataTable dsReturnedValue = new DataTable();
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            SqlCommand cmd;
            conn.Open();
            cmd = new SqlCommand(StrQuery, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 0;

            if (arParameters != null)
            {
                foreach (SqlParameter pr in arParameters)
                    cmd.Parameters.Add(pr);
            }
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dsReturnedValue);
            conn.Close();
        }
        return clsDBTransaction.DataTableToJson(dsReturnedValue);
    }

    /// Execute stored procedures with multiple parameters
    /// </summary>
    /// <returns>Returns a Json</returns>
    public string ExecuteQueryStringJson(CommandType type = CommandType.Text)
    {
        DataTable dsReturnedValue = new DataTable();
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            SqlCommand cmd;
            cmd = new SqlCommand(this.StrQuery, conn);
            cmd.CommandType = type;
            cmd.CommandTimeout = 0;
            if (arParameters != null)
            {
                foreach (SqlParameter pr in arParameters)
                    cmd.Parameters.Add(pr);
            }
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dsReturnedValue);
        }
        return clsDBTransaction.DataTableToJson(dsReturnedValue);
    }

    public DataTable ExecuteQueryStringDatatable(CommandType type = CommandType.Text)
    {
        DataTable dsReturnedValue = new DataTable();
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            SqlCommand cmd;
            cmd = new SqlCommand(this.StrQuery, conn);
            cmd.CommandType = type;
            cmd.CommandTimeout = 0;
            if (arParameters != null)
            {
                foreach (SqlParameter pr in arParameters)
                    cmd.Parameters.Add(pr);
            }
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dsReturnedValue);
        }
        return dsReturnedValue;
    }
    public string ExecuteQueryString(CommandType type = CommandType.Text)
    {
        DataTable dsReturnedValue = new DataTable();
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd;
                cmd = new SqlCommand(this.StrQuery, conn);
                cmd.CommandType = type;
                cmd.CommandTimeout = 0;
                if (arParameters != null)
                {
                    foreach (SqlParameter pr in arParameters)
                        cmd.Parameters.Add(pr);
                }
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dsReturnedValue);
                return (string)dsReturnedValue.Rows[0][0];
            }
        }
        catch
        {

            return "";
        }
    }
    /// <summary>
    /// Insert update
    /// </summary>
    public Int32 ExecuteScalar(string strQuery)
    {
        try
        {

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                DataTable dTable = new DataTable();
                if (conn.State != ConnectionState.Open) conn.Open();
                SqlCommand command = new SqlCommand(strQuery, conn);
                command.CommandType = CommandType.Text;
                return (Int32)command.ExecuteScalar();
            }

        }
        catch (Exception)
        {
            return 0;
        }
    }

    public int ExecuteNonQuery(CommandType type = CommandType.Text)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            if (conn.State != ConnectionState.Open) conn.Open();
            SqlCommand cmd;
            cmd = new SqlCommand(this.StrQuery, conn);
            cmd.CommandType = type;
            cmd.CommandTimeout = 0;
            return cmd.ExecuteNonQuery();
        }
    }
    #region My Function

    public string GetDateSQL(string _dateString)
    {
        var _date = _dateString.Split('/');
        return string.Format("{0}-{1}-{2}", _date[2], _date[1], _date[0]);
    }
    public string GetDateSQL(DateTime _date)
    {
        return string.Format("{0}-{1}-{2}", _date.Year, _date.Month, _date.Day);
    }

    public static string DataTableToJson(DataTable dt)
    {
        DataSet ds = new DataSet();
        ds.Merge(dt);
        System.Text.StringBuilder JsonStr = new System.Text.StringBuilder();
        if (ds != null && ds.Tables[0].Rows.Count > 0)
        {
            JsonStr.Append("[");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                JsonStr.Append("{");
                for (int j = 0; j < ds.Tables[0].Columns.Count; j++)
                {
                    if (j < ds.Tables[0].Columns.Count - 1)
                    {
                        JsonStr.Append("\"" + ds.Tables[0].Columns[j].ColumnName.ToString() + "\":" + "\"" + ds.Tables[0].Rows[i][j].ToString() + "\",");
                    }
                    else if (j == ds.Tables[0].Columns.Count - 1)
                    {
                        JsonStr.Append("\"" + ds.Tables[0].Columns[j].ColumnName.ToString() + "\":" + "\"" + ds.Tables[0].Rows[i][j].ToString() + "\"");
                    }
                }
                if (i == ds.Tables[0].Rows.Count - 1)
                {
                    JsonStr.Append("}");
                }
                else
                {
                    JsonStr.Append("},");
                }
            }
            JsonStr.Append("]");
            return JsonStr.ToString();
        }
        else
        {
            return "[]";
        }
    }

    #endregion
}