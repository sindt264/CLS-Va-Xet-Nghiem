﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Ykhoanet.DB.XetNghiem.DAL;

namespace Ykhoanet.BaoCao.YkhoaNet
{
    public partial class TongSoXNThucHienTheoNhom : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}