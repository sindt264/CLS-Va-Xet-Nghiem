﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;

namespace Ykhoanet
{
    public class CulturePage : System.Web.UI.Page
    {
        public CulturePage() { }
        protected override void InitializeCulture()
        {
            string lang = String.Empty;
            HttpCookie cookie = Request.Cookies["CurrentLanguage"];
            if (cookie != null && cookie.Value != null)
            {
                lang = cookie.Value;
            }
            else
            {
                lang = "vi-VN";
                HttpCookie cookie_new = new HttpCookie("CurrentLanguage");
                cookie_new.Value = lang;
                cookie_new.Expires = DateTime.Now.AddMonths(6);
                Response.SetCookie(cookie_new);
            }

            CultureInfo Cul = CultureInfo.CreateSpecificCulture(lang);
            System.Threading.Thread.CurrentThread.CurrentUICulture = Cul;
            System.Threading.Thread.CurrentThread.CurrentCulture = Cul;

            base.InitializeCulture();
        }

        public static string GetResource(HttpContext context, string filename, string key)
        {
            HttpCookie cookie = context.Request.Cookies["CurrentLanguage"];
            CultureInfo culture = CultureInfo.CreateSpecificCulture(cookie.Value);
            object keyValue = HttpContext.GetLocalResourceObject(filename, key, culture);
            return keyValue.ToString();
        }
    }
}
