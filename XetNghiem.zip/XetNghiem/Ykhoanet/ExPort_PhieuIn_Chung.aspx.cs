﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ykhoanet
{
    public partial class ExPort_PhieuIn_Chung : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Response.Clear();
            //Response.Buffer = true;
            //Response.AddHeader("content-disposition", "attachment;filename=YKHOANET_KSK_" + DateTime.Now.ToString("dd-MM-yyyy_HH-mm-ss") + ".xls");
            //Response.ContentType = "application/vnd.ms-excel";
            //Response.Charset = "";
            //Response.ContentEncoding = System.Text.Encoding.Unicode;
            //Response.BinaryWrite(System.Text.Encoding.Unicode.GetPreamble());
            //StringWriter oStringWriter = new StringWriter();
            //HtmlTextWriter oHtmlTextWriter = new HtmlTextWriter(oStringWriter);
            //baocao_content.RenderControl(oHtmlTextWriter);
            ////Response.Write(oStringWriter.ToString());
            //Response.Output.Write(oStringWriter.ToString());
            //Response.Flush();
            //Response.End();
        }
    }
}