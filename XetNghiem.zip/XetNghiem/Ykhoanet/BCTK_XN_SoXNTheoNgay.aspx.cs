﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using Ykhoanet.DB.XetNghiem.DAL;

namespace Ykhoanet
{
    public partial class BCTK_XN_SoXNTheoNgay : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string _loaitg = Request.QueryString["loaitg"].ToString();
            //string _tungay = Request.QueryString["tungay"].ToString();
            //string _denngay = Request.QueryString["denngay"].ToString();
            //DateTime tungay = Convert.ToDateTime(_tungay);
            //DateTime denngay = Convert.ToDateTime(_denngay);
            //string _ngin = Request.QueryString["nguoiin"].ToString();
            //string chuoimakhoa = Request.Cookies["chuoimakhoa"].Value;
            //CanLamSangEntities dbxn = new CanLamSangEntities();
            //var dstk = dbxn.sp_XN_TK_TongXN_TheoNgay(tungay, denngay, chuoimakhoa).ToList();
        }
    }
}