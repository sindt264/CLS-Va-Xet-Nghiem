﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Script.Serialization;
using Ykhoanet.DB.XetNghiem.DAL;
using Ykhoanet.DB.XetNghiem.BLL;

using System.Data.Entity;
using System.Collections;
using System.Data.Entity.Validation;

namespace Ykhoanet.Handler._6_XetNghiem
{
    public class CapMaBN : IHttpHandler
    {

        public CanLamSangEntities dbxn = new CanLamSangEntities();

        public ThongTinTiepNhanBN ttbn = new ThongTinTiepNhanBN();

        public void ProcessRequest(HttpContext context)
        {
            string loai = context.Request.QueryString["loai"];
            string l = context.Request.QueryString["ten"];
            string str = "";

            if (String.IsNullOrEmpty(context.Request.QueryString["loai"]))
            {
                loai = "";
            }

            if (loai.Equals("capmabn"))
            {
                string machidinh = context.Request.QueryString["machidinh"];
                string macap = context.Request.QueryString["macap"];
                string mabn = context.Request.QueryString["mabn"];
                string maba = context.Request.QueryString["maba"];
                string hoten = context.Request.QueryString["hoten"];
                bool gioitinh = (context.Request.QueryString["gioitinh"].Trim() == "1" ? true : false);
                int tuoi = Convert.ToInt32(context.Request.QueryString["tuoi"]);
                string namsinh = context.Request.QueryString["namsinh"];
                DateTime tgiancd = Convert.ToDateTime(string.Format("{0:yyyy-MM-dd HH:mm:ss}", context.Request.QueryString["ngaycd"]));
                string khoacd = context.Request.QueryString["khoacd"];
                string nguoicd = context.Request.QueryString["nguoicd"];
                string diachi = context.Request.QueryString["diachi"];
                string sobhyt = context.Request.QueryString["sobhyt"];
                string hanbhyt = context.Request.QueryString["hanbhyt"];
                string chandoan = context.Request.QueryString["chandoan"];
                string doituong = context.Request.QueryString["doituong"];
                bool capcuu = (context.Request.QueryString["capcuu"].Trim() == "1" ? true : false);

                string noilaymau = context.Request.QueryString["noilaymau"];
                string macapxn = context.Request.QueryString["macapxn"];
                string mabp = context.Request.QueryString["mabp"];
                string nguoicm = context.Request.QueryString["nguoicm"];
                DateTime tgiancm = Convert.ToDateTime(string.Format("{0:yyyy-MM-dd HH:mm:ss}", context.Request.QueryString["ngaycm"]));
                string nguoiduyet = context.Request.QueryString["nguoiduyet"];
                DateTime tgianduyet = Convert.ToDateTime(string.Format("{0:yyyy-MM-dd HH:mm:ss}", context.Request.QueryString["ngayduyet"]));

                str = CapMaBenhNhan(machidinh, macap, mabn, maba, hoten, gioitinh, tuoi, namsinh, tgiancd, khoacd, nguoicd, diachi, sobhyt, hanbhyt, chandoan, doituong, capcuu, noilaymau, macapxn, mabp, nguoicm, tgiancm, nguoiduyet, tgianduyet);

            }
            else if (loai.Equals("capmabn_dl_all"))
            {
                string _chuoicd = context.Request.QueryString["chuoicd"];
                string _chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                string _ngcapma = context.Request.QueryString["ngcapma"];
                str = CapMaBenhNhan_DL(_chuoicd, _chuoimakhoa, _ngcapma);
            }
            else if (loai.Equals("capmabn_tuychon"))
            {
                string _chuoi_idct = context.Request.QueryString["chuoi_idct"];
                string _chuoimacap_macd = context.Request.QueryString["chuoimacap_macd"];
                string _ngcapma = context.Request.QueryString["ngcapma"];
                string _chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                str = CapMaBenhNhan_TuyChon(_chuoi_idct, _chuoimacap_macd, _ngcapma, _chuoimakhoa);
            }
            else if (loai.Equals("gomcapmabn_tuychon"))
            {
                string _chuoi_idct = context.Request.QueryString["chuoi_idct"];
                string _chuoimacap_macd = context.Request.QueryString["chuoimacap_macd"];
                string _ngcapma = context.Request.QueryString["ngcapma"];
                string _chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                //string _idcoso = context.Request.QueryString["idcoso"];
                str = GomCapMaBenhNhan_TuyChon(_chuoi_idct, _chuoimacap_macd, _ngcapma, _chuoimakhoa);
            }
            else if (loai.Equals("tenxn"))
            {
                string keyword = context.Request.QueryString["keyword"];
                string manhom = context.Request.QueryString["manhom"];
                str = LoadDanhSachXetNghiem(keyword, manhom);
            }
            else if (loai.Equals("luucdxn"))
            {
                string mabn = context.Request.QueryString["mabn"];
                string maba = context.Request.QueryString["maba"];
                string mabp = context.Request.QueryString["mabp"];
                string maxn = context.Request.QueryString["maxn"];
                str = LuuChiDinhXetNghiem(mabn, maba, mabp, maxn);
            }

            else if (loai.Equals("thongtinbncm"))
            {
                string mabp = context.Request.QueryString["mabp"];
                string macd = context.Request.QueryString["macd"];
                str = LayThongTinBenhNhanCapMa(mabp, macd);
            }

            else if (loai.Equals("thongtinbncho"))
            {
                string macd = context.Request.QueryString["macd"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                str = LayThongTinBenhNhanCho(macd, chuoimakhoa);
            }
            else if (loai.Equals("loadcdxn"))
            {
                string mabp = context.Request.QueryString["mabp"];
                string macd = context.Request.QueryString["macd"];
                int page = Convert.ToInt32(context.Request.QueryString["page"]);
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
                str = LoadChiDinhXetNghiem(mabp, macd, page, sodong);
            }

            else if (loai.Equals("loadcdxn_cd"))
            {
                string macd = context.Request.QueryString["macd"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                string idcoso = context.Request.QueryString["idcoso"];
                int page = Convert.ToInt32(context.Request.QueryString["page"]);
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
                str = LoadChiDinhXetNghiemBNCho(macd, chuoimakhoa, idcoso, page, sodong);
            }

            else if (loai.Equals("loadxnl"))
            {
                string macd = context.Request.QueryString["macd"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                string idcoso = context.Request.QueryString["idcoso"];
                int page = Convert.ToInt32(context.Request.QueryString["page"]);
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
                str = LoadChiDinhXetNghiemBNCho_Loi(macd, chuoimakhoa, idcoso, page, sodong);
            }
            else if (loai.Equals("load_dropxnl"))
            {

                string macd = context.Request.QueryString["macd"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                string idcoso = context.Request.QueryString["idcoso"];
                str = LoadDropXNLoi(macd, chuoimakhoa, idcoso);
            }
            else if (loai.Equals("tongsotrangxnl"))
            {
                string macd = context.Request.QueryString["macd"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                string idcoso = context.Request.QueryString["idcoso"];
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
                str = TongSoTrangXNL(macd, chuoimakhoa, idcoso, sodong);
            }
            else if (loai.Equals("tongsodvcapnhat"))
            {
                string macd = context.Request.QueryString["macd"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                string idcoso = context.Request.QueryString["idcoso"];
                str = TongSoDVCapNhat(macd, chuoimakhoa, idcoso);
            }
            else if (loai.Equals("loaddsbn"))
            {
                string macd = context.Request.QueryString["macd"];
                string macap = context.Request.QueryString["macap"];
                string hoten = context.Request.QueryString["hoten"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                string idcoso = context.Request.QueryString["idcoso"];
                DateTime tungay = Convert.ToDateTime(context.Request.QueryString["tungay"]);
                DateTime denngay = Convert.ToDateTime(context.Request.QueryString["denngay"]);
                int page = Convert.ToInt32(context.Request.QueryString["page"]);
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
                str = LoadDanhSachBNCM(macd, macap, hoten, chuoimakhoa, idcoso, tungay, denngay, page, sodong);
            }

            else if (loai.Equals("loaddsbncho"))
            {
                string macd = context.Request.QueryString["macd"];
                string mabn = context.Request.QueryString["mabn"];
                string hoten = context.Request.QueryString["hoten"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                string idcoso = context.Request.QueryString["idcoso"];
                DateTime tungay = Convert.ToDateTime(context.Request.QueryString["tungay"]);
                DateTime denngay = Convert.ToDateTime(context.Request.QueryString["denngay"]);
                int page = Convert.ToInt32(context.Request.QueryString["page"]);
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);

                str = LoadDanhSachBNCho(macd, mabn, hoten, chuoimakhoa, idcoso, tungay, denngay, page, sodong);
            }
            else if (loai.Equals("dsmacapcungbn"))
            {
                string mabn = context.Request.QueryString["mabn"];
                string idcoso = context.Request.QueryString["idcoso"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                str = DSMaCapCungBN(mabn, idcoso, chuoimakhoa);
            }


            //else if (loai.Equals("macddautrang"))
            //{
            //    string macd = context.Request.QueryString["macd"];
            //    string macap = context.Request.QueryString["macap"];
            //    string hoten = context.Request.QueryString["hoten"];
            //    DateTime tungay = Convert.ToDateTime(context.Request.QueryString["tungay"]);
            //    DateTime denngay = Convert.ToDateTime(context.Request.QueryString["denngay"]);
            //    int sotrang = Convert.ToInt32(context.Request.QueryString["sotrang"]);
            //    int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
            //    str = LayMaChiDinhDauTrang(macd, macap, hoten, tungay, denngay, sotrang, sodong);
            //}





            else if (loai.Equals("huycd"))
            {
                string maxn = context.Request.QueryString["maxn"];
                string mabp = context.Request.QueryString["mabp"];
                string mavp = context.Request.QueryString["mavp"];
                string madv = context.Request.QueryString["madv"];
                string idct = context.Request.QueryString["idct"];
                str = HuyCD(maxn, mabp, idct, mavp, madv);
            }
            else if (loai.Equals("huycapma"))
            {
                string mabp = context.Request.QueryString["mabp"];
                string macd = context.Request.QueryString["macd"];
                string mavp = context.Request.QueryString["mavp"];
                str = HuyCapMa(mabp, mavp);
            }
            else if (loai.Equals("suacd"))
            {
                string mabn = context.Request.QueryString["mabn"].Trim();
                string maba = context.Request.QueryString["maba"].Trim();
                string mabp = context.Request.QueryString["mabp"].Trim();
                string maxncu = context.Request.QueryString["maxncu"];
                string maxnmoi = context.Request.QueryString["maxnmoi"];
                str = SuaChiDinhXetNghiem(mabn, maba, mabp, maxncu, maxnmoi);
            }
            else if (loai.Equals("sudungdvcd"))
            {
                string idct = context.Request.QueryString["idct"];
                string mavp = context.Request.QueryString["mavp"];
                string macd = context.Request.QueryString["macd"];
                str = SudungDVXN(idct, mavp);
            }
            else if (loai.Equals("huydvcd"))
            {
                string idct = context.Request.QueryString["idct"];
                string mavp = context.Request.QueryString["mavp"];
                str = HuyDVXN(idct, mavp);
            }
            else if (loai.Equals("tongsotrangcd"))
            {
                string mabp = context.Request.QueryString["mabp"];
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
                str = TongSoTrangCD(mabp, sodong);
            }
            else if (loai.Equals("tongsotrangcdcm"))
            {
                string mabp = context.Request.QueryString["mabp"];
                string macd = context.Request.QueryString["macd"];
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
                str = TongSoTrangCDCM(mabp, macd, sodong);
            }
            else if (loai.Equals("tongsotrangbn"))
            {
                string macd = context.Request.QueryString["macd"].Trim();
                string macap = context.Request.QueryString["macap"].Trim();
                string hoten = context.Request.QueryString["hoten"].Trim();
                DateTime tungay = Convert.ToDateTime(context.Request.QueryString["tungay"]);
                DateTime denngay = Convert.ToDateTime(context.Request.QueryString["denngay"]);
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
                str = TongSoTrangBN(tungay, denngay, macap, macd, hoten, sodong);
            }
            else if (loai.Equals("tongsotrangbncho"))
            {
                string macd = context.Request.QueryString["macd"].Trim();
                string mabn = context.Request.QueryString["mabn"].Trim();
                string hoten = context.Request.QueryString["hoten"].Trim();
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"].Trim();
                string idcoso = context.Request.QueryString["idcoso"].Trim();
                DateTime tungay = Convert.ToDateTime(context.Request.QueryString["tungay"]);
                DateTime denngay = Convert.ToDateTime(context.Request.QueryString["denngay"]);
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
                str = TongSoTrangBNCho(tungay, denngay, mabn, macd, hoten, chuoimakhoa, idcoso, sodong);
            }
            else if (loai.Equals("ktmabp"))
            {
                string mabp = context.Request.QueryString["mabp"].Trim();
                str = KiemTraMaBP(mabp);
            }
            else if (loai.Equals("loadcdxntrunggomma_cd"))//sp_XN_GomCacDVChiDinh_TrungGomMa
            {
                string macd = context.Request.QueryString["macd"].Trim();
                string mabp = context.Request.QueryString["mabp"].Trim();
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"].Trim();

                str = LoadChiDinhXetNghiemBNCho_TrungGomMa(macd, mabp, chuoimakhoa);
            }

            context.Response.Clear();
            context.Response.Cache.SetCacheability(HttpCacheability.Public);
            context.Response.Cache.SetExpires(DateTime.MinValue);
            context.Response.Write(str);

        }

        private string DSMaCapCungBN(string _mabn, string _idcoso, string chuoimakhoa)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            string ht = string.Format("{0:yyMMdd}", DateTime.Now);
            //string tgcm = string.Format("{dd/MM/yy}",x.TGCapMa);
            string dskhoa = chuoimakhoa.Replace("_", "");
            List<string> _dskhoa = dskhoa.Split(new char[] { ',' }).ToList();
            var dsbn = dbxn.View_XN_KQ_BenhNhan.Where(x => x.MaBN == _mabn && x.IDCoSo.Contains(_idcoso) == true && x.MaTGCapMa == ht);
            var dskq = dbxn.View_XN_KQ_XetNghiem.Where(x => _dskhoa.Contains(x.MaKhoaXNTheoCD) && x.MaTGCapMa == ht);
            var listdsbn = dsbn.Join(dskq,
                    x => x.MaBP,
                    y => y.MaBP,
                    (x, y) => new { x.MaBP, x.MaCap, x.MaBN, x.TGDuyet, x.HoTen }).ToList().Distinct();
            return serializer.Serialize(listdsbn);
        }

        private string LoadDropXNLoi(string macd, string chuoimakhoa, string idcoso)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            List<sp_XN_GomCacDVChiDinh_Result> listDscd = dbxn.sp_XN_GomCacDVChiDinh(macd, chuoimakhoa, idcoso).Where(x => x.TrangThai == "err").ToList();
            return serializer.Serialize(listDscd);
        }

        private string TongSoDVCapNhat(string macd, string chuoimakhoa, string idcoso)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int listDscd = dbxn.sp_XN_GomCacDVChiDinh(macd, chuoimakhoa, idcoso).Where(x => x.TrangThai == "err").Count();
            return listDscd.ToString();
        }

        private string TongSoTrangXNL(string macd, string chuoimakhoa, string idcoso, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int listDscd = dbxn.sp_XN_GomCacDVChiDinh(macd, chuoimakhoa, idcoso).Where(x => x.TrangThai == "err").Count() / sodong;
            return listDscd.ToString();
        }

        private string LoadChiDinhXetNghiemBNCho_Loi(string macd, string chuoimakhoa, string idcoso, int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var listDscd = ttbn.LoadChiDinhXetNghiemBNCho_ERR(macd, chuoimakhoa, idcoso, page, sodong).Select(x => new { STT = x.STT.Trim(), MaDV = x.MaDV.Trim(), IDCT = x.IDCT, TenDichVu = x.TenDichVu.Trim(), SoLuong = 1, Huy = x.Huy, SuDung = x.SuDung, XNTrung = x.XNTrung, TTMau = x.TTMau, MaChiDinh = x.MaChiDinh, MaVienPhi = x.MaVienPhi, ChuoiMaCD = macd, HoTen = x.Hoten });
            return serializer.Serialize(listDscd);
        }


        public string LoadChiDinhXetNghiemBNCho_TrungGomMa(string macd, string mabp, string chuoimakhoa)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            //string macd_trung="";
            string macd_full = macd + ",";
            try
            {
                List<XN_KQ_CapMa> kqcm = dbxn.XN_KQ_CapMa.Where(x => x.MaBP == mabp).ToList();
                foreach (var item in kqcm)
                {
                    macd_full += item.MaChiDinh + ",";
                }
                macd_full = macd_full.TrimEnd(',');

                var ds = dbxn.sp_XN_GomCacDVChiDinh_TrungGomMa(macd_full, macd, chuoimakhoa);
                return serializer.Serialize(ds);
            }
            catch (Exception ex)
            {
                return serializer.Serialize(ex.Message);
                //throw new Exception(ex.Message);
            }
        }


        private string CapMaBenhNhan_DL(string _chuoicd, string _chuoimakhoa, string _ngcapma)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                sp_XN_CapMaXetNghiem_DL_Result kqcm = dbxn.sp_XN_CapMaXetNghiem_DL(_chuoicd, _ngcapma, _chuoimakhoa).FirstOrDefault();
                if (kqcm.KQ == "ok")
                {
                    return serializer.Serialize(new { kqcm.KQ, ChuoiMaCap = kqcm.ChuoiMaCap.TrimEnd(' ').TrimEnd(';'), ChuoiHoTen = kqcm.ChuoiHoTen.TrimEnd(' ').TrimEnd(';'), ChuoiMCD = kqcm.ChuoiMCD.TrimEnd(' ').TrimEnd(';') });
                }
                else
                {
                    return serializer.Serialize(new { kqcm.KQ, ChuoiMaCap = kqcm.ErrorMessage });
                }

            }
            catch (Exception)
            {
                return serializer.Serialize(new { KQ = "err" });
            }
        }

        private string CapMaBenhNhan_TuyChon(string _chuoi_idct, string _chuoimc_cd, string _ng_capma, string _chuoimakhoa)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                if (_chuoi_idct.Contains(","))
                {
                    _chuoi_idct = _chuoi_idct.TrimEnd(',');
                }

                sp_XN_CapMaXetNghiem_TuyChon_Result kqcm = dbxn.sp_XN_CapMaXetNghiem_TuyChon(_chuoi_idct, _chuoimc_cd, _ng_capma, _chuoimakhoa).FirstOrDefault();
                if (kqcm.KQ == "ok")
                {
                    return serializer.Serialize(new { kqcm.KQ, ChuoiMaCap = kqcm.ChuoiMaCap.TrimEnd(' ').TrimEnd(';'), ChuoiHoTen = kqcm.ChuoiHoTen.TrimEnd(' ').TrimEnd(';'), ChuoiMCD = kqcm.ChuoiMCD.TrimEnd(' ').TrimEnd(';') });
                }
                else
                {
                    return serializer.Serialize(new { kqcm.KQ, ChuoiMaCap = kqcm.ErrorMessage });
                }

            }
            catch (Exception)
            {
                return serializer.Serialize(new { KQ = "err" });
            }
        }

        private string GomCapMaBenhNhan_TuyChon(string _chuoi_idct, string _chuoimc_cd, string _ng_capma, string _chuoimakhoa)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                if (_chuoi_idct.Contains(","))
                {
                    _chuoi_idct = _chuoi_idct.TrimEnd(',');
                }

                sp_XN_GomCapMaXetNghiem_TuyChon_Result kqcm = dbxn.sp_XN_GomCapMaXetNghiem_TuyChon(_chuoi_idct, _chuoimc_cd, _ng_capma, _chuoimakhoa).FirstOrDefault();
                if (kqcm.KQ == "ok")
                {
                    return serializer.Serialize(new { kqcm.KQ, ChuoiMaCap = kqcm.ChuoiMaCap.TrimEnd(' ').TrimEnd(';'), ChuoiHoTen = kqcm.ChuoiHoTen.TrimEnd(' ').TrimEnd(';'), ChuoiMCD = kqcm.ChuoiMCD.TrimEnd(' ').TrimEnd(';') });
                }
                else
                {
                    return serializer.Serialize(new { kqcm.KQ, ChuoiMaCap = kqcm.ErrorMessage });
                }

            }
            catch (Exception ex)
            {
                return serializer.Serialize(new { KQ = "err", Value = ex.Message });
            }
        }

        private string TongSoTrangBNCho(DateTime tungay, DateTime denngay, string mabn, string macd, string hoten, string chuoimakhoa, string idcoso, int sodong)
        {
            if (string.Format("{0:ddMMyyyy}", tungay) != "01011900" && string.Format("{0:ddMMyyyy}", denngay) != "01011900")
            {
                int count = (dbxn.sp_XN_HienThiDSChoBN(macd, mabn, hoten, chuoimakhoa, idcoso, tungay, denngay).Where(x => x.TGChiDinh >= tungay
                                         && x.TGChiDinh <= denngay
                                         && x.MaChiDinh.Contains(macd) == true
                                         && x.MaBN.Contains(mabn) == true
                                         && x.HoTen.Contains(hoten) == true)
                .Count()) / sodong;
                return count.ToString();


                //var b= dbxn.KQ_BenhNhan.Where(x => x.TGCapMa >= tungay
                //                    && x.TGCapMa <= denngay
                //                    && x.MaChiDinh.Contains(macd) == true
                //                    && x.MaCap.Contains(macap) == true
                //                    && x.HoTen.Contains(hoten) == true).ToList();
                //int c = b.Count()/sodong;
                //int a = (dbxn.KQ_BenhNhan.Where(x => x.TGCapMa >= tungay
                //                    && x.TGCapMa <= denngay
                //                    && x.MaChiDinh.Contains(macd) == true
                //                    && x.MaCap.Contains(macap) == true
                //                    && x.HoTen.Contains(hoten) == true)).Count()/sodong;
                //return a.ToString();
            }

            return "0";
        }

        private string KiemTraMaBP(string _mabp)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                if (ttbn.ktthongtinbn(_mabp))
                {
                    return serializer.Serialize(new { KQ = "find" });
                }
                return serializer.Serialize(new { KQ = "nofind" });
            }
            catch (Exception)
            {
                return serializer.Serialize(new { KQ = "err" });
            }

        }

        //private string LayMaChiDinhDauTrang(string macd, string macap, string hoten, DateTime tungay, DateTime denngay, int sotrang, int sodong)
        //{
        //    string chuoimacd="";
        //    //int i = 0;
        //    JavaScriptSerializer serializer = new JavaScriptSerializer();
        //    try
        //    {
        //        var listDscd = ttbn.LayMaChiDinhDauTrang(macd, macap, hoten, tungay, denngay, sotrang, sodong)
        //       .Select(x => new { MaCD = x.MaChiDinh });
        //        foreach (var item in listDscd)
        //        {
        //            //i++;
        //            chuoimacd += item.MaCD + "|";//i.ToString() +":"+ 
        //        }
        //        chuoimacd = chuoimacd.TrimEnd('|');
        //        return serializer.Serialize(new { KQ="ok",CHUOICD=chuoimacd });
        //    }
        //    catch (Exception ex)
        //    {
        //        return serializer.Serialize(new { KQ = "err", VALUE = ex.Message });
        //    }
        //}

        //private KQ_BenhNhan LayThongTinBenhNhanCD_CM(string macd)
        //{ 

        //}
        //Select(x => new { MaBP = x.MaBP
        private string LayThongTinBenhNhanCapMa(string mabp, string macd)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                View_XN_KQ_BenhNhan_MCD bn = new View_XN_KQ_BenhNhan_MCD();
                bn = ttbn.LayThongTinBenhNhanCD_CM(mabp, macd);

                //var thongtinbncd = dbxn.KQ_BenhNhan.Include(i => i.KQ_CapMa.Select(s => new { MaCD = s.MaChiDinh })).ToList();
                //var ttbncd = thongtinbncd.Select(x => new { MaChiDinh=x.macd});


                return serializer.Serialize(new
                {
                    KQ = "ok",
                    MaChiDinh = bn.MaCD,
                    bn.MaCap,
                    bn.MaBN,
                    bn.MaBA,
                    bn.HoTen,
                    bn.GioiTinh,
                    bn.Tuoi,
                    bn.NamSinh,
                    TGChiDinh = string.Format("{0:dd/MM/yy HH:mm:ss}", bn.TGChiDinh),
                    bn.MaNoiChiDinh,
                    bn.NoiChiDinh,
                    bn.NguoiChiDinh,
                    bn.DiaChi,
                    bn.SoBHYT,
                    HanBHYT = bn.HanBHYT == "01/01/1900" ? "" : bn.HanBHYT,
                    bn.ChanDoan,
                    bn.MaDT_HIV,
                    bn.MaDT,
                    bn.TenDoiTuong,
                    bn.CapCuu,
                    bn.NoiLayMau,
                    bn.MaBP,
                    bn.NguoiCapMa,
                    TGCapMa = string.Format("{0:dd/MM/yy HH:mm:ss}", bn.TGCapMa),
                    bn.NguoiDuyet,
                    TGDuyet = string.Format("{0:dd/MM/yy HH:mm:ss}", bn.TGDuyet)

                });
            }
            catch (Exception ex)
            {
                return serializer.Serialize(new KetQua { KQ = "err", Value = ex.Message });
            }
        }

        private string LayThongTinBenhNhanCho(string macd, string chuoimakhoa)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                sp_XN_LayThongTinBNDSCho_Result bn = new sp_XN_LayThongTinBNDSCho_Result();
                bn = ttbn.LayThongTinBenhNhanChoCM(macd, chuoimakhoa);
                return serializer.Serialize(new
                {
                    KQ = "ok",
                    bn.MaChiDinh,
                    bn.MaPhieu,
                    bn.MaBN,
                    bn.MaBA,
                    bn.HoTen,
                    bn.GioiTinh,
                    bn.Tuoi,
                    bn.NamSinh,
                    TGChiDinh = string.Format("{0:dd/MM/yyyy HH:mm:ss}", bn.TGChiDinh),
                    bn.MaNoiChiDinh,

                    bn.MaDotKham,
                    bn.NoiChiDinh,
                    bn.TenBSCD,
                    bn.DiaChi,
                    bn.SoBHYT,
                    HanBHYT = bn.HanBHYT == "01/01/1900" ? "" : bn.HanBHYT,
                    bn.ChanDoan,
                    //bn.MaDT_HIV,
                    bn.MaDT,
                    bn.TenDT,
                    bn.CapCuu
                    //bn.NoiLayMau,
                    //bn.MaBP,
                    //bn.NguoiCapMa,
                    //TGCapMa = string.Format("{0:dd/MM/yy HH:mm:ss}", bn.TGCapMa),
                    //bn.NguoiDuyet,
                    //TGDuyet = string.Format("{0:dd/MM/yy HH:mm:ss}", bn.TGDuyet)

                });
            }
            catch (Exception ex)
            {
                return serializer.Serialize(new KetQua { KQ = "err", Value = ex.Message });
            }

        }

        private string HuyCapMa(string mabp, string mavp)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();

            sp_XN_CapNhat_MaPhieu_VP huy = dbxn.sp_XN_CapNhat_MaPhieu_VP(mabp, mavp).FirstOrDefault();

            return serializer.Serialize(new { KQ = huy.KQ });
        }


        private int SoPhanTuXetNghiem(string mabp, string maxn)
        {
            return dbxn.XN_KQ_XetNghiem.Where(x => x.MaBP == mabp && x.MaXNCha == maxn).Count();
        }
        private string SuaChiDinhXetNghiem(string mabn, string maba, string mabp, string maxn_cu, string maxn_moi)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                ttbn.xoachidinhxn(mabp, maxn_cu);
                ttbn.LuuChiDinhXetNghiem(mabn, maba, mabp, maxn_moi);
                return serializer.Serialize(new { KQ = "ok" });
            }
            catch (Exception ex)
            {

                return serializer.Serialize(new { KQ = "err", Value = ex.Message });
            }
        }

        private string SudungDVXN(string idct, string mavp)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                return serializer.Serialize(new { KQ = ttbn.suachidinhdv(idct, mavp, "sudung"), IDCT = idct.Trim() });
            }
            catch (Exception ex)
            {

                return serializer.Serialize(new { KQ = "err", Value = ex.Message });
            }
        }

        private string HuyDVXN(string idct, string mavp)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                return serializer.Serialize(new { KQ = ttbn.suachidinhdv(idct, mavp, "huy"), IDCT = idct.Trim() });
            }
            catch (Exception ex)
            {

                return serializer.Serialize(new { KQ = "err", Value = ex.Message });
            }
        }

        private string LoadChiDinhXetNghiem(string mabp, string macd, int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var listDscd = ttbn.LoadChiDinhXetNghiem_CM(mabp, macd, page, sodong).Select(x => new { MaBP = x.MaBP, IDCT = x.IDCT, MaBN = x.MaBN, MaBA = x.MaBA, MaCD = x.MaChiDinh, MaVP = x.MaVienPhi, MaXN = x.MaXN, TenXetNghiem = x.TenXetNghiem, SoLuong = 1, MaDV = x.MaDV });
            return serializer.Serialize(listDscd);
        }

        private string LoadChiDinhXetNghiemBNCho(string macd, string chuoimakhoa, string idcoso, int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();

            var listDscd = ttbn.LoadChiDinhXetNghiemBNCho(macd, chuoimakhoa, idcoso, page, sodong).Select(x => new { STT = x.STT.Trim(), MaXN = x.MaDV.Trim(), IDCT = x.IDCT, TenXetNghiem = x.TenDichVu.Trim(), SoLuong = 1, Huy = x.Huy, SuDung = x.SuDung, XNTrung = x.XNTrung, TTMau = x.TTMau, MaChiDinh = x.MaChiDinh, MaVienPhi = x.MaVienPhi, ChuoiMaCD = macd });
            return serializer.Serialize(listDscd);
        }

        private string LoadDanhSachBNCM(string macd, string macap, string hoten, string chuoimakhoa, string idcoso, DateTime tungay, DateTime denngay, int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            // listDscd =new ;
            try
            {
                var listDscd = ttbn.LoadDanhSachBenhNhanCM(macd, macap, hoten, chuoimakhoa, idcoso, tungay, denngay, page, sodong).Select(x => new { STT = x.STT, MaBP = x.MaBP.Trim(), MaBN = x.MaBN.Trim(), MaBA = x.MaBA.Trim(), MaCD = x.MaChiDinh.Trim(), MaVP = x.MaVienPhi.Trim(), TGCapMa = string.Format("{0:dd/MM/yyyy}", x.TGCapMa), MaCap = x.MaCap, HoTen = x.HoTen, GioiTinh = (x.GioiTinh == true ? "Nam" : "Nữ"), NamSinh = x.NamSinh, NoiChiDinh = x.NoiChiDinh, TTMau = x.TTMau }).ToList();
                return serializer.Serialize(listDscd);
            }
            catch (Exception ex)
            {
                return serializer.Serialize(new { KQ = "err", Value = ex.Message });
            }

            //var listDscd = ttbn.LoadDanhSachBenhNhanCM(macd, macap, hoten, tungay, denngay, page, sodong)
            //.Select(x => new { MaBN = x.MaBN, MaBA = x.MaBA, MaBP = x.MaBP, MaCD = x.MaChiDinh, TGCapMa = string.Format("{0:dd/MM/yyyy HH:mm}", x.TGCapMa), MaCap = x.MaCap, HoTen = x.HoTen, GioiTinh = (x.GioiTinh == true ? "Nam" : "Nữ"), NamSinh = x.NamSinh, NoiChiDinh = x.NoiChiDinh });
            //return serializer.Serialize(listDscd);
        }


        private string LoadDanhSachBNCho(string macd, string mabn, string hoten, string chuoimakhoa, string idcoso, DateTime tungay, DateTime denngay, int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();

            try
            {
                var listDscd = ttbn.LoadDanhSachBenhNhanCho(macd, mabn, hoten, chuoimakhoa, idcoso, tungay, denngay, page, sodong).Select(x => new { STT = x.STT.ToString(), MaBN = x.MaBN.Trim(), MaBA = x.MaBA.Trim(), MaCD = x.MaChiDinh.Trim(), TGChiDinh = string.Format("{0:dd/MM/yyyy}", x.TGChiDinh), HoTen = x.HoTen, GioiTinh = (x.GioiTinh == true ? "Nam" : "Nữ"), NamSinh = x.NamSinh, NoiChiDinh = x.NoiChiDinh, TTMau = x.TTMau }).ToList();
                return serializer.Serialize(listDscd);
            }
            catch (Exception ex)
            {
                return serializer.Serialize(new { KQ = "err", Value = ex.Message });

            }

            //var listDscd = ttbn.LoadDanhSachBenhNhanCM(macd, macap, hoten, tungay, denngay, page, sodong)
            //.Select(x => new { MaBN = x.MaBN, MaBA = x.MaBA, MaBP = x.MaBP, MaCD = x.MaChiDinh, TGCapMa = string.Format("{0:dd/MM/yyyy HH:mm}", x.TGCapMa), MaCap = x.MaCap, HoTen = x.HoTen, GioiTinh = (x.GioiTinh == true ? "Nam" : "Nữ"), NamSinh = x.NamSinh, NoiChiDinh = x.NoiChiDinh });
            //return serializer.Serialize(listDscd);
        }


        private string LuuChiDinhXetNghiem(string mabn, string maba, string mabp, string maxn)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                ttbn.LuuChiDinhXetNghiem(mabn, maba, mabp, maxn);
                return serializer.Serialize(new { KQ = "ok" });
            }
            catch (Exception ex)
            {

                return serializer.Serialize(new { KQ = "err", Value = ex.Message });
            }
        }

        //private string LoadDanhSachXetNghiem(string keyword)
        //{
        //    JavaScriptSerializer serializer = new JavaScriptSerializer();
        //    var lstTenxn = ttbn.DocDanhSachTenXN(keyword).Select(x => new { MaXN = x.MaXN.Trim(), TenXetNghiem = x.TenXetNghiem.Trim().ToUpper().Replace(":", ""), ChiSoBinhThuong = (string.IsNullOrEmpty(x.ChiSoBinhThuong) ? "" : x.ChiSoBinhThuong.Trim()), DonVi = string.IsNullOrEmpty(x.DonVi) ? "" : x.DonVi.Trim(), Nhom_XN = (string.IsNullOrEmpty(x.Nhom_XN) ? "" : x.Nhom_XN.Trim()) }).Take(10).ToList();
        //    return serializer.Serialize(lstTenxn);
        //}


        private string TongSoTrangCD(string mabp, int sodong)
        {
            int count = (dbxn.XN_KQ_XetNghiem.Where(x => x.MaBP == mabp && x.XNChinh == true).Count()) / sodong;
            return count.ToString();
        }

        private string TongSoTrangCDCM(string mabp, string macd, int sodong)
        {
            int count = (dbxn.XN_KQ_XetNghiem.Where(x => x.MaBP == mabp.Trim() && x.MaChiDinh == macd.Trim() && x.XNChinh == true).Count()) / sodong;
            return count.ToString();
        }

        private string TongSoTrangBN(DateTime tungay, DateTime denngay, string macap, string macd, string hoten, int sodong)
        {
            if (string.Format("{0:ddMMyyyy}", tungay) != "01011900" && string.Format("{0:ddMMyyyy}", denngay) != "01011900")
            {
                int count = (dbxn.XN_KQ_BenhNhan.Where(x => x.TGCapMa >= tungay
                                    && x.TGCapMa <= denngay
                                    && x.MaChiDinh.Contains(macd) == true
                                    && x.MaCap.Contains(macap) == true
                                    && x.HoTen.Contains(hoten) == true).Count()) / sodong;
                return count.ToString();

            }

            return "0";

        }



        private string HuyCD(string maxn, string mabp, string idct, string mavp, string madv)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            if (KTHuyCD_DuyetKQ(mabp, maxn) == true)
            {
                try
                {
                    //KQ_XetNghiem xn = ttbn.DocTenXetNghiemDaXoa(mabp, maxn);
                    ttbn.xoachidinhxn_capma(mabp, maxn, mavp, idct, madv);//xoamacapbn
                    return serializer.Serialize(new { KQ = "ok" }); //hoten = bn.HoTen,macap=bn.MaCap,macd=bn.MaChiDinh });
                }
                catch (Exception ex)
                {
                    return serializer.Serialize(new KetQua { KQ = "err", Value = ex.Message });
                }
            }
            else
            {
                return serializer.Serialize(new KetQua { KQ = "err_d" });
            }

        }

        private bool KTHuyCD_DuyetKQ(string mabp, string maxn)
        {
            bool _result = false;
            int n_kqxn = 0;
            int n_kqks = 0;
            List<XN_KQ_XetNghiem> kqxn = new List<XN_KQ_XetNghiem>();
            List<XN_KQ_KhangSinh> kqks = new List<XN_KQ_KhangSinh>();
            kqxn = dbxn.XN_KQ_XetNghiem.Where(x => x.MaBP == mabp && x.MaXN == maxn).ToList();
            kqks = dbxn.XN_KQ_KhangSinh.Where(x => x.MaBP == mabp && x.MaXN == maxn).ToList();
            n_kqxn = kqxn.Count();
            n_kqks = kqks.Count();

            foreach (XN_KQ_XetNghiem kq in kqxn)
            {
                if (kq.TTDuyet == false || kq.TTDuyet == null)
                    _result = true;
                else
                    _result = false;
            }
            foreach (XN_KQ_KhangSinh kq in kqks)
            {
                if (kq.TTDuyet == false)
                    _result = true;
                else
                    _result = false;
            }

            return _result;
        }

        private string LoadDanhSachXetNghiem(string keyword, string manhom)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var lstTenxn = ttbn.DocDanhSachTenXN(keyword, manhom).Select(x => new { MaXN = x.MaXN.Trim(), TenXetNghiem = x.TenXetNghiem.Trim().ToUpper().Replace(":", ""), ChiSoBinhThuongNam = (string.IsNullOrEmpty(x.ChiSoBinhThuongNam) ? "" : x.ChiSoBinhThuongNam.Trim()), ChiSoBinhThuongNu = (string.IsNullOrEmpty(x.ChiSoBinhThuongNu) ? "" : x.ChiSoBinhThuongNu.Trim()), DonVi = string.IsNullOrEmpty(x.DonVi) ? "" : x.DonVi.Trim(), Nhom_XN = (string.IsNullOrEmpty(x.Nhom_XN) ? "" : x.Nhom_XN.Trim()) }).ToList();
            return serializer.Serialize(lstTenxn);
        }
        //x.DonVi.Trim().Contains("")? "&nbsp;" : x.DonVi
        private string CapMaBenhNhan(string _machidinh, string _macap, string _mabn, string _maba, string _hoten, bool _gioitinh, int _tuoi, string _namsinh, DateTime _ngaycd, string _khoacd, string _nguoicd, string _diachi, string _sobhyt, string _hanbhyt, string _chandoan, string _doituong, bool _capcuu, string _noilaymau, string _macapxn, string _mabp, string _nguoicm, DateTime _ngaycm, string _nguoiduyet, DateTime _ngayduyet)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();

            XN_KQ_BenhNhan bn = new XN_KQ_BenhNhan();

            bn.MaChiDinh = _machidinh;
            bn.MaCap = _macap;

            bn.MaBN = _mabn;
            bn.MaBA = _maba;
            bn.HoTen = _hoten;
            bn.GioiTinh = _gioitinh;
            bn.Tuoi = _tuoi;
            bn.NamSinh = _namsinh;
            bn.TGChiDinh = _ngaycd;
            bn.MaNoiChiDinh = _khoacd;
            bn.NguoiChiDinh = _nguoicd;
            bn.DiaChi = _diachi;
            bn.SoBHYT = _sobhyt;
            bn.HanBHYT = _hanbhyt;
            bn.ChanDoan = _chandoan;
            bn.MaDT_HIV = "DT1";
            bn.MaDT = _doituong;
            bn.CapCuu = _capcuu;

            bn.NoiLayMau = _noilaymau;
            bn.MaBP = _mabp;
            bn.NguoiCapMa = _nguoicm;
            bn.TGCapMa = _ngaycm;
            bn.NguoiDuyet = _nguoiduyet;
            bn.TGDuyet = _ngayduyet;

            try
            {
                if (_mabp != "")
                {
                    if (ttbn.ktthongtinbn(_mabp))
                    {
                        ttbn.suathongtinbn(bn);
                        return serializer.Serialize(new { KQ = "edit", macap = bn.MaCap, macd = bn.MaChiDinh, hoten = bn.HoTen }); //hoten = bn.HoTen,macap=bn.MaCap,macd=bn.MaChiDinh });
                    }
                    else
                    {
                        ttbn.themthongtinbn(bn);
                        return serializer.Serialize(new { KQ = "add", macap = bn.MaCap, macd = bn.MaChiDinh, hoten = bn.HoTen }); //hoten = bn.HoTen,macap=bn.MaCap,macd=bn.MaChiDinh });
                    }
                }
                else
                {
                    return serializer.Serialize(new { KQ = "empty" });
                }



            }
            catch (Exception ex)
            {
                return serializer.Serialize(new KetQua { KQ = "err", Value = ex.Message });
            }

        }


        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}