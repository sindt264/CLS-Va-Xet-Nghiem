﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Script.Serialization;
using Ykhoanet.DB.XetNghiem.DAL;
using Ykhoanet.DB.XetNghiem.BLL;

using System.Data.Entity;
using System.Collections;

namespace Ykhoanet.Handler
{
    /// <summary>
    /// Summary description for DMCongThucXN
    /// </summary>
    public class DMCongThucXN : IHttpHandler
    {

        public CanLamSangEntities dbxn = new CanLamSangEntities();
        public TraKetQuaXN ttbn = new TraKetQuaXN();

        public void ProcessRequest(HttpContext context)
        {


            //string kh = "HH,SH,SV";
            //string hh = "HH,";
            //bool ss = kh.Contains(hh);

            //List<XN_DM_XetNghiem> dm = new List<XN_DM_XetNghiem>();
            //string chuoidv = "";
            //string a= "HH3546,";
            //var dsdv = dbxn.XN_DM_XetNghiem.Where(x => x.MaDV.Contains(a)).ToList();  //Where(x => a.Contains(x.MaDV))//.Where(x=>x.MaXN=="XN123")
            //foreach (var item in dsdv)
            //{
            //    string b = item.MaDV;
            //    if (item.MaDV.Contains(a) == true)
            //    {
            //        dm.Add(item);
            //        chuoidv += item.MaDV;
            //    }
            //}

            //string c = chuoidv;

            string loai = context.Request.QueryString["loai"];
            string l = context.Request.QueryString["ten"];
            string str = "";

            if (String.IsNullOrEmpty(context.Request.QueryString["loai"]))
            {
                loai = "";
            }

            else if (loai.Equals("tongsotrangdmctt"))
            {
                string keyword = context.Request.QueryString["keyword"].Trim();
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                str = TongSoTrangDMCTT(keyword,sodong);
            }

            else if (loai.Equals("loaddmctt"))
            {

                string keyword = context.Request.QueryString["keyword"].Trim();
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                int page = Convert.ToInt32(context.Request.QueryString["page"].Trim());
                str = LoadDanhMucCTT(keyword,page, sodong);
            }


            else if (loai.Equals("xoactt"))
            {
                string maxn = context.Request.QueryString["maxn"].Trim();
                str = XoaCTT(maxn);
            }
            else if (loai.Equals("timct"))
            {
                string keyword = context.Request.QueryString["keyword"];
                string idcoso = context.Request.QueryString["idcoso"];
                str = TimNhomXN(keyword,idcoso);
            }

            else if (loai.Equals("timxn"))
            {
                string key = context.Request.QueryString["key"];
                string idcoso = context.Request.QueryString["idcoso"];
                str = TimXN(key, idcoso);
            }
            else if (loai.Equals("luuct"))
            {
                string maxn = context.Request.QueryString["maxn"].Trim('$');
                string dsmaxn = context.Request.QueryString["dsmaxn"].TrimEnd('$');
                string tenxn = context.Request.QueryString["tenxn"].TrimEnd('$');

                string congthuctinh = context.Request.QueryString["congthuctinh"].TrimEnd('$');
                string congthuctinhclient = context.Request.QueryString["congthuctinhclient"];
                string pheptinhclient = context.Request.QueryString["pheptinhclient"];
                string congthucht = context.Request.QueryString["congthucht"].TrimEnd('$');
                string congthuchtgd = context.Request.QueryString["congthuchtgd"].TrimEnd('$');

                string dktontaitp = context.Request.QueryString["dktontaitp"].TrimEnd('$');

                string dktontaict = context.Request.QueryString["dktontaict"].TrimEnd('$');
                string dktontaictclient = context.Request.QueryString["dktontaictclient"].TrimEnd('$');
                string dktontaictht = context.Request.QueryString["dktontaictht"].TrimEnd('$');
                string dktontaicthtgd = context.Request.QueryString["dktontaicthtgd"].TrimEnd('$');

                string lttp = context.Request.QueryString["lamtronthapphan"].TrimEnd('$');
                bool setclient = context.Request.QueryString["setclient"] == "1" ? true : false;
                bool setserver = context.Request.QueryString["setserver"] == "1" ? true : false;
                string idcoso = context.Request.QueryString["idcoso"];
                str = LuuCongThuc(maxn, dsmaxn, tenxn, congthuctinh, congthuctinhclient,pheptinhclient, congthucht, congthuchtgd, dktontaitp, dktontaict, dktontaictclient, dktontaictht, dktontaicthtgd, lttp,dsmaxn,setclient, setserver, idcoso);
            }

            context.Response.Clear();
            context.Response.Cache.SetCacheability(HttpCacheability.Public);
            context.Response.Cache.SetExpires(DateTime.MinValue);
            context.Response.Write(str);

        }


        private int KiemTraTonTaiCongThuc(string maxn)
        {
            int countct = dbxn.XN_DH_CongThucKQXN.Where(x => x.MaXN == maxn).Count();
            return countct;
        }

        public void themct_chitiet(string maxn ,string lttp)
        {

            List<string> strmaxn = lttp.Split(new char[] { '$' }).ToList();

            foreach (var item in strmaxn)
            {
                XN_DH_CongThucKQXN_ChiTiet tpctt = new XN_DH_CongThucKQXN_ChiTiet();
                tpctt.MaXN = maxn;
                tpctt.MaXNTrongCT = item;
                dbxn.XN_DH_CongThucKQXN_ChiTiet.Add(tpctt);
            }

            dbxn.SaveChanges();

        }

        public void xoact_chitiet(string maxn)
        {

            List<XN_DH_CongThucKQXN_ChiTiet> dstpct = dbxn.XN_DH_CongThucKQXN_ChiTiet.Where(x => x.MaXN == maxn).ToList();
            dbxn.XN_DH_CongThucKQXN_ChiTiet.RemoveRange(dstpct);
            dbxn.SaveChanges();

        }

        private string LuuCongThuc(string maxn, string dsmaxn, string tenxetnghiem, string congthuctinh, string congthuctinhclient, string pheptinhclient, string congthucht, string congthuchtgd, string dktontaitp, string dktontaict, string dktontaictclient, string dktontaictht, string dktontaicthtgd, string lamtronthapphan, string thanhphanct, bool setclient, bool setserver, string idcoso)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int ktct = KiemTraTonTaiCongThuc(maxn);
            if (ktct <= 0)
            {
                try
                {
                    XN_DH_CongThucKQXN ctt = new XN_DH_CongThucKQXN();
                    ctt.MaXN = maxn;
                    ctt.DSMaXN = dsmaxn;
                    ctt.TenXetNghiem = tenxetnghiem;
                    ctt.CongThucTinh = congthuctinh;
                    ctt.CongThucTinhClient = congthuctinhclient;
                    ctt.PhepTinhClient = pheptinhclient;
                    ctt.CongThucHienThi = congthucht;
                    ctt.CongThucHienThiGD = congthuchtgd;

                    ctt.DKTonTaiThanhPhan = dktontaitp;

                    ctt.DKTonTaiCongThuc = dktontaict;
                    ctt.DKTonTaiCongThucClient = dktontaictclient;
                    ctt.DKTonTaiCongThucHienThi = dktontaictht;
                    ctt.DKTonTaiCongThucHienThiGD = dktontaicthtgd;

                    ctt.LamTronThapPhan = lamtronthapphan;
                    ctt.SetClient = setclient;
                    ctt.SetServer = setserver;
                    ctt.IDCoSo = idcoso;
                    dbxn.XN_DH_CongThucKQXN.Add(ctt);
                    dbxn.SaveChanges();

                    themct_chitiet(maxn, thanhphanct);

                    return serializer.Serialize(new { KQ = "add" });
                }
                catch (Exception)
                {
                    return serializer.Serialize(new { KQ = "err" });
                }
            }
            else
            {
                try
                {
                    xoact_chitiet(maxn);

                    themct_chitiet(maxn, thanhphanct);

                    XN_DH_CongThucKQXN ctt = dbxn.XN_DH_CongThucKQXN.Where(x => x.MaXN == maxn).FirstOrDefault();
                    ctt.MaXN = maxn;
                    ctt.DSMaXN = dsmaxn;
                    ctt.TenXetNghiem = tenxetnghiem;
                    ctt.CongThucTinh = congthuctinh;
                    ctt.CongThucTinhClient = congthuctinhclient;
                    ctt.PhepTinhClient = pheptinhclient;

                    ctt.CongThucHienThi = congthucht;
                    ctt.CongThucHienThiGD = congthuchtgd;

                    ctt.DKTonTaiThanhPhan = dktontaitp;

                    ctt.DKTonTaiCongThuc = dktontaict;
                    ctt.DKTonTaiCongThucClient = dktontaictclient;
                    ctt.DKTonTaiCongThucHienThi = dktontaictht;
                    ctt.DKTonTaiCongThucHienThiGD = dktontaicthtgd;

                    ctt.LamTronThapPhan = lamtronthapphan;
                    ctt.SetClient = setclient;
                    ctt.SetServer = setserver;
                    ctt.IDCoSo = idcoso;
                    dbxn.SaveChanges();

                    return serializer.Serialize(new { KQ = "edit" });
                }
                catch (Exception)
                {

                    return serializer.Serialize(new { KQ = "err" });
                }
            }
        }

        private string TimNhomXN(string keyword, string idcoso)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsdmxn = dbxn.XN_DH_CongThucKQXN.Where(x => (x.TenXetNghiem.Contains(keyword) || x.MaXN.Contains(keyword)) && x.IDCoSo == idcoso).ToList();
            return serializer.Serialize(dsdmxn);
        }


        private string TimXN(string keyword, string idcoso)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsdmxn = dbxn.XN_DM_XetNghiem.Where(x => (x.TenDichVu.Contains(keyword) || x.MaXN.Contains(keyword) || x.TenXetNghiem.Contains(keyword) || x.NguoiThem.Contains(keyword)) && x.IDCoSo == idcoso).ToList();  //&& x.MaXNCha == x.MaXN
            return serializer.Serialize(dsdmxn);
        }

        private string XoaCTT(string maxn)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                XN_DH_CongThucKQXN ct = dbxn.XN_DH_CongThucKQXN.Where(x => x.MaXN == maxn).FirstOrDefault();
                dbxn.XN_DH_CongThucKQXN.Remove(ct);

                List<XN_DH_CongThucKQXN_ChiTiet> tpct = dbxn.XN_DH_CongThucKQXN_ChiTiet.Where(x => x.MaXN == maxn).ToList();
                dbxn.XN_DH_CongThucKQXN_ChiTiet.RemoveRange(tpct);

                dbxn.SaveChanges();
                return serializer.Serialize(new { KQ = "ok" });

            }
            catch (Exception)
            {
                return serializer.Serialize(new { KQ = "err" });
            }
        }

        private string LoadDanhMucCTT(string keyword,int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsct = dbxn.XN_DH_CongThucKQXN.Where(x => (x.MaXN.Contains(keyword) || x.TenXetNghiem.Contains(keyword))).OrderBy(x => x.AutoID).Skip((page - 1) * sodong).Take(sodong).ToList();
            return serializer.Serialize(dsct);
        }

        private string TongSoTrangDMCTT(string keyword,int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int count = dbxn.XN_DH_CongThucKQXN.Where(x => (x.MaXN.Contains(keyword) || x.TenXetNghiem.Contains(keyword))).Count() / sodong;
            return count.ToString();
        }



        public bool IsReusable
        {
            get
            {
                return false;
            }
        }




    }
}