﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Script.Serialization;
using Ykhoanet.DB.XetNghiem.DAL;
using Ykhoanet.DB.XetNghiem.BLL;

using System.Data.Entity;
using System.Collections;

namespace Ykhoanet.Handler._6_XetNghiem
{
    /// <summary>
    /// Summary description for DMKhangSinh
    /// </summary>
    /// 


    public class DMKhangSinh : IHttpHandler
    {
        public CanLamSangEntities dbxn = new CanLamSangEntities();
        public TraKetQuaXN ttbn = new TraKetQuaXN();
        public void ProcessRequest(HttpContext context)
        {
            string loai = context.Request.QueryString["loai"];

            string str = "";

            if (String.IsNullOrEmpty(context.Request.QueryString["loai"]))
            {
                loai = "";
            }

            if (loai.Equals("loaddanhmucks"))
            {
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                int page = Convert.ToInt32(context.Request.QueryString["page"].Trim());
                str = LoadDanhMucKS(page, sodong);
            }
            else if (loai.Equals("tongsotrangdmks"))
            {

                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                //string keyword = context.Request.QueryString["keyword"].Trim();
                str = TongSoTrangDMKS(sodong);

            }

            else if (loai.Equals("loaddanhmucpks"))
            {

                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                int page = Convert.ToInt32(context.Request.QueryString["page"].Trim());
                str = LoadDanhMucPKS(page, sodong);
            }
            else if (loai.Equals("tongsotrangdmpks"))
            {

                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                str = TongSoTrangDMPKS(sodong);

            }

            else if (loai.Equals("loaddanhmuckspks"))
            {
                //string keyword = context.Request.QueryString["keyword"].Trim();
                string mapks = context.Request.QueryString["mapks"].Trim();
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                int page = Convert.ToInt32(context.Request.QueryString["page"].Trim());
                str = LoadDanhMucKSPKS(mapks, page, sodong);
            }

            else if (loai.Equals("tongsotrangdmkspks"))
            {
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                string mapks = context.Request.QueryString["mapks"].Trim();
                str = TongSoTrangDMKSPKS(mapks,sodong);
            }
            else if (loai.Equals("luuks"))
            {
                string maks = context.Request.QueryString["maks"].Trim();
                string tenks = context.Request.QueryString["tenks"].Trim();
                string dkght = context.Request.QueryString["dkght"].Trim();
                string dkghd = context.Request.QueryString["dkghd"].Trim();
                string nguoithem = context.Request.QueryString["nguoithem"].Trim();
                string thutuks = context.Request.QueryString["thutuks"].Trim();
                str = ThemKhangSinh(maks,tenks,dkght,dkghd,nguoithem,thutuks);
            }
            else if (loai.Equals("luupks"))
            {
                string mapks = context.Request.QueryString["mapks"].Trim();
                string tenpks = context.Request.QueryString["tenpks"].Trim();
                string nguoithem = context.Request.QueryString["nguoithem"].Trim();
                str = ThemProfileKhangSinh(mapks, tenpks,nguoithem);
            }
            else if (loai.Equals("luukspks"))
            {
                string mapks = context.Request.QueryString["mapks"].Trim();
                string maks = context.Request.QueryString["maks"].Trim();
                string tenks = context.Request.QueryString["tenks"].Trim();
                string nguoithem = context.Request.QueryString["nguoithem"].Trim();
                str = ThemKhangSinhTrongProfileKhangSinh(mapks, maks, tenks, nguoithem);
            }
            else if (loai.Equals("timtenks"))
            {
                string keyword = context.Request.QueryString["keyword"];
                str = TimKhangSinh(keyword);
            }
            else if (loai.Equals("timtenpks"))
            {
                string keyword = context.Request.QueryString["keyword"];
                str =TimTenProfileKhangSinh(keyword);
            }
            else if (loai.Equals("timtenkspks"))
            {
                string keyword = context.Request.QueryString["keyword"];
                str = TimKhangSinhTrongProfile(keyword);
            }

            else if (loai.Equals("xoaks"))
            {
                string maks = context.Request.QueryString["maks"];
                str = XoaKhangSinh(maks);
            }
            else if (loai.Equals("xoapks"))
            {
                string mapks = context.Request.QueryString["mapks"];
                str = XoaProfileKhangSinh(mapks);
            }
            else if (loai.Equals("xoakspks"))
            {
                string maks = context.Request.QueryString["maks"];
                string mapks = context.Request.QueryString["mapks"];
                str = XoaKhangSinhTrongProfile(maks,mapks);
            }


            context.Response.Clear();
            context.Response.Cache.SetCacheability(HttpCacheability.Public);
            context.Response.Cache.SetExpires(DateTime.MinValue);
            context.Response.Write(str);


        }

        private string XoaKhangSinhTrongProfile(string maks, string mapks)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                XN_DM_ChiTiet_Profile_KhangSinh kspks = dbxn.XN_DM_ChiTiet_Profile_KhangSinh.Where(x => x.MaPKS == mapks && x.MaKS==maks).FirstOrDefault();
                dbxn.XN_DM_ChiTiet_Profile_KhangSinh.Remove(kspks);
                dbxn.SaveChanges();
                return serializer.Serialize(new { KQ = "ok" });
            }
            catch (Exception)
            {
                return serializer.Serialize(new { KQ = "err" });
            }
        }

        private string XoaProfileKhangSinh(string mapks)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                XN_DM_Profile_KhangSinh pks = dbxn.XN_DM_Profile_KhangSinh.Where(x => x.MaPKS == mapks).FirstOrDefault();
                dbxn.XN_DM_Profile_KhangSinh.Remove(pks);
                dbxn.SaveChanges();
                return serializer.Serialize(new { KQ = "ok" });

            }
            catch (Exception)
            {
                return serializer.Serialize(new { KQ = "err" });
            }
        }

        private string XoaKhangSinh(string maks)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                XN_DM_KhangSinh ks = dbxn.XN_DM_KhangSinh.Where(x=>x.MaKS==maks).FirstOrDefault();
                dbxn.XN_DM_KhangSinh.Remove(ks);
                dbxn.SaveChanges();
                return serializer.Serialize(new { KQ = "ok" });

            }
            catch (Exception)
            {
                return serializer.Serialize(new { KQ = "err" });
            }
        }

        private string TimKhangSinhTrongProfile(string keyword)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsdmxn = dbxn.XN_DM_KhangSinh.Where(x => (x.TenKhangSinh.Contains(keyword) || x.MaKS.Contains(keyword))).Take(20).ToList();
            return serializer.Serialize(dsdmxn);
        }

        private string TimTenProfileKhangSinh(string keyword)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsdmxn = dbxn.XN_DM_Profile_KhangSinh.Where(x => (x.TenProfileKhangSinh.Contains(keyword) || x.MaPKS.Contains(keyword))).Take(20).ToList();
            return serializer.Serialize(dsdmxn);
        }

        private string TimKhangSinh(string keyword)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsdmxn = dbxn.XN_DM_KhangSinh.Where(x => (x.TenKhangSinh.Contains(keyword) || x.MaKS.Contains(keyword))).Take(20).ToList();
            return serializer.Serialize(dsdmxn);
        }

        private string ThemKhangSinhTrongProfileKhangSinh(string mapks, string maks, string tenks, string nguoithem)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int ktkspks = dbxn.XN_DM_ChiTiet_Profile_KhangSinh.Where(x=>x.MaPKS==mapks && x.MaKS==maks).Count();
            if (ktkspks<=0)
            {
                try
                {
                    XN_DM_ChiTiet_Profile_KhangSinh kspks = new XN_DM_ChiTiet_Profile_KhangSinh();
                    kspks.MaPKS = mapks;
                    kspks.MaKS = maks;
                    kspks.TenKhangSinh = tenks;
                    kspks.NguoiThem = nguoithem;
                    kspks.TGThem = DateTime.Now;
                    dbxn.XN_DM_ChiTiet_Profile_KhangSinh.Add(kspks);
                    dbxn.SaveChanges();
                    return serializer.Serialize(new { KQ = "add" });
                }
                catch (Exception)
                {
                    return serializer.Serialize(new { KQ = "err" });
                }
            }
            else
            {
                try
                {
                    XN_DM_ChiTiet_Profile_KhangSinh kspks = dbxn.XN_DM_ChiTiet_Profile_KhangSinh.Where(x => x.MaPKS == mapks && x.MaKS == maks).FirstOrDefault();
                    kspks.MaPKS = mapks;
                    kspks.MaKS = maks;
                    kspks.TenKhangSinh = tenks;
                    kspks.NguoiThem = nguoithem;
                    kspks.TGThem = DateTime.Now;
                    dbxn.SaveChanges();
                    return serializer.Serialize(new { KQ = "save" });
                }
                catch (Exception)
                {

                    return serializer.Serialize(new { KQ = "err" });
                }
            }

        }

        private string ThemProfileKhangSinh(string mapks, string tenpks,string nguoithem)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int ktpks = dbxn.XN_DM_Profile_KhangSinh.Where(x=>x.MaPKS==mapks).Count();
            if (ktpks<=0)
            {
                try
                {
                    XN_DM_Profile_KhangSinh pks = new XN_DM_Profile_KhangSinh();
                    pks.MaPKS = mapks;
                    pks.TenProfileKhangSinh = tenpks;
                    pks.NguoiThem = nguoithem;
                    pks.TGThem = DateTime.Now;
                    dbxn.XN_DM_Profile_KhangSinh.Add(pks);
                    dbxn.SaveChanges();
                    return serializer.Serialize(new { KQ = "add" });
                }
                catch (Exception)
                {
                    return serializer.Serialize(new { KQ = "err" });
                }
            }
            else
            {
                try
                {
                    XN_DM_Profile_KhangSinh pks = dbxn.XN_DM_Profile_KhangSinh.Where(x => x.MaPKS == mapks).FirstOrDefault();
                    pks.TenProfileKhangSinh = tenpks;
                    pks.NguoiThem = nguoithem;
                    pks.TGThem = DateTime.Now;
                    dbxn.SaveChanges();
                    return serializer.Serialize(new { KQ = "save" });
                }
                catch (Exception)
                {
                    return serializer.Serialize(new { KQ = "err" });
                }
            }

        }

        private string ThemKhangSinh(string maks, string tenks, string dkght, string dkghd, string nguoithem,string thutuks)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int ktks = dbxn.XN_DM_KhangSinh.Where(x=>x.MaKS==maks).Count();
            if (ktks<=0)
            {
                try
                {
                    XN_DM_KhangSinh ks = new XN_DM_KhangSinh();
                    ks.MaKS = maks;
                    ks.TenKhangSinh = tenks;
                    ks.DKGH = dkghd + " - " + dkght;
                    ks.DKGHDuoi = Convert.ToDouble(dkghd);
                    ks.DKGHTren = Convert.ToDouble(dkght);
                    ks.NguoiThem = nguoithem;
                    ks.TTKS = Convert.ToInt16(thutuks);
                    ks.NgayThem = DateTime.Now;
                    dbxn.XN_DM_KhangSinh.Add(ks);
                    dbxn.SaveChanges();
                    return serializer.Serialize(new { KQ = "add" });

                }
                catch (Exception)
                {
                    return serializer.Serialize(new { KQ = "err" });
                }
            }
            else
            {
                try
                {
                    XN_DM_KhangSinh ks = dbxn.XN_DM_KhangSinh.Where(x=>x.MaKS==maks).FirstOrDefault();
                    //ks.MaKS = maks;
                    ks.TenKhangSinh = tenks;
                    ks.DKGH = dkghd + " - " + dkght;
                    ks.DKGHDuoi = Convert.ToDouble(dkghd);
                    ks.DKGHTren = Convert.ToDouble(dkght);
                    ks.NguoiThem = nguoithem;
                    ks.TTKS = Convert.ToInt16(thutuks);
                    ks.NgayThem = DateTime.Now;
                    dbxn.SaveChanges();
                    return serializer.Serialize(new { KQ = "save" });

                }
                catch (Exception)
                {
                    return serializer.Serialize(new { KQ = "err" });
                }
            }


        }

        private string TongSoTrangDMKSPKS(string mapks,int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int count = dbxn.XN_DM_ChiTiet_Profile_KhangSinh.Where(x => x.MaPKS==mapks).Count() / sodong;
            return count.ToString();
        }

        private string LoadDanhMucKSPKS(string mapks,int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsks = dbxn.XN_DM_ChiTiet_Profile_KhangSinh.Where(x => x.MaPKS == mapks).OrderBy(x => x.MaKS).Skip((page - 1) * sodong).Take(sodong).ToList()
                                                        .Select(x => new {x.MaPKS,x.MaKS,x.TenKhangSinh,x.NguoiThem,TGThem=string.Format("{0:dd/MM/yy}",x.TGThem) });
            return serializer.Serialize(dsks);
        }

        private string TongSoTrangDMPKS(int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int count = dbxn.XN_DM_Profile_KhangSinh.Count() / sodong;
            return count.ToString();
        }

        private string LoadDanhMucPKS(int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsks = dbxn.XN_DM_Profile_KhangSinh.OrderBy(x => x.TenProfileKhangSinh).Skip((page - 1) * sodong).Take(sodong).ToList()
                                                .Select(x => new {x.MaPKS,x.TenProfileKhangSinh,x.NguoiThem,TGThem=string.Format("{0:dd/MM/yy}",x.TGThem) });
            return serializer.Serialize(dsks);
        }

        private string TongSoTrangDMKS(int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int count = dbxn.XN_DM_KhangSinh.Count() / sodong;
            return count.ToString();
        }

        private string LoadDanhMucKS(int page,int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsks = dbxn.XN_DM_KhangSinh.OrderBy(x => x.TTKS).Skip((page - 1) * sodong).Take(sodong).ToList();
            return serializer.Serialize(dsks);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}