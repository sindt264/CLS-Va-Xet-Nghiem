﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Script.Serialization;
using Ykhoanet.DB.XetNghiem.DAL;
using Ykhoanet.DB.XetNghiem.BLL;

using System.Data.Entity;
using System.Collections;

namespace Ykhoanet.Handler._6_XetNghiem
{
   
    public class DangNhapND : IHttpHandler
    {
        public CanLamSangEntities dbxn = new CanLamSangEntities();

        public void ProcessRequest(HttpContext context)
        {
            string loai = context.Request.QueryString["loai"];
            string str="";
            if (loai.Equals("dn"))
            {
                string mand=context.Request.QueryString["mand"];
                string matkhau=context.Request.QueryString["matkhau"];
                str = KiemTraDangNhap(context,mand,matkhau);
            }

            context.Response.Clear();
            context.Response.Cache.SetCacheability(HttpCacheability.Public);
            context.Response.Cache.SetExpires(DateTime.MinValue);
            context.Response.Write(str);

        }

        private string KiemTraDangNhap(HttpContext context, string _mand, string _matkhau)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            string chuoimaquyen = ",", chuoimanhom = ",", hoten="",idcoso="";
            string manhom1 = "";
            string manhom2 = "";
            try
            {
                var dsnd=dbxn.View_XN_NguoiDung.Where(x => x.MaNV.Trim() == _mand && x.MatKhau.Trim() == _matkhau).ToList().Select(x => new {MaNV= x.MaNV.Trim(),HoTen=x.HoTen.Trim(), IDCoSo=x.IDCoSo}).FirstOrDefault();
                if (dsnd.MaNV.Trim()!="")
                {

                    hoten = dsnd.HoTen;
                    idcoso = dsnd.IDCoSo;

                    var dspq = dbxn.View_XN_PhanQuyen.Where(y => y.MaNV == _mand.Trim() && y.MaNhom=="XN").ToList().Select(x => new {MaNV= x.MaNV.Trim(),MaQuyen= x.MaQuyen.Trim(),MaNhom=x.MaNhom.Trim()}).OrderBy(x=>x.MaQuyen);

                    if (dspq.Count() > 0)
                    {
                        foreach (var item in dspq)
                        {
                            chuoimaquyen += item.MaQuyen + ",";
                            manhom2 = item.MaNhom;
                            if (manhom1!=manhom2)
                            {
                                chuoimanhom += manhom2 + ",";
                                manhom1 = manhom2;
                            }
                        }
                        
                    }
                }
                else
                {
                    return serializer.Serialize(new { KQ = "err", Value = "Bạn đã nhập sai tên tài khoản hoặc mật khẩu \n Vui lòng đăng nhập lại" });
                }
                return serializer.Serialize(new { KQ = "ok", HoTen = hoten, ChuoiMaQuyen = chuoimaquyen, ChuoiMaNhom = chuoimanhom, IDCoSo = idcoso });
            }
            catch (Exception e)
            {
                return serializer.Serialize(new { KQ = "err", Value = e.Message });
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}