﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Script.Serialization;
using Ykhoanet.DB.XetNghiem.DAL;
using Ykhoanet.DB.XetNghiem.BLL;

using System.Data.Entity;
using System.Collections;
using System.Data.Entity.Validation;

namespace Ykhoanet.Handler._6_XetNghiem
{
    /// <summary>
    /// Summary description for DMMayXetNghiem
    /// </summary>
    public class DMMayXetNghiem : IHttpHandler
    {
        public CanLamSangEntities dbxn = new CanLamSangEntities();
        public TraKetQuaXN ttbn = new TraKetQuaXN();
        public void ProcessRequest(HttpContext context)
        {
            string loai = context.Request.QueryString["loai"];

            string str = "";

            if (String.IsNullOrEmpty(context.Request.QueryString["loai"]))
            {
                loai = "";
            }

            if (loai.Equals("loaddanhmucmxn"))
            {
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                int page = Convert.ToInt32(context.Request.QueryString["page"].Trim());
                str = LoadDanhMucmxn(page, sodong);
            }

            else if (loai.Equals("tongsotrangdmmxn"))
            {

                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                //string keyword = context.Request.QueryString["keyword"].Trim();
                str = TongSoTrangDMmxn(sodong);

            }
            else if (loai.Equals("loaddanhmuctimmxn"))
            {
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                int page = Convert.ToInt32(context.Request.QueryString["page"].Trim());
                string keyword = context.Request.QueryString["keyword"].Trim();
                str = LoadDanhMuctimmxn(keyword, page, sodong);
            }
            else if (loai.Equals("tongsotrangdmtimmxn"))
            {

                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                string keyword = context.Request.QueryString["keyword"].Trim();
                str = TongSoTrangDMtimmxn(keyword, sodong);

            }

            else if (loai.Equals("loaddanhmuctimctmay"))
            {
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                int page = Convert.ToInt32(context.Request.QueryString["page"].Trim());
                string keyword = context.Request.QueryString["keyword"].Trim();
                str = LoadDanhMuctimmxn(keyword, page, sodong);
            }
            else if (loai.Equals("tongsotrangdmtimctmay"))
            {

                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                string keyword = context.Request.QueryString["keyword"].Trim();
                str = TongSoTrangDMtimmxn(keyword, sodong);

            }

            else if (loai.Equals("loaddanhmucctmay"))
            {

                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                int page = Convert.ToInt32(context.Request.QueryString["page"].Trim());
                str = LoadDanhMucctmay(page, sodong);
            }
            else if (loai.Equals("tongsotrangdmctmay"))
            {

                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                str = TongSoTrangDMctmay(sodong);

            }

            else if (loai.Equals("loaddanhmucxnmay"))
            {
                //string keyword = context.Request.QueryString["keyword"].Trim();
                string mactmay = context.Request.QueryString["mactmay"].Trim();
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                int page = Convert.ToInt32(context.Request.QueryString["page"].Trim());
                str = LoadDanhMucxnmay(mactmay, page, sodong);
            }

            else if (loai.Equals("tongsotrangdmxnmay"))
            {
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                string mactmay = context.Request.QueryString["mactmay"].Trim();
                str = TongSoTrangDMxnmay(mactmay, sodong);
            }

            else if (loai.Equals("loaddanhmucgtkn"))
            {

                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                int page = Convert.ToInt32(context.Request.QueryString["page"].Trim());
                str = LoadDanhMucgtkn(page, sodong);
            }

            else if (loai.Equals("tongsotrangdmgtkn"))
            {
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                str = TongSoTrangDMgtkn(sodong);
            }

            else if (loai.Equals("luumxn"))
            {
                string mamxn = context.Request.QueryString["mamxn"].Trim();
                string tenmxn = context.Request.QueryString["tenmxn"].Trim();
                string loaikn = context.Request.QueryString["loaikn"].Trim();
                string khoaxn = context.Request.QueryString["khoaxn"].Trim();
                str = ThemMayXN(mamxn, tenmxn, loaikn, khoaxn);
            }
            //else if (loai.Equals("luuctmay"))
            //{
            //    string mactmay = context.Request.QueryString["mactmay"].Trim();
            //    string tenctmay = context.Request.QueryString["tenctmay"].Trim();
            //    string ttnhomin = context.Request.QueryString["ttnhomin"].Trim();
            //    str = ThemNhomIn(mactmay, tenctmay, ttnhomin);
            //}
            else if (loai.Equals("luuxnmay"))
            {
                string mamxn = context.Request.QueryString["mamxn"].Trim();
                string maxn = context.Request.QueryString["maxn"].Trim();
                string madvmay = context.Request.QueryString["madvmay"].Trim();
                str = ThemDichVuMay(mamxn,maxn,madvmay);
            }

            else if (loai.Equals("luugtkn"))
            {
                string mamxn = context.Request.QueryString["mamxn"].Trim();
                string magtkn = context.Request.QueryString["magtkn"].Trim();
                string tengtkn = context.Request.QueryString["tengtkn"].Trim();
                str = ThemGiaoThucKetNoi(mamxn, magtkn, tengtkn);
            }

            else if (loai.Equals("timtenmxn"))
            {
                string keyword = context.Request.QueryString["keyword"];
                str = TimMayXN(keyword);
            }
            else if (loai.Equals("timtenctmay"))
            {
                string keyword = context.Request.QueryString["keyword"];
                str = TimMayXN(keyword);
            }
            else if (loai.Equals("timtenxnmay"))
            {
                string keyword = context.Request.QueryString["keyword"];
                str = TimXetNghiem(keyword);
            }

            else if (loai.Equals("xoamxn"))
            {
                string mamxn = context.Request.QueryString["mamxn"];
                str = XoaMayXN(mamxn);
            }
            //else if (loai.Equals("xoactmay"))
            //{
            //    string mactmay = context.Request.QueryString["mactmay"];
            //    str = XoaNhomIn(mactmay);
            //}
            else if (loai.Equals("xoaxnmay"))
            {

                string mamxn = context.Request.QueryString["mamxn"];
                string madvmay = context.Request.QueryString["madvmay"];
                string maxn = context.Request.QueryString["maxn"];
                str = XoaDichVuMay(mamxn, madvmay, maxn);

            }
            else if (loai.Equals("xoagtkn"))
            {

                string mamxn = context.Request.QueryString["mamxn"];
                string magtkn = context.Request.QueryString["magtkn"];
                str = XoaGiaoThucKN(mamxn, magtkn);

            }

            else if (loai.Equals("loadgiaothuckn"))
            {
                str = LoadGiaoThucKN();
            }
            else if (loai.Equals("loadloaikn"))
            {
                str = LoadLoaiKN();
            }
            else if (loai.Equals("loadkhoaxn"))
            {
                str = LoadKhoaXN();
            }
            else if (loai.Equals("loadtenmayxn"))
            {
                str = LoadTenMayXN();
            }

            context.Response.Clear();
            context.Response.Cache.SetCacheability(HttpCacheability.Public);
            context.Response.Cache.SetExpires(DateTime.MinValue);
            context.Response.Write(str);

        }












        private string LoadTenMayXN()
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var tenmayxn = dbxn.XN_DM_MayXetNghiem.OrderBy(x => x.IDMayXN).ToList();
            return serializer.Serialize(tenmayxn);
        }

        private string LoadKhoaXN()
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var khoaxn = dbxn.XN_DM_KhoaXN.OrderBy(x => x.TenKhoa).ToList();
            return serializer.Serialize(khoaxn);
        }

        private string LoadLoaiKN()
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var loaikn= dbxn.XN_DM_LoaiKetNoi.OrderBy(x => x.AutoID).ToList();
            return serializer.Serialize(loaikn);
        }

        private string LoadGiaoThucKN()
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var gtkn = dbxn.XN_DM_GiaoThucKetNoi.OrderBy(x => x.AutoID).ToList();
            return serializer.Serialize(gtkn);
        }

        private string LoadDanhMuctimmxn(string keyword, int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsdmxn = dbxn.XN_DM_MayXetNghiem.Where(x => (x.TenMayXN.Contains(keyword))).ToList();
            return serializer.Serialize(dsdmxn);
        }

        private string TongSoTrangDMtimmxn(string keyword, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int dsdmxn = dbxn.XN_DM_MayXetNghiem.Where(x => (x.TenMayXN.Contains(keyword))).Count()/sodong;
            return serializer.Serialize(dsdmxn.ToString());
        }

        private string XoaDichVuMay(string mamxn, string madvmay, string maxn)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                int _idmay = int.Parse(mamxn);
                XN_DM_DichVuMay xnmay = dbxn.XN_DM_DichVuMay.Where(x => x.MaDVMay == madvmay && x.IDMay == _idmay  && x.MaXN==maxn).FirstOrDefault();
                dbxn.XN_DM_DichVuMay.Remove(xnmay);
                dbxn.SaveChanges();
                return serializer.Serialize(new { KQ = "ok" });
            }
            catch (Exception ex)
            {
                return serializer.Serialize(new { KQ = "err", Value = ex.Message });
            }
        }

        private string XoaGiaoThucKN(string mamxn, string magtkn)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                XN_DM_GiaoThucKetNoi gtkn = dbxn.XN_DM_GiaoThucKetNoi.Where(x => x.MaGTKN == magtkn).FirstOrDefault();
                dbxn.XN_DM_GiaoThucKetNoi.Remove(gtkn);
                dbxn.SaveChanges();
                return serializer.Serialize(new { KQ = "ok" });
            }
            catch (Exception)
            {
                return serializer.Serialize(new { KQ = "err" });
            }
        }

        private string XoaMayXN(string mamxn)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                int _mamxn = int.Parse(mamxn);
                XN_DM_MayXetNghiem mxn = dbxn.XN_DM_MayXetNghiem.Where(x => x.IDMayXN == _mamxn).FirstOrDefault();
                dbxn.XN_DM_MayXetNghiem.Remove(mxn);
                dbxn.SaveChanges();
                return serializer.Serialize(new { KQ = "ok" });

            }
            catch (Exception ex)
            {
                return serializer.Serialize(new { KQ = "err", Value = ex.Message });
            }
        }

        private string TimXetNghiem(string keyword)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsdmxn = dbxn.XN_DM_XetNghiem.Where(x => (x.MaTimNhanh.Contains(keyword) || x.TenXetNghiem.Contains(keyword))).Take(20).ToList();
            return serializer.Serialize(dsdmxn);
        }

        private string TimMayXN(string keyword)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsdmxn = dbxn.XN_DM_MayXetNghiem.Where(x => (x.TenMayXN.Contains(keyword) || x.IDMayXN.ToString().Contains(keyword))).Take(20).ToList();
            return serializer.Serialize(dsdmxn);
        }

        private string ThemMayXN(string mamxn, string tenmxn, string loaicongkn,string khoa)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            if (mamxn!="" && tenmxn!="")
            {
                int _mamxn = int.Parse(mamxn);
                int ktmxn = dbxn.XN_DM_MayXetNghiem.Where(x => x.IDMayXN == _mamxn).Count();
                if (ktmxn <= 0)
                {
                    try
                    {

                        XN_DM_MayXetNghiem mxn = new XN_DM_MayXetNghiem();
                        //mxn.IDMayXN = Convert.ToInt32(mamxn);
                        mxn.TenMayXN = tenmxn;
                        //mxn.GiaoThucKN = gtkn;
                        //mxn.LoaiCongKN = loaicongkn;
                        mxn.KieuKetNoi = loaicongkn;
                        mxn.KhoaXN = khoa;
                        dbxn.XN_DM_MayXetNghiem.Add(mxn);
                        dbxn.SaveChanges();
                        return serializer.Serialize(new { KQ = "add" });

                    }
                    catch (Exception ex)
                    {
                        //return serializer.Serialize(new { KQ = "err" });      
                        throw ex;
                    }
                }
                else
                {
                    try
                    {
                        XN_DM_MayXetNghiem mxn = dbxn.XN_DM_MayXetNghiem.Where(x => x.IDMayXN == _mamxn).FirstOrDefault();
                        //mxn.IDMayXN = Convert.ToInt32(mamxn);
                        mxn.TenMayXN = tenmxn;
                        mxn.KieuKetNoi = loaicongkn;
                        mxn.KhoaXN = khoa;
                        dbxn.SaveChanges();
                        return serializer.Serialize(new { KQ = "save" });

                    }
                    catch (Exception ex)
                    {
                        return serializer.Serialize(new { KQ = "err" , Value = ex.Message});
                    }
                }
            }
            else
            {
                return serializer.Serialize(new { KQ = "err" });
            }
            


        }





        private string ThemDichVuMay(string mamxn, string maxn, string madvmay)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int _IDMayXN = Convert.ToInt32(mamxn);
            int ktmxn = dbxn.XN_DM_DichVuMay.Where(x => x.IDMay == _IDMayXN && x.MaDVMay == madvmay && x.MaXN == maxn).Count();
            if (ktmxn <= 0)
            {
                try
                {

                    XN_DM_DichVuMay mxn = new XN_DM_DichVuMay();
                    mxn.IDMay = _IDMayXN;
                    mxn.MaXN = maxn;
                    mxn.MaDVMay = madvmay;
                    dbxn.XN_DM_DichVuMay.Add(mxn);
                    dbxn.SaveChanges();
                    return serializer.Serialize(new { KQ = "add" });

                }
                catch (DbEntityValidationException ex)
                {

                    var errorMessages = ex.EntityValidationErrors
                        .SelectMany(x => x.ValidationErrors)
                        .Select(x => x.ErrorMessage);

                    // Join the list to a single string.
                    var fullErrorMessage = string.Join("; ", errorMessages);

                    // Combine the original exception message with the new one.
                    var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);

                    // Throw a new DbEntityValidationException with the improved exception message.
                    //throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
                    return serializer.Serialize(new { KQ = "err", Value = exceptionMessage });
                }
            }
            else
            {
                try
                {
                    XN_DM_DichVuMay mxn = dbxn.XN_DM_DichVuMay.Where(x => x.IDMay == _IDMayXN && x.MaDVMay == madvmay && x.MaXN == maxn).FirstOrDefault();
                    mxn.IDMay = _IDMayXN;
                    mxn.MaXN = maxn;
                    mxn.MaDVMay = madvmay;
                    dbxn.SaveChanges();
                    return serializer.Serialize(new { KQ = "save" });

                }
                catch (Exception)
                {
                    return serializer.Serialize(new { KQ = "err" });
                }
            }


        }


        private string ThemGiaoThucKetNoi(string mamxn, string magtkn, string tengtkn)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int ktmxn = dbxn.XN_DM_GiaoThucKetNoi.Where(x =>  x.MaGTKN == magtkn).Count();
            if (ktmxn <= 0)
            {
                try
                {

                    XN_DM_GiaoThucKetNoi gtkn = new XN_DM_GiaoThucKetNoi();
                    //gtkn.IDMayXN = mamxn;
                    gtkn.MaGTKN = magtkn;
                    gtkn.TenGTKN = tengtkn;
                    dbxn.XN_DM_GiaoThucKetNoi.Add(gtkn);
                    dbxn.SaveChanges();
                    return serializer.Serialize(new { KQ = "add" });

                }
                catch (Exception)
                {
                    return serializer.Serialize(new { KQ = "err" });
                }
            }
            else
            {
                try
                {
                    XN_DM_GiaoThucKetNoi gtkn = dbxn.XN_DM_GiaoThucKetNoi.Where(x =>x.MaGTKN == magtkn).FirstOrDefault();
                    //gtkn.IDMayXN = mamxn;
                    gtkn.MaGTKN = magtkn;
                    gtkn.TenGTKN = tengtkn;
                    dbxn.SaveChanges();
                    return serializer.Serialize(new { KQ = "save" });

                }
                catch (Exception)
                {
                    return serializer.Serialize(new { KQ = "err" });
                }
            }


        }
        private string TongSoTrangDMxnmay(string mamay, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int _sodv = Convert.ToInt32(mamay);
            var count = dbxn.XN_DM_DichVuMay.Where(x => x.IDMay == _sodv).Count() / sodong;
            return count.ToString();
        }

        private string TongSoTrangDMgtkn(int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int count = dbxn.XN_DM_GiaoThucKetNoi.Count() / sodong;
            return count.ToString();
        }

        //////////////////////////////////////////////////////////////////////
        private string LoadDanhMucxnmay(string mamxn, int page, int sodong) // join voi danh muc nhomxn de them cot ten nhomxn
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int _IDMayXN = int.Parse(mamxn);
            var dsdvm = dbxn.XN_DM_DichVuMay.Where(x => x.IDMay == _IDMayXN).OrderBy(x => x.AutoID);
            var dmxn = dbxn.XN_DM_XetNghiem;
            var dsks = dsdvm.Join(dmxn,
                                  x => x.MaXN,
                                  y => y.MaXN,
                                  (x, y) => new { x.AutoID, x.IDMay, x.MaDVMay, x.MaXN, y.TenXetNghiem}).OrderBy(x => x.TenXetNghiem).Skip((page - 1) * sodong).Take(sodong).ToList();
            return serializer.Serialize(dsks);
        }

        private string LoadDanhMucgtkn(int page, int sodong) // join voi danh muc nhomxn de them cot ten nhomxn
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsks = dbxn.XN_DM_GiaoThucKetNoi.ToList();
            //dbxn.XN_DM_GiaoThucKetNoi
            //                            .Join(dbxn.XN_DM_MayXetNghiem,
            //                             x => x.IDMayXN,
            //                             y => y.IDMayXN,
            //                             (x, y) => new { x.AutoID, x.MaGTKN, x.TenGTKN }).OrderBy(x => x.MaGTKN).Skip((page - 1) * sodong).Take(sodong).ToList();
            return serializer.Serialize(dsks);
        }

        private string TongSoTrangDMctmay(int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int count = dbxn.XN_DM_MayXetNghiem.Count() / sodong;
            return count.ToString();
        }

        private string LoadDanhMucctmay(int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsks = dbxn.XN_DM_MayXetNghiem.OrderBy(x => x.IDMayXN).Skip((page - 1) * sodong).Take(sodong).ToList()
                                                .Select(x => new { x.IDMayXN, x.TenMayXN});
            return serializer.Serialize(dsks);
        }

        private string TongSoTrangDMmxn(int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            int count = dbxn.XN_DM_MayXetNghiem.Count() / sodong;
            return count.ToString();
        }

        private string LoadDanhMucmxn(int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var dsks = "";
                //dbxn.XN_DM_MayXetNghiem
                //            .Join(dbxn.XN_DM_KhoaXN,
                //                  x=>x.NhomXN,
                //                  y=>y.IDKhoa,
                //                  (x, y) => new { x.IDMayXN, x.TenMay, x.LoaiCongKN, x.GiaoThucKN, KhoaXN = y.TenKhoa,MaKhoaXN=y.IDKhoa }).OrderBy(x => x.IDMayXN).Skip((page - 1) * sodong).Take(sodong).ToList();
            return serializer.Serialize(dsks);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}