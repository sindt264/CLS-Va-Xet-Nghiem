﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Script.Serialization;
using Ykhoanet.DB.XetNghiem.DAL;
using Ykhoanet.DB.XetNghiem.BLL;

using System.Data.Entity;
using System.Collections;

namespace Ykhoanet.Handler._6_XetNghiem
{
    /// <summary>
    /// Summary description for CapNhatKQMay
    /// </summary>
    public class CapNhatKQMay : IHttpHandler
    {
        public CanLamSangEntities dbxn = new CanLamSangEntities();
        public void ProcessRequest(HttpContext context)
        {
            string loai = context.Request.QueryString["loai"];

            string str = "";

            if (String.IsNullOrEmpty(context.Request.QueryString["loai"]))
            {
                loai = "";
            }

            if (loai.Equals("loaddropmayxn"))
            {
                str = LoadMayXetNghiem();
            }
            else if (loai.Equals("loaddroptrangthai"))
            {
                str = LoadTrangThaiKQMay();
            }
            else if (loai.Equals("tongsotrangkqmay"))
            {
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());

                string sid = context.Request.QueryString["sid"].Trim();
                string maxn = context.Request.QueryString["maxn"].Trim();
                DateTime mangay = Convert.ToDateTime(context.Request.QueryString["mangay"]);
                string idmayxn = context.Request.QueryString["idmayxn"].Trim();
                string idcoso = context.Request.QueryString["idcoso"].Trim();

                str = TongSoTrangKQMay(sid, maxn, mangay, idmayxn, idcoso, sodong);

            }
            else if (loai.Equals("loadkqmay"))//luu_cn_kq
            {
                string sid = context.Request.QueryString["sid"].Trim();
                string maxn = context.Request.QueryString["maxn"].Trim();
                DateTime mangay = Convert.ToDateTime(context.Request.QueryString["mangay"]);
                string idmayxn = context.Request.QueryString["idmayxn"].Trim();
                string idcoso = context.Request.QueryString["idcoso"].Trim();
                int page = Convert.ToInt32(context.Request.QueryString["page"].Trim());
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"].Trim());
                str = LoadKQMay(sid, maxn, mangay, idmayxn, idcoso, page, sodong);
            }

            else if (loai.Equals("luu_cn_kq"))//luu_cn_kq
            {
                string chuoiid_cn = context.Request.QueryString["chuoiid_cn"].Trim();
                str = CapNhatKQMayTheoChuoiID(chuoiid_cn);
            }

            else if (loai.Equals("doi_sid"))//luu_cn_kq
            {
                string chuoiid_cn = context.Request.QueryString["chuoiid_cn"].Trim();
                string sid = context.Request.QueryString["sid"].Trim();
                str = CapNhatKQMayDoiSID(chuoiid_cn, sid);
            }

            else if (loai.Equals("timtenxn"))//luu_cn_kq
            {
                string key = context.Request.QueryString["key"].Trim();
                string ngaytim = context.Request.QueryString["ngaytim"].Trim();

                str = TimXN(key, ngaytim);
            }



            context.Response.Clear();
            context.Response.Cache.SetCacheability(HttpCacheability.Public);
            context.Response.Cache.SetExpires(DateTime.MinValue);
            context.Response.Write(str);
        }

        private string CapNhatKQMayDoiSID(string chuoiid_cn, string sid)
        {
            chuoiid_cn = chuoiid_cn.TrimEnd(',');
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            List<XN_KQ_XetNghiem> ds = new List<XN_KQ_XetNghiem>();
            List<XN_TM_KQ_May> dstam = new List<XN_TM_KQ_May>();
            List<string> _id_up = chuoiid_cn.Split(new char[] { ',' }).ToList();

            try
            {
                foreach (var item in _id_up)
                {
                    if (chuoiid_cn != "")
                    {
                        XN_TM_KQ_May kqt = dbxn.XN_TM_KQ_May.Where(x => x.AutoID.ToString() == item).FirstOrDefault();
                        string[] str = kqt.MaBP.Split('_');
                        kqt.MaCap = sid.Trim();
                        kqt.MaBP = str[0] + "_" + sid.Trim();
                        dstam.Add(kqt);
                    }
                }

                dbxn.SaveChanges();
                foreach (var item in _id_up)
                {
                    if (chuoiid_cn != "")
                    {
                        XN_TM_KQ_May kqt = dbxn.XN_TM_KQ_May.Where(x => x.AutoID.ToString() == item).FirstOrDefault();
                        XN_KQ_XetNghiem kq = dbxn.XN_KQ_XetNghiem.Where(x => x.MaXN == kqt.MaXN && x.MaBP == kqt.MaBP).FirstOrDefault();
                        if (kq != null)
                        {
                            if (kq.TTDuyet == null || kq.TTDuyet == false)
                            {
                                kqt.TrangThaiKQ = "UPL";
                                kq.KetQua = kqt.KetQua;
                                ds.Add(kq);
                            }
                        }
                    }
                }
                dbxn.SaveChanges();

                return serializer.Serialize(new { KQ = "ok" });
            }
            catch
            {
                return serializer.Serialize(new { KQ = "err" });
            }

        }

        private string TimXN(string key, string ngaytim)
        {

            JavaScriptSerializer serializer = new JavaScriptSerializer();

            DateTime _ngaytim = Convert.ToDateTime(ngaytim);

            var kqm = dbxn.XN_TM_KQ_May.Where(x => x.NgayXN == _ngaytim).Select(o => new { MaXN = o.MaXN }).Distinct();

            var dmxn = dbxn.XN_DM_XetNghiem.Where(x => x.TenXetNghiem.Contains(key));

            var kqtheomaxn = dmxn.Join(kqm,
                                    x => x.MaXN,
                                    y => y.MaXN,
                                    (x, y) => new { y.MaXN, x.TenXetNghiem })
                                    .OrderBy(o => o.TenXetNghiem).ToList();

            //var dsmayxn = dbxn.XN_DM_MayXetNghiem.Where(x=>x.IDCoSo==idcoso);

            //var dskqmay = dbxn.XN_TM_KQ_May.Where(x => x.MaCap.Contains(sid) && x.MaXN.Contains(maxn) && x.IDMayXN.ToString().Contains(idmayxn) && x.NgayXN == mangay).OrderBy(x => x.AutoID);

            //var dskqmay_dd = dskqmay.Join(dsmayxn,
            //    x => x.IDMayXN,
            //    y => y.IDMay,
            //    (x, y) => new { x.AutoID,x.MaBP,x.MaCap, x.MaMay, x.MaXN, x.KetQua, x.DonVi, x.TGCoKQ,x.IDMayXN, y.TenMay, x.TrangThaiKQ,y.IDCoSo })
            //    .OrderBy(o => o.IDMayXN).ThenBy(o => o.MaCap).ThenBy(o => o.AutoID)
            //    .Skip((page - 1) * sodong).Take(sodong).ToList()
            //    .Select(y => new { y.IDCoSo,y.AutoID, y.MaBP, y.MaCap, y.MaMay, y.MaXN, y.KetQua, y.DonVi, TGCoKQ = string.Format("{0:dd/MM/yyyy HH:mm:ss}", y.TGCoKQ), y.IDMayXN, TenMay=y.TenMay==""?"???":y.TenMay, y.TrangThaiKQ });

            return serializer.Serialize(kqtheomaxn);

        }

        private string CapNhatKQMayTheoChuoiID(string chuoiid_cn)
        {
            chuoiid_cn = chuoiid_cn.TrimEnd(',');
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            List<XN_KQ_XetNghiem> ds = new List<XN_KQ_XetNghiem>();
            List<XN_TM_KQ_May> dstam = new List<XN_TM_KQ_May>();
            List<string> _id_up = chuoiid_cn.Split(new char[] { ',' }).ToList();

            try
            {
                foreach (var item in _id_up)
                {
                    if (chuoiid_cn != "")
                    {
                        XN_TM_KQ_May kqt = dbxn.XN_TM_KQ_May.Where(x => x.AutoID.ToString() == item).FirstOrDefault();
                        XN_KQ_XetNghiem kq = dbxn.XN_KQ_XetNghiem.Where(x => x.MaXN == kqt.MaXN && x.MaBP == kqt.MaBP).FirstOrDefault();
                        if (kq != null)
                        {
                            if (kq.TTDuyet == null || kq.TTDuyet == false)
                            {
                                kqt.TrangThaiKQ = "UPL";
                                kq.KetQua = kqt.KetQua;
                                ds.Add(kq);
                            }
                        }
                    }
                }

                dbxn.SaveChanges();
                return serializer.Serialize(new { KQ = "ok" });
            }
            catch
            {
                return serializer.Serialize(new { KQ = "err" });
            }


        }




        private string LoadKQMay(string sid, string maxn, DateTime mangay, string idmayxn, string idcoso, int page, int sodong)
        {

            JavaScriptSerializer serializer = new JavaScriptSerializer();

            try
            {

                var dsmayxn = dbxn.XN_DM_MayXetNghiem.Where(x => x.IDCoSo == idcoso);

                var dskqmay = dbxn.XN_TM_KQ_May.Where(x => x.MaCap.Contains(sid) && x.MaXN.Contains(maxn) && x.IDMayXN.ToString().Contains(idmayxn) && x.NgayXN == mangay).OrderBy(x => x.AutoID);

                var dskqmay_dd = dskqmay.Join(dsmayxn,
                    x => x.IDMayXN,
                    y => y.IDMayXN,
                    (x, y) => new { x.AutoID, x.MaBP, x.MaCap, x.MaMay, x.MaXN, x.KetQua, x.DonVi, x.TGCoKQ, x.IDMayXN, y.TenMayXN, x.TrangThaiKQ, y.IDCoSo })
                    .OrderBy(o => o.IDMayXN).ThenBy(o => o.MaCap).ThenBy(o => o.AutoID)
                    .Skip((page - 1) * sodong).Take(sodong).ToList()
                    .Select(y => new { y.IDCoSo, y.AutoID, y.MaBP, y.MaCap, y.MaMay, y.MaXN, y.KetQua, y.DonVi, TGCoKQ = string.Format("{0:dd/MM/yyyy HH:mm:ss}", y.TGCoKQ), y.IDMayXN, TenMay = y.TenMayXN == "" ? "???" : y.TenMayXN, y.TrangThaiKQ });

                return serializer.Serialize(dskqmay_dd);

            }
            catch (Exception)
            {
                return "0";
            }

        }

        private string TongSoTrangKQMay(string sid, string maxn, DateTime mangay, string idmayxn, string idcoso, int sodong)
        {

            JavaScriptSerializer serializer = new JavaScriptSerializer();

            try
            {

                var dsmayxn = dbxn.XN_DM_MayXetNghiem.Where(x => x.IDCoSo == idcoso);

                var dskqmay = dbxn.XN_TM_KQ_May.Where(x => x.MaCap.Contains(sid) && x.MaXN.Contains(maxn) && x.IDMayXN.ToString().Contains(idmayxn) && x.NgayXN == mangay).OrderBy(x => x.AutoID);

                int count = dskqmay.Join(dsmayxn,
                    x => x.IDMayXN,
                    y => y.IDMayXN,
                    (x, y) => new { x.AutoID, x.MaMay, x.MaXN, x.KetQua, x.DonVi, x.TGCoKQ, y.TenMayXN, x.TrangThaiKQ }).Count() / sodong;

                return serializer.Serialize(count);

            }
            catch (Exception)
            {
                return "0";
            }

        }

        private string LoadTrangThaiKQMay()
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var tenmayxn = dbxn.XN_DM_TrangThaiKQMay.OrderBy(x => x.AutoID).ToList();
            return serializer.Serialize(tenmayxn);
        }

        private string LoadMayXetNghiem()
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var tenmayxn = dbxn.XN_DM_MayXetNghiem.OrderBy(x => x.IDMayXN).ToList();
            return serializer.Serialize(tenmayxn);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}