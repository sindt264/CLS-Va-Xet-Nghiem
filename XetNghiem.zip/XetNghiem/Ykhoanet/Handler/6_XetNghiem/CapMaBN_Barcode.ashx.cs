﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Script.Serialization;
using Ykhoanet.DB.XetNghiem.DAL;
using Ykhoanet.DB.XetNghiem.BLL;

using System.Data.Entity;
using System.Collections;

namespace Ykhoanet.Handler._6_XetNghiem
{
    public class CapMaBN_Barcode : IHttpHandler
    {
        public CanLamSangEntities dbxn = new CanLamSangEntities();

        public ThongTinTiepNhanBN ttbn = new ThongTinTiepNhanBN();

        public void ProcessRequest(HttpContext context)
        {
            string loai = context.Request.QueryString["loai"];
            //context.Response.ContentType = "text/plain";
            //context.Response.Write("Hello World");
            string str = "";
            if (loai == "thongtinbncho")
            {
                string macd = context.Request.QueryString["macd"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                str = LayThongTinBenhNhanCho(macd, chuoimakhoa);
            }
            if (loai == "loadxnl")
            {
                string macd = context.Request.QueryString["macd"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                string idcoso = context.Request.QueryString["idcoso"];
                int page = Convert.ToInt32(context.Request.QueryString["page"]);
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
                str = LoadChiDinhXetNghiemBNCho_Loi(macd, chuoimakhoa, idcoso, page, sodong);
            }
            if (loai.Equals("loadcdxn_cd"))
            {
                string macd = context.Request.QueryString["macd"];
                string chuoimakhoa = context.Request.QueryString["chuoimakhoa"];
                string idcoso = context.Request.QueryString["idcoso"];
                int page = Convert.ToInt32(context.Request.QueryString["page"]);
                int sodong = Convert.ToInt32(context.Request.QueryString["sodong"]);
                str = LoadChiDinhXetNghiemBNCho(macd, chuoimakhoa, idcoso, page, sodong);
            }


            context.Response.Clear();
            context.Response.Cache.SetCacheability(HttpCacheability.Public);
            context.Response.Cache.SetExpires(DateTime.MinValue);
            context.Response.Write(str);
        }


        private string LoadChiDinhXetNghiemBNCho(string macd, string chuoimakhoa, string idcoso, int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var listDscd = ttbn.LoadChiDinhXetNghiemBNCho(macd, chuoimakhoa, idcoso, page, sodong).Select(x => new { STT = x.STT.Trim(), MaXN = x.MaDV.Trim(), IDCT = x.IDCT, TenXetNghiem = x.TenDichVu.Trim(), SoLuong = 1, Huy = x.Huy, SuDung = x.SuDung, XNTrung = x.XNTrung, TTMau = x.TTMau, MaChiDinh = x.MaChiDinh, MaVienPhi = x.MaVienPhi, ChuoiMaCD = macd });
            return serializer.Serialize(listDscd);
        }

        private string LayThongTinBenhNhanCho(string macd, string chuoimakhoa)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            try
            {
                sp_XN_LayThongTinBNDSCho_Result bn = new sp_XN_LayThongTinBNDSCho_Result();
                bn = ttbn.LayThongTinBenhNhanChoCM(macd, chuoimakhoa);
                return serializer.Serialize(new
                {
                    KQ = "ok",
                    bn.MaChiDinh,
                    bn.MaPhieu,
                    bn.MaBN,
                    bn.MaBA,
                    bn.HoTen,
                    bn.GioiTinh,
                    bn.Tuoi,
                    bn.NamSinh,
                    TGChiDinh = string.Format("{0:dd/MM/yyyy HH:mm:ss}", bn.TGChiDinh),
                    bn.MaNoiChiDinh,

                    bn.MaDotKham,
                    bn.NoiChiDinh,
                    bn.TenBSCD,
                    bn.DiaChi,
                    bn.SoBHYT,
                    HanBHYT = bn.HanBHYT == "01/01/1900" ? "" : bn.HanBHYT,
                    bn.ChanDoan,
                    bn.MaDT,
                    bn.TenDT

                });
            }
            catch (Exception ex)
            {
                return serializer.Serialize(new KetQua { KQ = "err", Value = ex.Message });
            }

        }

        private string LoadChiDinhXetNghiemBNCho_Loi(string macd, string chuoimakhoa, string idcoso, int page, int sodong)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var listDscd = ttbn.LoadChiDinhXetNghiemBNCho_ERR(macd, chuoimakhoa, idcoso, page, sodong).Select(x => new { STT = x.STT.Trim(), MaDV = x.MaDV.Trim(), IDCT = x.IDCT, TenDichVu = x.TenDichVu.Trim(), SoLuong = 1, Huy = x.Huy, SuDung = x.SuDung, XNTrung = x.XNTrung, TTMau = x.TTMau, MaChiDinh = x.MaChiDinh, MaVienPhi = x.MaVienPhi, ChuoiMaCD = macd, HoTen = x.Hoten });
            return serializer.Serialize(listDscd);
        }

        public List<sp_XN_GomCacDVChiDinh_Result> LoadChiDinhXetNghiemBNCho_ERR(string macd, string chuoimakhoa, string idcoso, int page, int sodong)
        {
            try
            {
                List<sp_XN_GomCacDVChiDinh_Result> ds = dbxn.sp_XN_GomCacDVChiDinh(macd, chuoimakhoa, idcoso).Where(x => x.TrangThai == "err").OrderBy(x => x.MaChiDinh).Skip((page - 1) * sodong).Take(sodong).ToList();
                return ds;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}