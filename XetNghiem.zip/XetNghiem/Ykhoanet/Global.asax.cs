﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using Ykhoanet;

namespace Ykhoanet
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            AuthConfig.RegisterOpenAuth();
            RouteConfig.RegisterRoutes(RouteTable.Routes);


            //Application.Lock();
            //Application["sotruycap"] = 1;
            //Application["soonline"] = 0;
            //Application.UnLock();

        }

        void Application_End(object sender, EventArgs e)
        {
            //  Code that runs on application shutdown

        }

        void Application_Error(object sender, EventArgs e)
        {
            // Code that runs when an unhandled error occurs

        }

        void Session_Start(object sender, EventArgs e)
        {
            //int so = 0;
            //Application.Lock();
            //Application["sotruycap"] = so + 1;
            //Application["soonline"] = (int)Application["soonline"] + 1;
            //Application.UnLock();
            //Session["MaNV"] = string.Empty;
        }

        void Session_End(object sender, EventArgs e)
        {

            Session["mand"] = string.Empty;
            Session["tennguoidung"] = string.Empty;
        }


    }

}
