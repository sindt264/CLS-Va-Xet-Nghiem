﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ykhoanet
{
    public partial class BCTK_XN_SoXetNghiem : System.Web.UI.Page
    {
        StringBuilder StrHtmlGenerate = new StringBuilder();
        StringBuilder StrExport = new StringBuilder();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

    }
}