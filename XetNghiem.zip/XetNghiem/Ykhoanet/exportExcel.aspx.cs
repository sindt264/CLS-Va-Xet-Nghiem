﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.IO;

public partial class exportExcel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string fname = "Baocao_";
        if (Request.Params["data"] != null)
        {
            //if (Request.Params["name"] != null && Request.Params["name"].ToString() != "")
            //{
            //    fname = Request.Params["name"].ToString().Trim() + "_";
            //}
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=" + fname
                + DateTime.Now.ToString("MMddyyyyHHmm") + "_"  + ".doc");

            //+ (Session["mand"].ToString().Trim() == "" ? "Noname" : Session["mand"].ToString().Trim())

            Response.ContentType = "application/vnd.ms-excel";
            Response.Charset = "";
            Response.ContentEncoding = Encoding.Unicode;
            Response.BinaryWrite(Encoding.Unicode.GetPreamble());
            string data = Request.Params["data"].ToString().Replace("|", "<");
            data = data.Replace("border=\"0\"", "border=\"1\"");
            data = data.Replace("border=0", "border=\"1\"");
            Response.Output.Write(data);
            Response.Flush();
            Response.End();


            //Response.Clear();
            //Response.Buffer = true;
            //Response.AddHeader("content-disposition", "attachment;filename=YKHOANET_KSK_" + DateTime.Now.ToString("dd-MM-yyyy_HH-mm-ss") + ".xls");
            //Response.ContentType = "application/vnd.ms-excel";
            //Response.Charset = "";
            //Response.ContentEncoding = System.Text.Encoding.Unicode;
            //Response.BinaryWrite(System.Text.Encoding.Unicode.GetPreamble());
            //StringWriter oStringWriter = new StringWriter();
            //HtmlTextWriter oHtmlTextWriter = new HtmlTextWriter(oStringWriter);

            //string data = Request.Params["data"].ToString().Replace("|", "<");
            //data = data.Replace("border=\"0\"", "border=\"1\"");
            //data = data.Replace("border=0", "border=\"1\"");
            ////Response.Write(data);


            //baocao_content.RenderControl(oHtmlTextWriter);
            ////Response.Write(oStringWriter.ToString());
            //Response.Output.Write(oStringWriter.ToString());
            //Response.Flush();
            //Response.End();




        }
    }
}
