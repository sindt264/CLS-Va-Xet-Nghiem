﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace Ykhoanet
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254726
        public static void RegisterBundles(BundleCollection bundles)
        {

            bundles.Add(new StyleBundle("~/bundles/CssCore").Include(
                  "~/Content/bootstrap.css",
                  "~/Content/6_XetNghiem/Master/navbar.css",
                  "~/Content/6_XetNghiem/Master/bootstrap-responsive.min.css",
                  "~/Content/themes/start/jquery-ui.start.min.css",
                  "~/Content/themes/base/base.css",
                  "~/Content/flag-icon.min.css",
                  "~/Content/6_XetNghiem/menu.css",
                  "~/Content/LoadingCSS/css-loader.css",
                  "~/Content/datetimepicker/jquery.datetimepicker.min.css",
                  "~/Content/jquery-loading-master/jquery.loading.css",
                  "~/Content/jquery.auto-complete.css")
                  

                  );
            bundles.Add(new StyleBundle("~/bundles/fontAwesome")
                  //Local font-awesome
                  //.Include("~/fonts/6_XetNghiem/font_awesome/css/font-awesome.min.css", new CssRewriteUrlTransform())
                  //server font-awesome
                  .Include("~/fonts/6_XetNghiem/font_awesome/css/font-awesome.min.server.css", new CssRewriteUrlTransform())
                  );

            bundles.Add(new StyleBundle("~/bundles/treegrid").Include("~/Content/jquery.treegrid.css"));

            bundles.Add(new StyleBundle("~/bundles/CssSite").Include("~/Content/Site.css"));

            bundles.Add(new ScriptBundle("~/bundles/JSCore").Include(
                 "~/Scripts/jquery-1.11.1.min.js",
                 "~/Scripts/bootstrap.min.js",
                 "~/Scripts/jquery-ui.min-1.11.1.js",
                 "~/Scripts/common.js",
                 "~/Scripts/bootbox.min.js",
                 "~/Scripts/jquery.bootpag.min.js",
                 "~/Content/datetimepicker/jquery.datetimepicker.js",
                 "~/Scripts/InitDatetimePicker.js",
                 "~/Scripts/jquery.cookie.js",
                 "~/Content/jquery-loading-master/jquery.loading.min.js",
                 "~/Scripts/jquery.mcautocomplete.js",
                 "~/Scripts/jquery.auto-complete.js",
                 "~/Scripts/FixAjax.js"
                 ));

            bundles.Add(new ScriptBundle("~/bundles/dangnhap").Include(
                "~/Scripts/6_XetNghiem/1_DangNhap/dangnhap.js"));

            bundles.Add(new ScriptBundle("~/bundles/capma").Include(
                "~/Scripts/6_XetNghiem/2_TiepNhan/capma.js"));

            bundles.Add(new ScriptBundle("~/bundles/ketquaxn").Include(
                "~/Scripts/6_XetNghiem/3_KetQuaXN/ketquaxn.js"));

            bundles.Add(new ScriptBundle("~/bundles/inlaikq").Include(
                "~/Scripts/6_XetNghiem/3_KetQuaXN/inlaikq.js"));

            bundles.Add(new ScriptBundle("~/bundles/dm_xetnghiem").Include(
                "~/Scripts/6_XetNghiem/dm_xetnghiem.js"));

            bundles.Add(new ScriptBundle("~/bundles/dm_mayxn").Include(
                "~/Scripts/6_XetNghiem/dm_mayxn.js"));

            bundles.Add(new ScriptBundle("~/bundles/dm_nhomxn").Include(
                "~/Scripts/6_XetNghiem/dm_nhomxn.js"));

            bundles.Add(new ScriptBundle("~/bundles/dm_sotaygotat").Include(
                "~/Scripts/6_XetNghiem/dm_sotaygotat.js"));

            bundles.Add(new ScriptBundle("~/bundles/dm_vikhuan").Include(
                "~/Scripts/6_XetNghiem/dm_vikhuan.js"));

            bundles.Add(new ScriptBundle("~/bundles/dm_khangsinh").Include(
                "~/Scripts/6_XetNghiem/dm_khangsinh.js"));

            bundles.Add(new ScriptBundle("~/bundles/dm_vkks").Include(
                "~/Scripts/6_XetNghiem/dm_vkks.js"));

            bundles.Add(new ScriptBundle("~/bundles/bctk").Include(
                "~/Scripts/6_XetNghiem/bctk.js"));

            bundles.Add(new ScriptBundle("~/bundles/dm_congthucxn").Include(
                "~/Scripts/6_XetNghiem/dm_congthucxn.js"));

            bundles.Add(new ScriptBundle("~/bundles/PhieuIn_HTML").Include(
                "~/Scripts/6_XetNghiem/PhieuIn_HTML.js"));

            BundleTable.EnableOptimizations = true;
        }
    }
}