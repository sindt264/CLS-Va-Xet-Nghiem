﻿using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.IO.Ports;
using System.Threading;
using BLL.Common;
using System.IO;

namespace WPF_Labconnected
{
    /// <summary>
    /// Interaction logic for UC_COM.xaml
    /// </summary>
    public partial class UC_COM : UserControl
    {
        private SerialPort serialport;
        private string DuLieuNhan = "";
        private string TenMay = "";
        private string IDMay = "";

        public UC_COM(SerialPort sp, string TenMay, string IDMay)
        {
            InitializeComponent();
            serialport = sp;
            this.TenMay = TenMay;
            this.IDMay = IDMay;
            serialport.ReadTimeout = 3000;
            serialport.RtsEnable = true;
            serialport.DtrEnable = true;
            //txtThongBao.IsEnabled = false;
            serialport.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            serialport.Open();

        }
        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;

            //Thread.Sleep(500);
            DuLieuNhan = sp.ReadExisting();

            List<string> l_thongbao = new List<string>();

            l_thongbao = BLL.BLL_KetQuaMay_comunication.XuLy_KetQua(DuLieuNhan, TenMay, IDMay, sp);

            if (l_thongbao.Count > 0)
                foreach (string thongbao in l_thongbao)
                {
                    xuatThongBao(thongbao);
                }

        }

        public void xuatThongBao(string thongbao)
        {

            this.Dispatcher.Invoke(() =>
            {
                txtThongBao.AppendText(DateTime.Now + ":  " + thongbao + Environment.NewLine);
                txtThongBao.ScrollToEnd();
            });
        }

        private void truyendulieu(string dulieu)
        {
            serialport.Write(dulieu);
        }

    }
}
