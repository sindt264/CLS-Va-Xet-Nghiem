﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Controls;

namespace WPF_Labconnected
{
    /// <summary>
    /// Interaction logic for UC_MSACCESS.xaml
    /// </summary>
    public partial class UC_MSACCESS : UserControl
    {
        string IDMay, duongDan, TenMay;
        public UC_MSACCESS(string duongDan, string TenMay, string IDMay)
        {
            InitializeComponent();
            this.IDMay = IDMay;
            this.TenMay = TenMay;
            this.duongDan = duongDan;
            watch();
            BLL.BLL_LuuKetNoi luukn = new BLL.BLL_LuuKetNoi("Microsoft Access", IDMay, duongDan);
            luukn.luuKetNoi();
        }

        private void xuatThongBao(string thongbao)
        {

            this.Dispatcher.Invoke(() =>
            {
                txtThongBao.AppendText(DateTime.Now + " - " + thongbao + "\n");
            });
        }

        public void watch()
        {
            try
            {
                List<string> l_path = duongDan.Split('\\').ToList();
                string path = null;
                int count = l_path.Count();
                for (int i = 0; i < count - 1; i++)
                {
                    path += l_path[i] + "\\";
                }

                FileSystemWatcher watcher = new FileSystemWatcher();
                watcher.Path = path;
                watcher.NotifyFilter = NotifyFilters.LastWrite;
                watcher.Filter = l_path[count - 1];
                watcher.Changed += new FileSystemEventHandler(OnChanged);
                watcher.EnableRaisingEvents = true;
                xuatThongBao("Kết nối tới file MS Access thông báo.");
            }
            catch (Exception)
            {
                xuatThongBao("Kết nối tới file MS Access thất bại.");
            }
        }

        private void OnChanged(object source, FileSystemEventArgs e)
        {

            //BLL.BLL_KetQuaMay_comunication kqm = new BLL.BLL_KetQuaMay_comunication();
            //List<string> l_macap = kqm.XuLy_KetQuaMS_Access(duongDan, TenMay, IDMay);
            //foreach (string macap in l_macap)
            //{
            //    xuatThongBao("Đã thêm kết quả xét nghiệm ID: " + macap);
            //}
        }
    }
}
