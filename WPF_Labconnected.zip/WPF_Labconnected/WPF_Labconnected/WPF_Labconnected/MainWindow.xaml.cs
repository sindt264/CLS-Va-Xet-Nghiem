﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using MahApps.Metro.Controls;
using System.IO.Ports;
using System.Data;
using MahApps.Metro.Controls.Dialogs;
using Microsoft.Win32;
using System.Collections.Generic;
using BLL.Common;
using System.Timers;
using System.Windows.Threading;

namespace WPF_Labconnected
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : MetroWindow
    {
        Parity parity;
        StopBits stopbits;
        string[] l_KieuKetNoi = { "COM", "TCP/IP", "Microsoft Access" };
        string[] serialPorts = SerialPort.GetPortNames();
        string[] baudrate = { "110", "300", "600", "1200", "2400", "4800", "9600", "14400", "19200", "28800", "38400", "56000", "57600", "115200", "128000", "256000", "None" };
        string[] dataBits = { "5", "6", "7", "8" };
        string[] stopBits = { "One", "OnePointFive", "Two", "None" };
        string[] parities = { "Even", "Mark", "None", "Odd", "Space" };

        DispatcherTimer timer = new DispatcherTimer();
        DispatcherTimer timerOff = new DispatcherTimer();

        //DateTime tgHetHan = new DateTime(2020, 01, 03, 07, 30, 00);//thánh Tâm
        //DateTime tgHetHan = new DateTime(2020, 01, 03, 07, 30, 00);//bình dương
        //DateTime tgHetHan = new DateTime(2018, 04, 05, 15, 33, 59);//test
        DateTime tgHetHan = new DateTime(2020, 01, 03, 07, 30, 00);//Thu Sa

        public MainWindow()
        {
            InitializeComponent();

            setTimeExpired();

            cbbKieuKetNoi.ItemsSource = l_KieuKetNoi;
            cbbKieuKetNoi.SelectedIndex = 0;
            //----------------------------------------------------------------------//
            cbbBaudrate.ItemsSource = baudrate;
            cbbDatabits.ItemsSource = dataBits;
            cbbStopbits.ItemsSource = stopBits;
            cbbParity.ItemsSource = parities;
            cbbCongKetNoi.ItemsSource = serialPorts;
            //----------------------------------------------------------------------//
            cbbBaudrate.SelectedIndex = 6;
            cbbDatabits.SelectedIndex = 3;
            cbbParity.SelectedIndex = 2;
            cbbStopbits.SelectedIndex = 0;
            cbbCongKetNoi.SelectedIndex = 0;
            //----------------------------------------------------------------------//

            //----------------------------------------------------------------------//
            btnTao_MSACCESS.IsEnabled = false;
            //----------------------------------------------------------------------//
            try
            {
                ThemMayXetNghiem();
                //----------------------------------------------------------------------//
                loadketnoi();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "YkhoaLab - Error", MessageBoxButton.OK, MessageBoxImage.Error);
                CGlobal.logError(ex, "MainWindow", "MainWindow", "");
                Application.Current.Shutdown();
            }

        }

        private void setTimeExpired()
        {
            timer.Interval = new TimeSpan(0,1,0);
            timer.Tick += new EventHandler(TimerEventProcessor);
            timer.Start();
        }

        private void TimerEventProcessor(object sender, EventArgs e)
        {
            if (DateTime.Now > tgHetHan)
            {
                setTimeTurnOff();
                //MessageBox.Show( "Hết hạn bản quyền! Vui lòng gia hạn!", "YkhoaLab - Thông báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                MessageBoxWrapper.Show("Hết hạn bản quyền! Vui lòng gia hạn!", "YkhoaLab - Thông báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                Application.Current.Shutdown();
            }
        }

        private void setTimeTurnOff()
        {
            timerOff.Interval = new TimeSpan(0, 2, 0);
            timerOff.Tick += new EventHandler(TimerEventOff);
            timerOff.Start();
        }

        private void TimerEventOff(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void loadketnoi()
        {
            BLL.BLL_LayKetNoiLuu layketnoiluu = new BLL.BLL_LayKetNoiLuu();
            List<string> l_chuoiketnoi = layketnoiluu.chuoiketnoi();
            if (l_chuoiketnoi.Count > 0)
            {
                foreach (string item in l_chuoiketnoi)
                {
                    string[] arr = item.Split('|');
                    if (arr[2] == "COM")
                    {
                        string congketnoi = arr[3];
                        string baudrate = arr[4];
                        setValueParity(arr[5]);
                        string databit = arr[6];
                        setValueStopbits(arr[7]);
                        try
                        {
                            taoketnoi_COM(arr[0], arr[1], congketnoi, baudrate, parity, databit, stopbits);
                        }
                        catch (Exception ex)
                        {
                            //thongBao("Lỗi", ex.Message);
                            MessageBox.Show(ex.Message, "YkhoaLab - Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
        }

        private void ThemMayXetNghiem()
        {
            BLL.BLL_TraDuLieuDB db = new BLL.BLL_TraDuLieuDB();
            DataTable dt = db.LayDanhSachMayXetNghiem();
            cbbMayXetNghiem.ItemsSource = dt.DefaultView;
            cbbMayXetNghiem.DisplayMemberPath = dt.Columns[1].ToString();
            cbbMayXetNghiem.SelectedValuePath = dt.Columns[0].ToString();
            cbbMayXetNghiem_msaccess.ItemsSource = dt.DefaultView;
            cbbMayXetNghiem_msaccess.DisplayMemberPath = dt.Columns[1].ToString();
            cbbMayXetNghiem_msaccess.SelectedValuePath = dt.Columns[0].ToString();
        }

        private void setValueParity(string parityText)
        {
            switch (parityText)
            {
                case "Even":
                    parity = Parity.Even;
                    break;
                case "Mark":
                    parity = Parity.Mark;
                    break;
                case "None":
                    parity = Parity.None;
                    break;
                case "Odd":
                    parity = Parity.Odd;
                    break;
                case "Space":
                    parity = Parity.Space;
                    break;
            }
        }

        private void setValueStopbits(string StopbitsText)
        {
            switch (StopbitsText)
            {
                case "One":
                    stopbits = StopBits.One;
                    break;
                case "OnePointFive":
                    stopbits = StopBits.OnePointFive;
                    break;
                case "Two":
                    stopbits = StopBits.Two;
                    break;
                case "None":
                    stopbits = StopBits.None;
                    break;
            }
        }

        private void btnThemKetNoi_Click(object sender, RoutedEventArgs e)
        {

            fl_ThemKetNoi.IsOpen = !fl_ThemKetNoi.IsOpen;

        }

        private void btnTiepTuc_Click(object sender, RoutedEventArgs e)
        {
            if (cbbKieuKetNoi.Text == "COM")
                fl_ChiTiet_ThemKetNoi_COM.IsOpen = !fl_ChiTiet_ThemKetNoi_COM.IsOpen;
            if (cbbKieuKetNoi.Text == "TCP/IP")
                fl_ChiTiet_ThemKetNoi_TCPIP.IsOpen = !fl_ChiTiet_ThemKetNoi_TCPIP.IsOpen;
            if (cbbKieuKetNoi.Text == "Microsoft Access")
                fl_ChiTiet_ThemKetNoi_MSACCESS.IsOpen = !fl_ChiTiet_ThemKetNoi_MSACCESS.IsOpen;
        }

        private void taoketnoi_COM(string idmay, string tenmay, string congketnoi, string baudrate, Parity parity, string databit, StopBits stopBits)
        {
            SerialPort sp = new SerialPort(congketnoi, int.Parse(baudrate), parity, int.Parse(databit), stopBits);
            sp.Open();
            sp.Close();
            UC_COM uc = new UC_COM(sp, tenmay, idmay);
            TabItem page = new TabItem();
            page.Header = congketnoi + " - " + tenmay;
            page.Name = congketnoi;
            page.Content = uc;
            tabControl.Items.Add(page);
            tabControl.SelectedItem = page;
            main_Grid.Background = Brushes.White;
        }

        private void btnTao_COM_Click(object sender, RoutedEventArgs e)
        {
            if (cbbMayXetNghiem.Text.Count() > 2)
            {
                try
                {
                    setValueParity(cbbParity.Text);
                    setValueStopbits(cbbStopbits.Text);
                    taoketnoi_COM(cbbMayXetNghiem.SelectedValue.ToString(), cbbMayXetNghiem.Text, cbbCongKetNoi.Text, cbbBaudrate.Text, parity, cbbDatabits.Text, stopbits);
                    string chuoiketnoi = cbbMayXetNghiem.SelectedValue + "|" +
                        cbbMayXetNghiem.Text + "|COM|" + cbbCongKetNoi.Text + "|" +
                        cbbBaudrate.Text + "|" + parity + "|" + cbbDatabits.Text + "|" + stopbits;

                    BLL.BLL_LuuKetNoi luukn = new BLL.BLL_LuuKetNoi("COM", cbbMayXetNghiem.SelectedValue.ToString(), chuoiketnoi);
                    luukn.luuKetNoi();
                }
                catch (Exception ex)
                {
                    thongBao("Lỗi", ex.Message);
                }
                finally
                {
                    fl_ChiTiet_ThemKetNoi_COM.IsOpen = !fl_ChiTiet_ThemKetNoi_COM.IsOpen;
                    fl_ThemKetNoi.IsOpen = !fl_ThemKetNoi.IsOpen;
                }
            }
            else
            {
                thongBao("Lỗi", "Bạn chưa chọn máy xét nghiệm.");
            }

        }

        private void btnDongKetNoi_Click(object sender, RoutedEventArgs e)
        {
            tabControl.Items.Remove(tabControl.SelectedItem);
        }

        private void btnDuongDan_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog theDialog = new OpenFileDialog();
            theDialog.Title = "Open MS ACCESS File";
            theDialog.Filter = "Microsoft Access Database|*.mdb";
            theDialog.InitialDirectory = @"C:\";
            Nullable<bool> result = theDialog.ShowDialog();

            if (result == true)
            {
                string filename = theDialog.FileName;
                txtDuongDan.Text = "Đường dẫn: \n" + filename;
                btnTao_MSACCESS.IsEnabled = true;
            }

        }

        private void btnTao_MSACCESS_Click(object sender, RoutedEventArgs e)
        {
            if (cbbMayXetNghiem_msaccess.Text.Count() > 2)
            {
                if (txtDuongDan.Text.Count() > 10)
                {
                    try
                    {
                        UC_MSACCESS uc = new UC_MSACCESS(txtDuongDan.Text.Remove(0, 12), cbbMayXetNghiem_msaccess.Text, ((int)cbbMayXetNghiem_msaccess.SelectedValue).ToString());
                        TabItem page = new TabItem();
                        page.Header = cbbMayXetNghiem_msaccess.Text;
                        page.Name = cbbMayXetNghiem_msaccess.Text.Replace(" ", "");
                        page.Content = uc;
                        tabControl.Items.Add(page);
                        tabControl.SelectedItem = page;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        BLL.BLL_LuuKetNoi luukn = new BLL.BLL_LuuKetNoi("Microsoft Access", ((int)cbbMayXetNghiem_msaccess.SelectedValue).ToString(), txtDuongDan.Text.Remove(0, 12));
                        main_Grid.Background = Brushes.White;
                        fl_ChiTiet_ThemKetNoi_MSACCESS.IsOpen = !fl_ChiTiet_ThemKetNoi_MSACCESS.IsOpen;
                        fl_ThemKetNoi.IsOpen = !fl_ThemKetNoi.IsOpen;
                    }
                }
                else
                {
                    thongBao("Lỗi", "Bạn chưa chọn đường dẫn đến file Microsoft Access Database.");
                }
            }
            else
            {
                thongBao("Lỗi", "Bạn chưa chọn máy xét nghiệm.");
            }
        }

        private async void thongBao(string title, string thongbao)
        {
            await this.ShowMessageAsync(title, thongbao);
        }
    }

    public class MessageBoxWrapper
    {
        public static MessageBoxResult Show(string msg, string title, MessageBoxButton buttonStyle, MessageBoxImage image)
        {
            var result = MessageBoxResult.None;

            if (Application.Current.Dispatcher.CheckAccess())
                result = MessageBox.Show(Application.Current.MainWindow, msg, title, buttonStyle, image);
            else
                Application.Current.Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                    result = MessageBox.Show(Application.Current.MainWindow, msg, title, buttonStyle, image);
                }));

            return result;
        }
    }
}
