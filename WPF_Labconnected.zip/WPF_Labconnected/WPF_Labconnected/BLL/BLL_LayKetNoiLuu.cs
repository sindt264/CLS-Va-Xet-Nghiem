﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL.Common;
using DAL;

namespace BLL
{
    public class BLL_LayKetNoiLuu
    {
        //SqlConnectionRun sqlrun = new SqlConnectionRun();
        public List<string> chuoiketnoi()
        {
            List<string> l_chuoiketnoi = new List<string>();

            string query = "select * from CanLamSang..XN_DM_MayXetNghiem mxn inner join CanLamSang..XN_DM_MayXetNghiem_ChiTiet ct on mxn.IDMayXN = ct.IDMayXN where ct.IPMac = '" + GetMacAddress.GetMACAddress() + "'";
            DataTable dt = SqlConnectionRun.LayDuLieu(query);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    if (row[2].ToString().Trim() == "COM")
                    {
                        l_chuoiketnoi.Add(row["COM"].ToString().Trim());
                    }
                    //else if (row[2].ToString().Trim() == "Microsoft Access")
                    //{
                    //    l_chuoiketnoi.Add(row["MS_Access"].ToString().Trim());
                    //}
                }
            }

            return l_chuoiketnoi;
        }
    }
}
