﻿
using DAL;
using System.Data;

namespace BLL
{
    public class BLL_TraDuLieuDB
    {
        //SqlConnectionRun sqlRun = new SqlConnectionRun();

        public bool KiemTraKetNoi()
        {
            return SqlConnectionRun.KiemTraKetNoi();
        }

        public DataTable LayDanhSachMayXetNghiem()
        {
            return SqlConnectionRun.DanhSachMayXetNghiem();
        }

        
    }
}
