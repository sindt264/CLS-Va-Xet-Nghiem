﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using System.IO;
using System.Data;
using System.Data.OleDb;

namespace BLL.MayXetNghiem.KHAC
{
    public class URIT8021A
    {
        //private SqlConnectionRun sqlRUN = new SqlConnectionRun();
        private string duongDan, IDMay;
        VariableSave vs = new VariableSave();
        int count_dt_URIT8021A_Cu = 0;

        public URIT8021A(string duongDan, string IDMay)
        {
            this.duongDan = duongDan;
            this.IDMay = IDMay;
            count_dt_URIT8021A_Cu = int.Parse(vs.LoadData().value);
        }

        public List<string> XuLy()
        {
            List<string> l_mabp = new List<string>();

            Times t = new Times();
            t = SqlConnectionRun.UpdateTimes();
            List<DataReceive> DataReceives = new List<DataReceive>();
            DataReceive DR = null;

            //----------------------------------------------------//

            DataTable dt = new DataTable();
            OleDbConnection mycon = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0 ;" +
            @"Data Source =" + duongDan +
            ";Jet OLEDB:Database Password =hanyu; Persist Security Info=False;");

            try
            {
                mycon.Open();
                string time = t.TGHienTai;

                OleDbDataAdapter myda = new OleDbDataAdapter("select ITEM, ID, RESULT, UNIT from CHECK_RESULT where ID LIKE '%" + time + "%'", mycon);
                myda.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                int count_moi = dt.Rows.Count;
                if (dt.Rows.Count > 0 && count_dt_URIT8021A_Cu != count_moi)
                {
                    for (int i = count_dt_URIT8021A_Cu; i < count_moi; i++)
                    {
                        DR = new DataReceive();
                        DR.BarcodeTest = float.Parse(dt.Rows[i][1].ToString().Substring(8)).ToString();
                        DR.DonVi = dt.Rows[i][3].ToString();
                        DR.IDMayXN = IDMay;
                        DR.KetQua = dt.Rows[i][2].ToString();
                        DR.MaDV = dt.Rows[i][0].ToString();
                        DR.NgayTraKetQua = t.TGCoKQ;
                        DR.NgayXN = t.NgayXN;
                        DR.MaBP = t.MaTG + DR.BarcodeTest;

                        DataReceives.Add(DR);
                        if (l_mabp.Contains(DR.MaBP) == false)
                            l_mabp.Add(DR.MaBP);
                    }

                    count_dt_URIT8021A_Cu = count_moi;
                    vs.SaveData(dt.Rows.Count.ToString());

                    SqlConnectionRun.ThemKetQuaXetNghiem(DataReceives);
                }               
            }
            return l_mabp;

        }
    }
}
