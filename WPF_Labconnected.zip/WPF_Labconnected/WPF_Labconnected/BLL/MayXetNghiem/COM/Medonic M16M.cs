﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using System.Data;
using System.Xml;
using System.IO;

namespace BLL.MayXetNghiem.COM
{
    public class Medonic_M16M
    {
        //private static SqlConnectionRun sqlRUN = new SqlConnectionRun();
        public static string DuLieuNhan, IDMay;

        public static List<string> XuLy()
        {
            List<string> l_macap = new List<string>();
            Times t = new Times();
            t = SqlConnectionRun.UpdateTimes();
            List<DataReceive> DataReceives = new List<DataReceive>();
            DataReceive DR;
            string _BarcodeTest = null;
            //----------------------------------------------------//
            DuLieuNhan = DuLieuNhan.Replace("\n", "");
            DataSet ds = new DataSet();
            ds.ReadXml(new XmlTextReader(new StringReader(DuLieuNhan)));
            DataTable dt = ds.Tables["p"];
            int count = dt.Rows.Count;
            for(int i = 7; i<count; i++)
            {
                if (i == 7)
                {
                    _BarcodeTest = dt.Rows[i]["v"].ToString();
                }
                if(i > 60 && i <= 79)
                {
                    DR = new DataReceive();
                    DR.BarcodeTest = _BarcodeTest;
                    DR.IDMayXN = IDMay;
                    DR.MaDV = dt.Rows[i]["n"].ToString();
                    DR.KetQua = dt.Rows[i]["v"].ToString();
                    DR.NgayTraKetQua = t.TGCoKQ;
                    DR.NgayXN = t.NgayXN;
                    DR.MaBP = t.MaTG + _BarcodeTest;

                    DataReceives.Add(DR);
                    if (l_macap.Contains(DR.MaBP) == false)
                        l_macap.Add(DR.MaBP);
                }              
            }
            //----------------------------------------------------//
            SqlConnectionRun.ThemKetQuaXetNghiem(DataReceives);
            return l_macap;
        }
    }
}
