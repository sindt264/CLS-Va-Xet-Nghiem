﻿using BLL.Common;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BLL.MayXetNghiem.COM
{
    public static class MissionU120
    {
        //private static SqlConnectionRun sqlRUN = new SqlConnectionRun();
        public static string DuLieuNhan, IDMay;
        private static string dulieudaydu = "";

        public static List<string> Xuly()
        {
            List<string> l_thongbao = new List<string>();
            if (DuLieuNhan.IndexOf(Convert.ToChar(T.ETX)) != -1)
            {
                dulieudaydu += DuLieuNhan;
                l_thongbao = Xuly_ketqua();
                dulieudaydu = "";
            }
            else
            {
                dulieudaydu += DuLieuNhan;
            }

            return l_thongbao;
        }

        private static List<string> Xuly_ketqua()
        {
            List<string> l_thongbao = new List<string>();
            try
            {
                Times t = new Times();
                t = SqlConnectionRun.UpdateTimes();
                string _BarcodeTest = "";



                //----------------------------------------------------//
                //DataReiceive = System.Text.RegularExpressions.Regex.Replace(DataReiceive, @"\s+", " ");
                List<DataReceive> l_datareceive = new List<DataReceive>();
                List<string> l_data = dulieudaydu.Split('\n').ToList();
                l_data[0] = System.Text.RegularExpressions.Regex.Replace(l_data[0], @"\s+", " ");
                _BarcodeTest = l_data[0].Split(':')[1];
                _BarcodeTest = _BarcodeTest.Trim();
                //_BarcodeTest = _BarcodeTest.Substring(2, _BarcodeTest.Length - 2);
                //_BarcodeTest = _BarcodeTest.Substring(_BarcodeTest.Length - 4, 4);

                if (_BarcodeTest.Length == 2)
                    _BarcodeTest = "0" + _BarcodeTest;
                else if (_BarcodeTest.Length == 1)
                    _BarcodeTest = "00" + _BarcodeTest;

                string mabp = t.MaTG + _BarcodeTest;

                l_thongbao.Add(mabp);
                for (int i = 4; i <= 13; i++)
                {
                    l_data[i] = System.Text.RegularExpressions.Regex.Replace(l_data[i], @"\s+", " ");
                    List<string> tam = l_data[i].Split(' ').ToList();

                    DataReceive DR = new DataReceive();
                    DR.IDMayXN = IDMay;
                    if (l_data[i].IndexOf("*") == -1)
                        DR.MaDV = tam[1];
                    else
                        DR.MaDV = tam[0];


                    if (DR.MaDV == "pH" || DR.MaDV == "SG")
                    {
                        DR.KetQua = tam[2];
                    }
                    else if (DR.MaDV == "URO")
                    {
                        DR.KetQua = tam[3];
                    }
                    else if (DR.MaDV.IndexOf("*") != -1)
                    {
                        DR.MaDV = DR.MaDV.Replace("*", "");
                        DR.KetQua = tam[2];
                        if (DR.KetQua == "pos")
                        {
                            DR.KetQua = "POSITIVE";
                        }
                    }
                    else
                    {
                        if (tam[2].IndexOf("+") != -1)
                            DR.KetQua = tam[3];
                        else
                            DR.KetQua = "NEGATIVE";
                    }


                    DR.NgayTraKetQua = t.TGCoKQ;
                    DR.NgayXN = t.NgayXN;
                    DR.MaBP = mabp;
                    DR.BarcodeTest = _BarcodeTest;

                    l_datareceive.Add(DR);

                    //if (l_thongbao.Contains(DR.MaBP) == false)
                    //    l_thongbao.Add(DR.MaBP);
                }
                SqlConnectionRun.ThemKetQuaXetNghiem(l_datareceive);
            }
            catch (Exception ex)
            {
                CGlobal.logError(ex, IDMay, "Mission U120", dulieudaydu);
                l_thongbao.Add("Lỗi: " + ex.Message);
            }
            return l_thongbao;
        }
    }
}
