﻿using BLL.Common;
using DAL;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.MayXetNghiem.COM
{
    public static class StartMax
    {
        public static string DuLieuNhan = "", IDMay = "";
        private static string dulieu_daydu = "";
        private static bool _flag = false;

        public static SerialPort serialPort;

        public static List<string> XuLy()
        {
            List<string> list = new List<string>();

            if (DuLieuNhan.Length == 1)
            {
                if (DuLieuNhan.Contains(Convert.ToChar(T.ENQ)))
                {
                    serialPort.Write(new byte[] { 0x06 }, 0, 1);
                    _flag = true;
                }
                else if (DuLieuNhan.Contains(Convert.ToChar(T.EOT)))
                {
                    list = xuly_ketqua();
                    _flag = false;
                    dulieu_daydu = "";
                    serialPort.Write(new byte[] { 0x06 }, 0, 1);
                }
            }
            else if (DuLieuNhan.IndexOf(Convert.ToChar(T.ENQ)) != -1)
                serialPort.Write(new byte[] { 0x06 }, 0, 1);

            if (_flag)
            {
                dulieu_daydu += DuLieuNhan;
                serialPort.Write(new byte[] { 0x06 }, 0, 1);
            }

            return list;
        }

        private static List<string> xuly_ketqua()
        {

            List<string> l_mabp = new List<string>();
            string GetID = "";
            try
            {
                List<string> lists = dulieu_daydu.Split(CGlobal.convertByte_toChar(T.STX)).ToList();
                GetID = clearNotUseStringGetID(lists);
                lists = clearNotUseString(lists,GetID);
                List<DataReceive> l_result = new List<DataReceive>();

                Times t = new Times();
                t = SqlConnectionRun.UpdateTimes();

                DataReceive DR = new DataReceive();
                DR.IDMayXN = IDMay;
                DR.NgayTraKetQua = t.TGCoKQ;
                DR.NgayXN = t.NgayXN;

                int count = 1;
                foreach (string item in lists)
                {
                    switch (count)
                    {
                        case 1:
                            count++;
                            DR.BarcodeTest = getID(item);
                            DR.MaBP = t.MaTG + DR.BarcodeTest;
                            if (!l_mabp.Contains(DR.MaBP))
                                l_mabp.Add(DR.MaBP);
                            break;
                        case 2:
                            string[] rs = getResult(item);
                            DR.MaDV = rs[0];
                            DR.KetQua = rs[1];
                            //---------------------------------------//
                            count = 1;
                            l_result.Add(DR);
                            DR = new DataReceive();
                            DR.IDMayXN = IDMay;
                            break;
                    }
                }
                SqlConnectionRun.ThemKetQuaXetNghiem(l_result);
            }
            catch (Exception ex)
            {
                l_mabp.Add("Lỗi! " + ex.Message + Environment.NewLine + dulieu_daydu);
                CGlobal.log_Activity("Lỗi! " + ex.Message, "StartMax", IDMay, dulieu_daydu);
            }

            return l_mabp;
        }

        private static string clearNotUseStringGetID(List<string> lists)
        {

            string GetID = "";
            foreach (string item in lists)
            {
                List<string> temp = item.Split('|').ToList();
                if (temp.Count == 8)
                {
                    if (temp[2].Length == 0 && temp[5].IndexOf('_') != -1)
                        GetID = item;
                }
            }
            return GetID;
        }
        private static List<string> clearNotUseString(List<string> lists,string GetID)
        {
            string ID = GetID;
            List<string> _r = new List<string>();
            foreach (string item in lists)
            {
                List<string> temp = item.Split('|').ToList();
                if (temp.Count > 8)
                {
                    if (temp[2].Length > 1)
                        if (isResult(temp[2]))
                            if(temp[4].ToString() != "Ref." || temp[4].ToString() != "Ratio")
                            {
                                _r.Add(GetID);
                                _r.Add(item);
                            }
                }
            }
            return _r;
        }

        private static bool isResult(string item)
        {
            List<string> temp = item.Split('^').ToList();
            if (temp[9] == "I")
                return true;
            else
                return false;
        }

        private static string getID(string input)
        {
            string result = "";
            string[] temp = input.Split('|');
            if (temp[5].IndexOf("_") != -1)
            {
                string[] check = temp[5].Split('^');
                string[] getID = check[0].Split('_');
                if (getID[1].Length == 1)
                {
                    result = "00" + getID[1].ToString();
                }
                else if (getID[1].Length == 2) {
                    result = "0" + getID[1].ToString();
                }
                else
                {
                    result = getID[1].ToString();
                }
            }
            return result;
        }
        private static string[] getResult(string input)
        {
            string result = "";
            string[] temp = input.Split('|');
            if (temp[3] == "NO RESULT")
            {
                result = "";
            }
            else
            {
                result = temp[3];
            }
            string[] temp2 = temp[2].Split('^');
            string MaDV = temp2[4]+"_"+temp[4];
            string[] rs = new string[2];
            rs[0] = MaDV;
            rs[1] = result;
            return rs;
        }
    }
}
