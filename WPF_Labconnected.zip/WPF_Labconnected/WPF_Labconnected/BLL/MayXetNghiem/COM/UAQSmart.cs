﻿using BLL.Common;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.MayXetNghiem.COM
{
    public static class UAQSmart
    {
         //private static SqlConnectionRun sqlRUN = new SqlConnectionRun();
        public static string DuLieuNhan, IDMay;
        private static string dulieudaydu = "";

        public static List<string> Xuly()
        {
            List<string> l_thongbao = new List<string>();
            //dulieudaydu += DuLieuNhan;
            //l_thongbao.Add(dulieudaydu);
            //return l_thongbao;
            dulieudaydu += DuLieuNhan;
            if (dulieudaydu.IndexOf("OP(00000000)LOT(00000000)") > -1)
            {
                l_thongbao = Xuly_ketqua();
                dulieudaydu = "";
            }
            else
            {
                //dulieudaydu += DuLieuNhan;
            }

            return l_thongbao;
        }

        private static List<string> Xuly_ketqua()
        {
            List<string> l_thongbao = new List<string>();

            try
            {
                Times t = new Times();
                t = SqlConnectionRun.UpdateTimes();
                string _BarcodeTest = "";
                //----------------------------------------------------//
                //DataReiceive = System.Text.RegularExpressions.Regex.Replace(DataReiceive, @"\s+", " ");
                List<DataReceive> l_datareceive = new List<DataReceive>();
                string check = dulieudaydu.Replace("~\r\n", "|");
                List<string> l_data = check.Split('|').ToList();
                int check2 = l_data.Count();
                for (int Total = 0; Total < check2; Total++)
                {
                    if (l_data[Total].Length > 1)
                    {
                        List<string> l_data2 = l_data[Total].Split('\n').ToList();
                        _BarcodeTest = l_data2[17].Replace(" ", "").Replace("ID(", "").Replace(")", "").Replace("\r", "");
                        string mabp = t.MaTG + _BarcodeTest;
                        string check3 = "";
                        for (int i = 4; i <= 14; i++)
                        {
                            if (l_data2[i].Length > 0)
                            {
                                check3 = l_data2[i].Replace(" "," ");
                                List<string> tam = check3.Split(' ').ToList();
                                //List<string> tam = l_data2[i].Split(' ').ToList();
                                DataReceive DR = new DataReceive();
                                DR.IDMayXN = IDMay;
                                DR.MaDV = tam[0];
                                if (DR.MaDV == "URO")
                                {
                                    DR.KetQua = tam[2].Replace("mg/dl", "");
                                }else if(DR.MaDV == "BLD")
                                {
                                    DR.KetQua = tam[2].Replace("RBC/ul", "");
                                }
                                else
                                {
                                    DR.KetQua = tam[1];
                                }
                                //if (DR.MaDV == "pH" || DR.MaDV == "S.G")
                                //{
                                //    DR.KetQua = tam[17];
                                //}
                                //else
                                //{
                                //    DR.KetQua = tam[7];
                                //}
                                DR.NgayTraKetQua = t.TGCoKQ;
                                DR.NgayXN = t.NgayXN;
                                DR.MaBP = mabp;
                                DR.BarcodeTest = _BarcodeTest;

                                l_datareceive.Add(DR);
                                if (l_thongbao.Contains(DR.MaBP) == false)
                                    l_thongbao.Add(DR.MaBP);
                            }
                        }

                    }
                }
                SqlConnectionRun.ThemKetQuaXetNghiem(l_datareceive);
            }
            catch (Exception ex)
            {
                CGlobal.logError(ex, IDMay, "UAQSmart", dulieudaydu);
                l_thongbao.Add("Lỗi: " + ex.Message);
            }
            return l_thongbao;
        }
    }
}
