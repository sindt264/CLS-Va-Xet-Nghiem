﻿using BLL.Common;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.MayXetNghiem.COM
{
    public static class EasyLyteExpand
    {
        public static string DuLieuNhan, IDMay;
        private static string dulieudaydu = "";

        public static List<string> XuLy()
        {
            List<string> l_thongbao = new List<string>();
            dulieudaydu += DuLieuNhan;
            //l_thongbao.Add(DuLieuNhan);
            try
            {
                if (dulieudaydu.IndexOf("BLOOD") > 0)
                {
                    var temp = dulieudaydu.Replace("------------------------", "|").Split('|');

                    var count = temp.Count();
                    for (int i = 0; i < count; i++)
                    {
                        if (temp[i].Contains("BLOOD"))
                        {
                            string rs = GetBetween(temp[i], "ID", "BLOOD");

                            var arr = rs.Replace("\r\n", "|").Split('|');

                            Times t = new Times();
                            t = SqlConnectionRun.UpdateTimes();

                            string macap = arr[0].Split(' ')[1];
                            macap = macap.Substring(macap.Length - 3);

                            if (macap == "000")
                            {
                                macap = arr[0].Split(' ')[1];
                                macap = macap.Substring(0, 3);
                            }
                            string mabp = t.MaTG + macap;

                            List<DataReceive> drs = new List<DataReceive>();
                            drs = GetData(drs, arr[1], macap, mabp, t.NgayXN, t.TGCoKQ, IDMay);
                            drs = GetData(drs, arr[2], macap, mabp, t.NgayXN, t.TGCoKQ, IDMay);
                            SqlConnectionRun.ThemKetQuaXetNghiem(drs);
                            l_thongbao.Add(mabp);
                        }
                    }
                    dulieudaydu = "";
                }

            }
            catch (Exception ex)
            {
                l_thongbao.Add("Lỗi! " + ex.Message + Environment.NewLine + dulieudaydu);
                CGlobal.log_Activity("Lỗi! " + ex.Message, "EasyLyteExpand", IDMay, dulieudaydu);
                //throw ex;
            }

            return l_thongbao;
        }

        private static List<DataReceive> GetData(List<DataReceive> drs, string data, string macap, string mabp, string ngayxn, string ngaytrakq, string idmay)
        {
            data = System.Text.RegularExpressions.Regex.Replace(data, @"\s+", " ");
            DataReceive dr = new DataReceive();
            var _arr = data.Split(' ');
            int count = _arr.Count();
            bool isMaDV = true;
            for (int i = 0; i < count; i++)
            {
                if (isMaDV)
                {
                    dr.IDMayXN = idmay;
                    dr.MaBP = mabp;
                    dr.MaDV = _arr[i];
                    dr.NgayTraKetQua = ngaytrakq;
                    dr.NgayXN = ngayxn;
                    dr.BarcodeTest = macap;
                    isMaDV = false;
                }
                else
                {
                    dr.KetQua = _arr[i];
                    drs.Add(dr);
                    dr = new DataReceive();
                    isMaDV = true;
                }
            }
            return drs;
        }

        private static string GetBetween(string content, string startString, string endString)
        {
            int Start = 0, End = 0;
            if (content.Contains(startString) && content.Contains(endString))
            {
                Start = content.IndexOf(startString, 0) + startString.Length;
                End = content.IndexOf(endString, Start);
                return content.Substring(Start, End - Start);
            }
            else
                return string.Empty;
        }
    }
}
