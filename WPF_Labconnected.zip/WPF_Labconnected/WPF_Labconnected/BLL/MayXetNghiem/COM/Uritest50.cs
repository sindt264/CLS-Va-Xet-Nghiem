﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL.MayXetNghiem.COM
{
    public class Uritest50
    {
        //private SqlConnectionRun sqlRUN = new SqlConnectionRun();
        private string DuLieuNhan, IDMay;

        public Uritest50(string DuLieuNhan, string IDMay)
        {
            this.DuLieuNhan = DuLieuNhan;
            this.IDMay = IDMay;
        }

        public List<string> Xuly()
        {
            List<string> l_macap = new List<string>();
            Times t = new Times();
            t = SqlConnectionRun.UpdateTimes();
            string _BarcodeTest = null;
            List<DataReceive> l_datareceive = new List<DataReceive>();
            DataReceive DR = null;
            //----------------------------------------------------//
            string DataReiceive = DuLieuNhan;
            if (!DataReiceive.Contains("TROUBLE"))
            {
                List<string> l_DataReiceive = DataReiceive.Split('\n').ToList();
                l_DataReiceive.RemoveAll(str => String.IsNullOrEmpty(str));
                int count = l_DataReiceive.Count();
                for (int i = 0; i < count; i++)
                {
                    if (i == 1)
                    {
                        string[] tam = l_DataReiceive[i].Split(' ');
                        _BarcodeTest = float.Parse(tam[0].Replace("NO.", "")).ToString();
                    }
                    if (i >= 3 && i <= 13)
                    {
                        l_DataReiceive[i] = System.Text.RegularExpressions.Regex.Replace(l_DataReiceive[i], @"\s+", " ");


                        if (i == 5 || i == 6 || i == 10 || i == 12)
                        {
                            string[] tam = l_DataReiceive[i].Replace("*", " ").Split(' ');
                            DR = new DataReceive();
                            DR.IDMayXN = IDMay;
                            DR.MaDV = tam[1];//
                            DR.KetQua = tam[2].Replace("<CR><LF>", "").Replace("umol/L", "").Replace("mmol/L", "").Replace("Cell/uL", "").Replace("g/L", "").Replace("+", "Positive").Replace("-", "Negative");
                            DR.NgayTraKetQua = t.TGCoKQ;
                            DR.NgayXN = t.NgayXN;
                            DR.MaBP = t.MaTG + _BarcodeTest;
                            DR.BarcodeTest = _BarcodeTest;

                            l_datareceive.Add(DR);
                        }
                        else
                        {
                            string[] tam = l_DataReiceive[i].Replace("*", " ").Split(' ');
                            DR = new DataReceive();
                            tam[3] = tam[3].Replace("<CR><LF>", "");
                            int j = tam[3].Count() - 1;
                            for (int m = j; m >= 0; m--)
                            {
                                if (Char.IsDigit(tam[3][m]))
                                {
                                    j = m + 1;
                                    break;
                                }
                            }
                            DR.DonVi = tam[3].Substring(j);

                            DR.IDMayXN = IDMay;
                            DR.MaDV = tam[1];//
                            DR.KetQua = tam[2] + "    " + tam[3].Replace("<CR><LF>", "").Replace("umol/L", "").Replace("mmol/L", "").Replace("Cell/uL", "").Replace("g/L", "");
                            DR.NgayTraKetQua = t.TGCoKQ;
                            DR.NgayXN = t.NgayXN;
                            DR.MaBP = t.MaTG + _BarcodeTest;
                            DR.BarcodeTest = _BarcodeTest;

                            l_datareceive.Add(DR);
                        }
                    }
                    if (l_macap.Contains(DR.MaBP) == false)
                        l_macap.Add(DR.MaBP);
                }
                SqlConnectionRun.ThemKetQuaXetNghiem(l_datareceive);
            }

            return l_macap;
        }
    }
}
