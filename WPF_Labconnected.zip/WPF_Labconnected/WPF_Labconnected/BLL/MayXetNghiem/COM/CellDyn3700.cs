﻿using BLL.Common;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BLL.MayXetNghiem.COM
{
    public static class CellDyn3700
    {
        //private static SqlConnectionRun sqlRUN = new SqlConnectionRun();
        private static string dulieudaydu = "";
        public static string dulieunhan, idmay;
        private static string[] MaDV = {"9|WBC","10|NEU","11|LYM","12|MONO","13|EOS","14|BASO","15|RBC","16|HGB","17|HCT","18|MCV","19|MCH","20|MCHC","21|RDW","22|PLT","23|MPV","26|%N","27|%L","28|%M","29|%E","30|%B" };

        public static List<string> Xuly()
        {
            dulieudaydu += dulieunhan;
            //if (dulieudaydu.Count(f => f == Convert.ToChar(T.ETX)) == 6)
            //{
            //    return Xuly_ketqua();
            //}
            if (dulieudaydu.IndexOf(Convert.ToChar(T.ETX)) != -1)
            {
                return Xuly_ketqua();
            }
            else
            {
                return new List<string>();
            }


        }

        private static List<string> Xuly_ketqua()
        {
            List<string> thongbao = new List<string>();
            try
            {
                List<DataReceive> l_datareceive = new List<DataReceive>();

                Times t = new Times();
                t = SqlConnectionRun.UpdateTimes();

                List<string> result = dulieudaydu.Split(',').ToList();
                dulieudaydu = "";
                int count = result.Count;
                

                foreach (string data in MaDV)
                {
                    DataReceive DR = new DataReceive();
                    string[] temp = data.Split('|');
                    if (result[int.Parse(temp[0])] == "-----")
                        DR.KetQua = "";
                    else
                        DR.KetQua = float.Parse(result[int.Parse(temp[0])]).ToString();

                    DR.IDMayXN = idmay;
                    DR.BarcodeTest = result[4].Replace("\"", "").Trim();
                    DR.MaDV = temp[1];
                    DR.NgayTraKetQua = t.TGCoKQ;
                    DR.NgayXN = t.NgayXN;
                    DR.MaBP = t.MaTG + DR.BarcodeTest;
                    l_datareceive.Add(DR);
                    if (!thongbao.Contains(DR.MaBP))
                        thongbao.Add(DR.MaBP);
                }
                SqlConnectionRun.ThemKetQuaXetNghiem(l_datareceive);
                
            }
            catch(Exception ex)
            {
                CGlobal.logError(ex, idmay, "CellDyn 3700", dulieudaydu);
                thongbao.Add("Lỗi: " + ex.Message);
            }
            return thongbao;
        }
    }
}
