﻿using BLL.Common;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.MayXetNghiem.COM
{
    public static class CellDyn1700
    {
        private static string dulieudaydu = "";
        public static string dulieunhan, idmay;
        private static string[] MaDV = { "16|WBC", "18|LYM", "34|LYM%", "19|MID", "35|MID%", "20|GRAN", "36|GRAN%", "22|RBC", "23|HGB", "24|HCT", "25|MCV", "26|MCH", "27|MCHC", "28|RDW", "29|PLT", "30|MPV", "31|PCT", "32|PDW" };

        public static List<string> Xuly()
        {
            dulieudaydu += dulieunhan;
            //if (dulieudaydu.Count(f => f == Convert.ToChar(T.ETX)) == 6)
            //{
            //    return Xuly_ketqua();
            //}
            if (dulieudaydu.IndexOf(Convert.ToChar(T.ETX)) != -1)
            {
                return Xuly_ketqua();
            }
            else
            {
                return new List<string>();
            }


        }

        private static List<string> Xuly_ketqua()
        {
            List<string> thongbao = new List<string>();
            try
            {
                List<DataReceive> l_datareceive = new List<DataReceive>();

                Times t = new Times();
                t = SqlConnectionRun.UpdateTimes();

                List<string> result = dulieudaydu.Replace("\"", "").Split(',').ToList();
                dulieudaydu = "";
                int count = result.Count;


                foreach (string data in MaDV)
                {
                    DataReceive DR = new DataReceive();
                    string[] temp = data.Split('|');
                    string test = "";
                    if (result[int.Parse(temp[0])] == "-----")
                    {
                        DR.KetQua = "";
                    }
                    else {
                        if (temp[0] =="22" || temp[0] == "31")
                        {
                            test = (float.Parse(result[int.Parse(temp[0])]) / 100).ToString();
                            DR.KetQua = test.Replace(",", ".").ToString();
                        }
                        else if (temp[0] == "29")
                        {
                            test = float.Parse(result[int.Parse(temp[0])]).ToString();
                            DR.KetQua = test.Replace(",", ".").ToString();
                        }
                        else
                        {
                            test = (float.Parse(result[int.Parse(temp[0])]) / 10).ToString();
                            if (test.IndexOf(',') == -1)
                            {
                                DR.KetQua = test.ToString() + ".0";
                            }
                            else
                            {
                                DR.KetQua = test.Replace(",", ".").ToString();
                            }
                        }
                    }

                    DR.IDMayXN = idmay;
                    string ID = result[8].Replace("\"","").Replace(" ", "").Trim();
                    if (ID.Length == 1)
                    {
                        DR.BarcodeTest = "00" + result[8].Trim();
                    }
                    else if (ID.Length == 2)
                    {
                        DR.BarcodeTest = "0" + result[8].Trim();
                    }
                    else
                    {
                        DR.BarcodeTest = result[8].Trim();
                    }
                    
                    DR.MaDV = temp[1];
                    DR.NgayTraKetQua = t.TGCoKQ;
                    DR.NgayXN = t.NgayXN;
                    DR.MaBP = t.MaTG + DR.BarcodeTest;
                    l_datareceive.Add(DR);
                    if (!thongbao.Contains(DR.MaBP))
                        thongbao.Add(DR.MaBP);
                }
                SqlConnectionRun.ThemKetQuaXetNghiem(l_datareceive);

            }
            catch (Exception ex)
            {
                CGlobal.logError(ex, idmay, "CellDyn 1700", dulieudaydu);
                thongbao.Add("Lỗi: " + ex.Message);
            }
            return thongbao;
        }
    }
}
