﻿using BLL.Common;
using DAL;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;

namespace BLL.MayXetNghiem.COM
{


    public static class CDRuby
    {
        //private static SqlConnectionRun sqlRUN = new SqlConnectionRun();
        public static string DuLieuNhan, IDMay;

        private static string dulieu_daydu = "";

        public static SerialPort serialPort;
        private static bool _flag = false;

        //set data send 3 bit
        public static List<string> XuLy()
        {

            List<string> list = new List<string>();

            if (DuLieuNhan.IndexOf(Convert.ToChar(T.ENQ)) != -1 || DuLieuNhan.IndexOf(Convert.ToChar(T.EOT)) != -1)
            {
                serialPort.Write(new byte[] { 0x06 }, 0, 1);
                //CGlobal.log_Activity("Recived ENQ/EOT", "CellDyn Ruby", IDMay, DuLieuNhan);
            }
            else if (DuLieuNhan.IndexOf(Convert.ToChar(T.STX)) != -1)
            {
                _flag = true;
            }

            if (_flag)
            {
                dulieu_daydu += DuLieuNhan;
                //CGlobal.log_Activity("Begin recive data", "CellDyn Ruby", IDMay, DuLieuNhan);
            }

            if(DuLieuNhan.IndexOf(Convert.ToChar(T.ETX)) != -1)
            {
                _flag = false;
                //CGlobal.log_Activity("End recive data", "CellDyn Ruby", IDMay, dulieu_daydu);
                list = Xuly_ketqua();
                dulieu_daydu = "";
                serialPort.Write(new byte[] { 0x06 }, 0, 1);
                //CGlobal.log_Activity("Process completed ID: " + string.Join(", ", list.ToArray()), "CellDyn Ruby", IDMay, "");
            }
            return list;
        }

        public static List<string> Xuly_ketqua()
        {
            List<string> list = new List<string>();
            try
            {
                //if (dulieu_daydu.Length > 50)
                //{
                Times t = new Times();
                t = SqlConnectionRun.UpdateTimes();
                List<DataReceive> l_datareceive = new List<DataReceive>();

                string _BarcodeTest = "";

                string[] temp = dulieu_daydu.Split('\n');

                string[] strArray = temp[0].Split('\r');

                string mabp = "";


                if (strArray.Length >= 18)
                {
                    string[] strGetResult = new string[4];
                    string[] tempBarcodeTest = strArray[2].Split('|');
                    //if (tempBarcodeTest[0] == "O")
                    //{
                    _BarcodeTest = tempBarcodeTest[2];
                    if (_BarcodeTest.Contains("^"))
                        _BarcodeTest = _BarcodeTest.Split('^')[0];
                    mabp = t.MaTG + _BarcodeTest;
                    list.Add(mabp);
                    //}
                    for (int i = 3; i <= 24; i++)
                    {
                        if (strArray[i] == "") continue;
                        strGetResult = GetResultOfCDRuby(strArray[i]);
                        DataReceive DR = new DataReceive();
                        DR.IDMayXN = IDMay;
                        DR.KetQua = strGetResult[3];
                        DR.Index = strGetResult[1];
                        DR.MaDV = strGetResult[2];

                        DR.NgayTraKetQua = t.TGCoKQ;
                        DR.NgayXN = t.NgayXN;
                        DR.MaBP = t.MaTG + _BarcodeTest;
                        DR.BarcodeTest = _BarcodeTest;
                        l_datareceive.Add(DR);

                        //if (list.Contains(DR.MaBP) == false)
                        //    list.Add(DR.MaBP);
                    }
                    SqlConnectionRun.ThemKetQuaXetNghiem(l_datareceive);
                }
                //}
            }
            catch (Exception ex)
            {
                CGlobal.logError(ex, IDMay, "CellDyn Ruby", dulieu_daydu);
                list.Add("Lỗi: " + ex.Message);
            }
            return list;
        }

        private static string[] GetResultOfCDRuby(string OrginalResult)
        {
            string[] strArray = OrginalResult.Split('|');
            string[] strResult = new string[4];
            //double testConvert;
            if (strArray.Length >= 13)
            {
                string tempIDXN = strArray[2].Replace("^^^", "-");
                string[] tempSplitIDXN = tempIDXN.Split('-');
                strResult[0] = strArray[11].Substring(0, 8);
                strResult[1] = strArray[1];
                strResult[2] = tempSplitIDXN[2];
                //if (double.TryParse(strArray[3], out testConvert))
                    //strResult[3] = double.Parse(strArray[3]).ToString();
                //else
                    strResult[3] = strArray[3];
            }
            return strResult;
        }
    }
}
