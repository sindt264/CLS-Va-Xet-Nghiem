﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.MayXetNghiem.COM
{
    public class Urit3000Plus
    {
        //private SqlConnectionRun sqlRUN = new SqlConnectionRun();
        private string DuLieuNhan, IDMay;

        public Urit3000Plus(string DuLieuNhan, string IDMay)
        {
            this.DuLieuNhan = DuLieuNhan;
            this.IDMay = IDMay;
        }

        public List<string> XuLy()
        {
            List<string> l_macap = new List<string>();
            Times t = new Times();
            t = SqlConnectionRun.UpdateTimes();
            List<DataReceive> DataReceives = new List<DataReceive>();
            DataReceive DR = null;
            string _BarcodeTest = null;
            //----------------------------------------------------//
            string DataReiceive = DuLieuNhan;
            List<string> l_DataReiceive = DataReiceive.Split('\n').ToList();
            l_DataReiceive.RemoveAll(x => x == null);
            int count = l_DataReiceive.Count();

            for (int i = 0; i < count; i++)
            {
                if (i == 2)// lấy mã barcode
                {
                    string tam = l_DataReiceive[3];
                    tam = tam.Replace("||", "|");
                    List<string> l_tam = tam.Split('|').ToList();
                    _BarcodeTest = float.Parse(l_tam[2]).ToString();
                }
                if (i >= 4 && i <= 24)// chỉ số từ dòng thứ 4 tới dòng thứ 24
                {
                    string[] tam = l_DataReiceive[i].Split('|');
                    DR = new DataReceive();
                    DR.IDMayXN = IDMay;
                    if (tam[3].Contains("_"))//nếu gặp mã dịch vụ có dấu _ thì chuyển thành -
                        tam[3] = tam[3].Replace("_", "-");
                    DR.MaDV = tam[3];
                    DR.KetQua = tam[5];
                    DR.DonVi = tam[6];
                    DR.NgayTraKetQua = t.TGCoKQ;
                    DR.NgayXN = t.NgayXN;
                    DR.MaBP = t.MaTG + _BarcodeTest;
                    DR.BarcodeTest = _BarcodeTest;

                    DataReceives.Add(DR);
                }

                if (l_macap.Contains(DR.MaBP) == false)
                    l_macap.Add(DR.MaBP);
            }
            SqlConnectionRun.ThemKetQuaXetNghiem(DataReceives);
            return l_macap;
        }
    }
}
