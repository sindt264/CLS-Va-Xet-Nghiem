﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using BLL.Common;
using DAL;

namespace BLL
{
    public class BLL_LuuKetNoi
    {
        private string kieuKetNoi;
        private string IDMay;
        private string chuoiketnoi;

        //private SqlConnectionRun sqlrun = new SqlConnectionRun();

        public BLL_LuuKetNoi(string kieuKetNoi, string IDMay, string chuoiketnoi)
        {
            this.kieuKetNoi = kieuKetNoi;
            this.IDMay = IDMay;
            this.chuoiketnoi = chuoiketnoi;
        }

        public void luuKetNoi()
        {
            if (SqlConnectionRun.kiemtrakiemtraKetNoiDaLuu(IDMay) == false)
            {
                string query = "";
                switch (kieuKetNoi)
                {
                    case "COM":
                        query = "insert into CanLamSang..XN_DM_MayXetNghiem_ChiTiet(IDMayXN, COM, IPMac) values ('" + IDMay + "','" + chuoiketnoi + "', '"+ GetMacAddress.GetMACAddress() +"')";
                        break;
                    case "TCP":
                        query = "insert into CanLamSang..XN_DM_MayXetNghiem_ChiTiet(IDMayXN, TCP, IPMac) values ('" + IDMay + "','" + chuoiketnoi + "', '" + GetMacAddress.GetMACAddress() + "')";
                        break;
                    case "Microsoft Access":
                        query = "insert into CanLamSang..XN_DM_MayXetNghiem_ChiTiet(IDMayXN, MS_Access, IPMac) values ('" + IDMay + "','" + chuoiketnoi + "', '" + GetMacAddress.GetMACAddress() + "')";
                        break;
                    case "USB":
                        query = "insert into CanLamSang..XN_DM_MayXetNghiem_ChiTiet(IDMayXN, USB, IPMac) values ('" + IDMay + "','" + chuoiketnoi + "', '" + GetMacAddress.GetMACAddress() + "')";
                        break;

                }
                SqlConnectionRun.ThucHienTruyVan(query);
            }
        }




    }
}
