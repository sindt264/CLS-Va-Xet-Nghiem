﻿
using System.Collections.Generic;
using System.IO.Ports;
using BLL.MayXetNghiem.COM;
using BLL.MayXetNghiem.KHAC;

namespace BLL
{
    public static class BLL_KetQuaMay_comunication
    {
        //MS Access
        public static List<string> XuLy_KetQuaMS_Access(string duongDan, string TenMay, string IDMay)
        {
            List<string> l_thongbao = new List<string>();
            switch (TenMay)
            {
                case "PLKPPC125":
                   
                    break;
                case "HeadWay HUBT-20P":

                    break;
            }
            return l_thongbao;
        }
        //giao tiếp 1 chiều
        public static List<string> XuLy_KetQua(string DuLieuNhan, string TenMay, string IDMay)
        {
            List<string> l_thongbao = new List<string>();
            switch (TenMay)
            {
                case "Mission U120":
                    MissionU120.DuLieuNhan = DuLieuNhan;
                    MissionU120.IDMay = IDMay;
                    l_thongbao = MissionU120.Xuly();
                    break;
                case "Medonic M16M":
                    Medonic_M16M.DuLieuNhan = DuLieuNhan;
                    Medonic_M16M.IDMay = IDMay;
                    l_thongbao = Medonic_M16M.XuLy();
                    break;
                case "EasyLyteExpand":
                    EasyLyteExpand.DuLieuNhan = DuLieuNhan;
                    EasyLyteExpand.IDMay = IDMay;
                    l_thongbao = EasyLyteExpand.XuLy();
                    break;
            }
            return l_thongbao;
        }

        //có giao tiếp 2 chiều
        public static List<string> XuLy_KetQua(string DuLieuNhan, string TenMay, string IDMay, SerialPort serialPort)
        {
            List<string> l_thongbao = new List<string>();
            switch (TenMay)
            {
                case "Abbott ci4100":
                    Ci4000.IDMay = IDMay;
                    Ci4000.DuLieuNhan = DuLieuNhan;
                    Ci4000.serialPort = serialPort;
                    l_thongbao = Ci4000.XuLy();
                    break;
                case "Cell-Dyn Ruby":
                    CDRuby.DuLieuNhan = DuLieuNhan;
                    CDRuby.IDMay = IDMay;
                    CDRuby.serialPort = serialPort;
                    l_thongbao = CDRuby.XuLy();
                    break;
                case "Mission U120":
                    MissionU120.DuLieuNhan = DuLieuNhan;
                    MissionU120.IDMay = IDMay;
                    l_thongbao = MissionU120.Xuly();
                    break;
                case "Cell Dyn 4700":
                    CellDyn3700.dulieunhan = DuLieuNhan;
                    CellDyn3700.idmay = IDMay;
                    l_thongbao = CellDyn3700.Xuly();
                    break;
                    //------------------26/12/2018------------------
                    //-----------------------StartMax----------------------
                case "StartMax":
                    StartMax.IDMay = IDMay;
                    StartMax.DuLieuNhan = DuLieuNhan;
                    StartMax.serialPort = serialPort;
                    l_thongbao = StartMax.XuLy();
                    break;
                case "Cell Dyn 1700":
                    CellDyn1700.dulieunhan = DuLieuNhan;
                    CellDyn1700.idmay = IDMay;
                    l_thongbao = CellDyn1700.Xuly();
                    break;
                case "YumizenH500":
                    YumizenH500.DuLieuNhan = DuLieuNhan;
                    YumizenH500.IDMay = IDMay;
                    YumizenH500.serialPort = serialPort;
                    l_thongbao = YumizenH500.XuLy();
                    break;
                case "UAQSmart":
                    UAQSmart.DuLieuNhan = DuLieuNhan;
                    UAQSmart.IDMay = IDMay;
                    l_thongbao = UAQSmart.Xuly();
                    break;
            }
            return l_thongbao;
        }
        
    }
}
