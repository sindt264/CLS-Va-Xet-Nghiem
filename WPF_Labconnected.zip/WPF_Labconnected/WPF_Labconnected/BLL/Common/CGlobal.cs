﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Common
{
    public static class CGlobal
    {
        public static char convertByte_toChar(byte b)
        {
            return Convert.ToChar(b);
        }
        public static string getDirectory()
        {
            string path = System.Reflection.Assembly.GetEntryAssembly().Location;
            string[] temp = path.Split('\\');
            int count = temp.Count() - 1;
            path = "";
            for (int i = 0; i < count; i++)
            {
                path += temp[i] + "\\";
            }
            return path;
        }

        public static void logError(Exception ex, string IDmay, string teMay, string dulieu)
        {
            //string filePath = @"C:\Error.txt";
            string filePath = getDirectory() + "\\error.txt";

            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine("Message :" + ex.Message + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                   "" + Environment.NewLine + "Date :" + DateTime.Now.ToString() + Environment.NewLine + "IDMayXn: " + IDmay + "   Tên máy: " + teMay + Environment.NewLine + "Data:" + Environment.NewLine + dulieu);
                writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
            }
        }
        public static void logError(string errorMess, string tenMay, string IDmay, string Dulieu)
        {
            string filePath = getDirectory() + "\\log\\error.txt";

            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine("Message :" + errorMess + Environment.NewLine + 
                   "" + Environment.NewLine + "Date :" + DateTime.Now.ToString() + Environment.NewLine + "IDMayXn: " + IDmay + "   Tên máy: " + tenMay + Environment.NewLine + "Data:" + Environment.NewLine + Dulieu);
                writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
            }
        }

        public static void log_Activity(string data, string tenmay, string idmay, string dulieu)
        {
            string filePath = getDirectory() + "\\log\\log_"+tenmay+".txt";
            if (!File.Exists(filePath))
            {
                File.Create(filePath);

            }
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine(DateTime.Now.ToString() + "\t" + "Name: " + tenmay + "\t" + "ID: " + idmay + Environment.NewLine
                    + "Activity: " + data + Environment.NewLine
                    + "Data: " + Environment.NewLine + dulieu + Environment.NewLine
                    + "====================================================================="
                    + Environment.NewLine);
            }
        }

    }
}
