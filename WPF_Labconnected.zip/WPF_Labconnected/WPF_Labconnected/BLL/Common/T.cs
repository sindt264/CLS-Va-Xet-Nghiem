﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Common
{
    public class T
    {
        public const byte ENQ = 5;
        public const byte ACK = 6;
        public const byte NAK = 21;
        public const byte EOT = 4;
        public const byte ETX = 3; //end
        public const byte ETB = 23;
        public const byte STX = 2; //start
        public const byte HASH = 23; //#
        public const byte CR = 13; //break line, \n
        public const byte LF = 10; //New line
        public const byte SYN = 22; //Synchronous idle
        public const byte ExclamationMark = 21; //1
        public static byte[] ACK_BUFF = { ACK };
        public static byte[] ENQ_BUFF = { ENQ };
        public static byte[] NAK_BUFF = { NAK };
        public static byte[] EOT_BUFF = { EOT };
        public static byte[] ETX_BUFF = { ETX };
        public static byte[] STX_BUFF = { STX };
        public static byte[] ETB_BUFF = { ETB };
        public static byte[] CR_BUFF = { CR };
        public static byte[] LF_BUFF = { LF };
        public static byte[] SYN_BUFF = { SYN };
    }
}
