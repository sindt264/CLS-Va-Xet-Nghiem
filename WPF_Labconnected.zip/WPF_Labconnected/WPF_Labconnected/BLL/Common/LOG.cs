﻿using System;
using System.Collections.Generic;
using System.IO;
using DAL;

namespace BLL.Common
{
    public class LOG
    {
        private List<DataReceive> l_datareceived = new List<DataReceive>();

        public LOG( List<DataReceive> l_datareceived)
        {
            this.l_datareceived = l_datareceived;
        }

        

        public void writeLOG()
        {
            
        }
    }
}
