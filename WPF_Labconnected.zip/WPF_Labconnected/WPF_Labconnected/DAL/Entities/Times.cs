﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public class Times
    {
        public string MaTG { get; set; }
        public string NgayXN { get; set; }
        public string TGCoKQ { get; set; }
        public string TGHienTai { get; set; }
        public Times()
        {
            MaTG = string.Format("{0:yyMMdd_}", DateTime.Now);
            NgayXN = string.Format("{0:yyyy-MM-dd 00:00:00}", DateTime.Now);
            TGCoKQ = string.Format("{0:yyyy-MM-dd HH:mm:ss}", DateTime.Now);
            TGHienTai = string.Format("{0:yyyyMMdd}", DateTime.Now);
        }
        public Times(string _matg, string _ngayxn, string _tgcokq, string _tghientai)
        {
            MaTG = _matg;
            NgayXN = _ngayxn;
            TGCoKQ = _tgcokq;
            TGHienTai = _tghientai;
        }
    }
}
