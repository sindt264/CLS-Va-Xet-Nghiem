﻿using System;
using System.IO;
using System.Collections;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Linq;

namespace DAL
{
    public class VariableSave
    {
        public void SaveData(string value)
        {
            Times t = new Times();
            // Create a hashtable of values that will eventually be serialized.
            Hashtable machine_lab = new Hashtable();
            machine_lab.Add(t.TGHienTai ,  value);


            // To serialize the hashtable and its key/value pairs,   
            // you must first open a stream for writing.  
            // In this case, use a file stream.
            FileStream fs = new FileStream("DataFile.dat", FileMode.Create);

            // Construct a BinaryFormatter and use it to serialize the data to the stream.
            BinaryFormatter formatter = new BinaryFormatter();
            try
            {
                formatter.Serialize(fs, machine_lab);
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Failed to serialize. Reason: " + e.Message);
                throw;
            }
            finally
            {
                fs.Close();
            }
        }

        public OJ_VariableSave LoadData()
        {
            var table = new Hashtable();

            table.Add(1, "a");
            table.Add(2, "b");
            table.Add(3, "c");


            var dict = table.Cast<DictionaryEntry>().ToDictionary(d => d.Key, d => d.Value);

            Times t = new Times();
            // Declare the hashtable reference.
            Hashtable machine_lab = null;

            // Open the file containing the data that you want to deserialize.
            FileStream fs = new FileStream("DataFile.dat", FileMode.Open);
            
            try
            {
                BinaryFormatter formatter = new BinaryFormatter();

                // Deserialize the hashtable from the file and  
                // assign the reference to the local variable.
                machine_lab = (Hashtable)formatter.Deserialize(fs);
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Failed to deserialize. Reason: " + e.Message);
                //throw;
            }
            finally
            {
                fs.Close();
            }

            // To prove that the table deserialized correctly,  
            // display the key/value pairs. 
            OJ_VariableSave oj = new OJ_VariableSave();
            try
            {
                var dic = machine_lab.Cast<DictionaryEntry>().ToDictionary(d => d.Key, d => d.Value);
                int count = dic.Count;
                if (count > 0)
                {
                    oj.key = dic.Last().Key.ToString();
                    if (oj.key != t.TGHienTai)
                    {
                        oj.value = "" + 0;
                        File.WriteAllText("DataFile.dat", string.Empty);
                    }
                    else
                    {
                        oj.value = dic.Last().Value.ToString();
                    }
                }
                
            }
            catch(Exception)
            {
                oj.key = t.TGHienTai;
                oj.value = "" + 0;
            }

            return oj;
        }
         

    }
}
