﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public class OJ_VariableSave
    {
        public string key { get; set; }
        public string value { get; set; }
    }
}
