﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public class DataReceive
    {
       public string BarcodeTest { get; set; }
       public string Index { get; set; }
       public string MaDV { get; set; }
       public string KetQua { get; set; }
       public string DonVi { get; set; }
       public string IDMayXN { get; set; }
       public string MaBP { get; set; }
       public string NgayXN { get; set; }
       public string NgayTraKetQua { get; set; }
       //public DateTime TGMayTraKQ { get; set; }
       public DataReceive()
       {
           BarcodeTest = "";
           Index = "0";
           MaDV = "";
           KetQua = "";
           DonVi = "";
           MaBP = "";
           IDMayXN = "";
       }
    }
}
