﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;

namespace DAL
{
    public static class SqlConnectionRun
    {
        //string sql = "server=103.48.195.41,1433;database=CanLamSang;uid=sa;pwd=ykhoanet";//Galant
        //private static string sql = @"server=TNBD-HIS-DB01\YKHOANET;database=CanLamSang;uid=sa;pwd=bvdktnBD@151sql";//Bình Dương Cây Dừa
        //private static string sql = @"server=DESKTOP-CQ5U9NN\SQLEXPRESS;database=CanLamSang;uid=sa;pwd=ykhoanet";//Local
        //private static string sql = @"server=192.168.0.250;database=CanLamSang;uid=ykhoasql;pwd=ykn@TT@2018";//Thánh tâm
        //private static string sql = @"server=192.168.1.100;database=CanLamSang;uid=ykhoasql;pwd=ykn@TT@2018";//Thu sa
        private static string sql = @"server=192.168.1.101;database=CanLamSang;uid=ykhoasql;pwd=ykn@TT@2018";//pHUC tAM


        private static SqlConnection sqlConnection = null;

        private static string query_not_complete = "";

        public static void KetNoi()
        {
            sqlConnection = new SqlConnection(sql);
            sqlConnection.Open();
        }

        public static bool KiemTraKetNoi()
        {
            sqlConnection = new SqlConnection(sql);
            try
            {
                sqlConnection.Open();
                sqlConnection.Close();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static void ThemKetQuaXetNghiem(List<DataReceive> l_datareceive)
        {
            string query = "";
            if (query_not_complete != "")
                ThucHienTruyVan(query_not_complete);
            foreach (DataReceive dr in l_datareceive)
            {
                query += "INSERT INTO CanLamSang..XN_TM_KQ_May(TrangThaiKQ, IDMayXN, MaBP, MaXN, MaMay, MaCap, KetQua, DonVi, NgayXN, TGCoKQ) VALUES" +
                    "('NEW','" + dr.IDMayXN + "', '" + dr.MaBP + "', '', '" + dr.MaDV + "', '" + dr.BarcodeTest + "', '" + dr.KetQua + "', '" + dr.DonVi + "', '', GETDATE()); ";
            }
            if (query != "")
                ThucHienTruyVan(query);
        }

        public static DataTable DanhSachMayXetNghiem()
        {
            DataTable dt = new DataTable();
            string query = "select IDMayXN, TenMayXN from CanLamSang..XN_DM_MayXetNghiem";
            dt = LayDuLieu(query);
            return dt;
        }

        public static Times UpdateTimes()
        {
            string sql = "exec CanLamSang..sp_XN_LayThoiGianCS3";
            DataTable dt = LayDuLieu(sql);
            Times t = null;
            foreach (DataRow row in dt.Rows)
            {
                t = new Times();
                t.MaTG = row["MaTG"].ToString();
                t.NgayXN = row["NgayXN"].ToString();
            }
            return t;
        }


        public static bool kiemtrakiemtraKetNoiDaLuu(string IDMay)
        {
            string query = "select * from XN_DM_MayXetNghiem_ChiTiet where IDMayXN='" + IDMay + "'";
            DataTable dt = LayDuLieu(query);
            if (dt.Rows.Count > 1)
                return true;
            else
                return false;
        }

        //-----------------------------------------------------------------------------------------------------------//

        public static DataTable LayDuLieu(string query)
        {
            DataTable dt = new DataTable();
            KetNoi();
            SqlCommand cmd;
            cmd = sqlConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = query;
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dt);
            sqlConnection.Close();
            return dt;
        }

        public static void ThucHienTruyVan(string query)
        {
            try
            {
                KetNoi();
                SqlCommand cmd;
                cmd = sqlConnection.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                if(ex.Message.IndexOf("server") != -1)
                {
                    query_not_complete = query;
                    resend_Result();
                }
                logError(ex.Message, "SQL_RUN", "Push Results Failed", query);                
            }
            sqlConnection.Close();
        }
        private static void resend_Result()
        {
            System.Timers.Timer timer = new System.Timers.Timer();
            timer.Interval = 3000;
            timer.Elapsed += timer_Elapsed;
            timer.Start();
        }
        static void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            System.Timers.Timer timer = (System.Timers.Timer)sender;
            timer.Elapsed -= timer_Elapsed;
            timer.Close();
            timer.Dispose();
            ThucHienTruyVan(query_not_complete);
        }

        public static void logError(string errorMess, string tenMay, string IDmay, string Dulieu)
        {
            string filePath = getDirectory() + "\\log\\error.txt";

            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine("Message :" + errorMess + Environment.NewLine +
                   "" + Environment.NewLine + "Date :" + DateTime.Now.ToString() + Environment.NewLine + "IDMayXn: " + IDmay + "   Tên máy: " + tenMay + Environment.NewLine + "Data:" + Environment.NewLine + Dulieu);
                writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
            }
        }
        public static string getDirectory()
        {
            string path = System.Reflection.Assembly.GetEntryAssembly().Location;
            string[] temp = path.Split('\\');
            int count = temp.Count() - 1;
            path = "";
            for (int i = 0; i < count; i++)
            {
                path += temp[i] + "\\";
            }
            return path;
        }
    }
}
