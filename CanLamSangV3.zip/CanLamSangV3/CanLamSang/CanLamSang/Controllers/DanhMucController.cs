﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CanLamSang.Models;
using Newtonsoft.Json;
namespace CanLamSang.Controllers
{
    public class DanhMucController : Controller
    {
        // GET: DanhMuc
        public ActionResult QuanLyDanhMuc()
        {
            return View();
        }
        //Thuộc tính trong Store 
        //-id(nvarchar) : mã sinh sau khi insert(Lưu ý: nếu insert thì Auto, Update thì Convert thành int vì ID là int identity)
        //-KhuVuc(varchar): nhóm khoa
        //-LoaiDanhMuc(nvarchar): (ví dụ: viết tắt là VT)
        //-TenDanhMuc(nvarchar): là mã viết tắt , tên tai biến, vùng chup,tên thuốc
        //-LoaiThuoc: danh cho vật tư y tế
        [HttpPost]
        public string dbThemDM(string ID, string Loai, string TenDanhMuc, string NoiDung, string KetLuan, string LoaiThuoc)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"sp_CLS_DanhMuc_Them";
            db.addParameter("id", SqlDbType.NVarChar, ID);
            db.addParameter("NhomChuyenKhoa", SqlDbType.NVarChar, Session[cSessionName.NhomChuyenKhoa].ToString());
            db.addParameter("ChuyenKhoa", SqlDbType.NVarChar, Session[cSessionName.ChuyenKhoa].ToString());
            db.addParameter("NhomDichVu", SqlDbType.NVarChar, Session[cSessionName.NhomDichVu].ToString());
            db.addParameter("LoaiDanhMuc", SqlDbType.NVarChar, Loai);
            db.addParameter("TenDanhMuc", SqlDbType.NVarChar, TenDanhMuc);
            db.addParameter("SlThuoc", SqlDbType.NVarChar, LoaiThuoc);//---Số lượng thuốc
            db.addParameter("NoiDung", SqlDbType.NVarChar, NoiDung);
            db.addParameter("KetLuan", SqlDbType.NVarChar, KetLuan);
            db.addParameter("NguoiThayDoi", SqlDbType.NVarChar, Session[cSessionName.username].ToString());
            return db.excuteStoreStringJson();
        }

        [HttpPost]
        public string dbLoadDM(string Loai)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"sp_CLS_DanhMuc_Get";
            db.addParameter("NhomChuyenKhoa", SqlDbType.NVarChar, Session[cSessionName.NhomChuyenKhoa].ToString());
            db.addParameter("ChuyenKhoa", SqlDbType.NVarChar, Session[cSessionName.ChuyenKhoa].ToString());
            db.addParameter("NhomDichVu", SqlDbType.NVarChar, Session[cSessionName.NhomDichVu].ToString());
            db.addParameter("LoaiDanhMuc", SqlDbType.NVarChar, Loai);
            return db.excuteStoreStringJson();
        }

        [HttpPost]
        public string dbXoaDM(string ID, string Loai)
        {
            cDBAccess act = new cDBAccess();
            act.sqlQuery = @"sp_CLS_DanhMuc_Xoa";
            act.addParameter("IDDanhMuc", SqlDbType.NVarChar, ID);
            act.addParameter("LoaiDanhMuc", SqlDbType.NVarChar, Loai);
            act.addParameter("NguoiThayDoi", SqlDbType.NVarChar, Session[cSessionName.username].ToString());
            return act.excuteStoreStringJson();
        }
        [HttpPost]
        public string dbLoadDM_VTYT()
        {
            cDBAccess act = new cDBAccess();
            act.sqlQuery = @"Select ID,TenDM from CanLamSang..CLS_ChungLoaiHangHoa where NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and isnull(ChuyenKhoa,'') = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and isnull(NhomDichVu,'') = '" + Session[cSessionName.NhomDichVu].ToString() + "'";
            return act.excuteQueryStringJson();
        }
        [HttpPost]
        public string dbThemLoaiDMVTYT(string TenDM, string ID)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"sp_CLS_VTYT_DM_ThemSua";
            db.addParameter("NhomChuyenKhoa", SqlDbType.NVarChar, Session[cSessionName.NhomChuyenKhoa].ToString());
            db.addParameter("ChuyenKhoa", SqlDbType.NVarChar, Session[cSessionName.ChuyenKhoa].ToString());
            db.addParameter("NhomDichVu", SqlDbType.NVarChar, Session[cSessionName.NhomDichVu].ToString());
            db.addParameter("ID", SqlDbType.NVarChar, ID);
            db.addParameter("TenDM", SqlDbType.NVarChar, TenDM);
            return db.excuteStoreStringJson();
        }

        [HttpPost]
        public string dbLoadVTYT()
        {
            cDBAccess act = new cDBAccess();
            act.sqlQuery = @"select vt.id, Ten,TenDM,DonVi,Sluong from CanLamSang..CLS_VatTuYTe vt
inner join(select * from  CanLamSang..CLS_ChungLoaiHangHoa) dm on dm.ID = vt.Loai where dm.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and isnull(dm.ChuyenKhoa,'') = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and isnull(dm.NhomDichVu,'') = '" + Session[cSessionName.NhomDichVu].ToString() + "'" +
" order by vt.loai desc";
            return act.excuteQueryStringJson();
        }
    }
}