﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CanLamSang.Models;
using Newtonsoft.Json;

namespace CanLamSang.Controllers
{
    public class BaoCaoController : Controller
    {
        // GET: BaoCao
        public ActionResult BaoCaoTongHop()
        {
            //trang layout chính
            return View();
        }

        public ActionResult _DanhSachKetQua()
        {
            ViewBag.Title = "Danh sách kết quả";
            return View();
        }

        public ActionResult _DanhSachBacSiChuaTraKetQua()
        {
            ViewBag.Title = "Danh sách bác sĩ chưa trả kết quả";
            return View();
        }

        public ActionResult _DanhSachBenhNhanChuaSuDung()
        {
            return View();
        }

        public ActionResult _TongBenhNhan()
        {
            return View();
        }

        #region api

        public string DanhSachChuaTraKetQua(string tungay, string denngay)
        {
            if (Session[cSessionName.ChuyenKhoa] != null)
            {
                string khoanhom_Query = "";
                if (Session[cSessionName.NhomDichVu].ToString() == "")
                {
                    khoanhom_Query = " NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + " '";
                }
                else
                {
                    khoanhom_Query = " NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and NhomDichVu ='" + Session[cSessionName.NhomDichVu].ToString() + "'";
                };
                tungay += " 00:00:00";
                denngay += " 23:59:59";
                cDBAccess db = new cDBAccess();
                db.sqlQuery = @"SET DATEFORMAT dmy select MaPhieu, MaBN, HoTen, GioiTinh, DoiTuong, MaChiDinh, BacSiChiDinh, NoiChiDinh, NgayChiDinh, TenDV,
ISNULL(TenKTVChupHinh,'') TenKTVChupHinh, FORMAT(NgayChupHinh, 'dd/MM/yyyy HH:mm') NgayChupHinh  
from Ketqua_CLS where "+ khoanhom_Query + " and Ngay between '" + tungay + "' and '" + denngay + "' and TinhTrang in (1,5,7)";
                return db.excuteQueryStringJson();
            }
            else
                return JsonConvert.SerializeObject(new { status = "error", message = "Hết phiên làm việc!" });
        }

        public string DanhSachKetQua(string tungay, string denngay)
        {
            if (Session[cSessionName.ChuyenKhoa] != null)
            {
                string khoanhom_Query = "";
                if (Session[cSessionName.NhomDichVu].ToString() == "")
                {
                    khoanhom_Query = " NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + " '";
                }
                else
                {
                    khoanhom_Query = " NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and NhomDichVu ='" + Session[cSessionName.NhomDichVu].ToString() + "'";
                };
                tungay += " 00:00:00";
                denngay += " 23:59:59";
                cDBAccess db = new cDBAccess();
                db.sqlQuery = @"SET DATEFORMAT dmy select MaPhieu, MaBN, HoTen, GioiTinh, DoiTuong, MaChiDinh, BacSiChiDinh, NoiChiDinh, NgayChiDinh, TenDV,
ISNULL(TenKTVChupHinh,'') TenKTVChupHinh, ISNULL(BacSiCDHA,'') BacSiCDHA, FORMAT(NgayChupHinh, 'dd/MM/yyyy HH:mm') NgayChupHinh, FORMAT(Ngay, 'dd/MM/yyyy HH:mm') NgayCoKQ, case when TaiGiuong = 0 then '' else 'x' end TaiGiuong  
from Ketqua_CLS where "+ khoanhom_Query + " and Ngay between '" + tungay + "' and '" + denngay + "' and TinhTrang in (2,4)";
                return db.excuteQueryStringJson();
            }
            else
                return JsonConvert.SerializeObject(new { status = "error", message = "Hết phiên làm việc!" });
        }

        public string DanhSachBNChuaSuDung(string tungay, string denngay)
        {
            if (Session[cSessionName.ChuyenKhoa] != null)
            {
                string khoanhom_Query = "";
                if (Session[cSessionName.NhomDichVu].ToString() == "")
                {
                    khoanhom_Query = " dsc.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and dsc.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + " '";
                }
                else
                {
                    khoanhom_Query = " dsc.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and dsc.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and dsc.NhomDichVu ='" + Session[cSessionName.NhomDichVu].ToString() + "'";
                };
                tungay += " 00:00:00";
                denngay += " 23:59:59";
                cDBAccess db = new cDBAccess();
                db.sqlQuery = @"SET DATEFORMAT dmy select MaBN, Hoten, case when GioiTinh = 1 then 'Nam' else N'Nữ' end GioiTinh
, dt.TenDT, MaChiDinh, TenBSCD, case when ISNULL(Kngoaitru.TenKhoa,'') <> '' then Kngoaitru.TenKhoa else Knoitru.TenKhoa end NoiChiDinh,
 Ngay TgChiDinh, MaDV, TenDichVu
from DS_ChoCLS dsc
left join (Select TenDT,MADT from QuanTri..DM_DoiTuong_BN) dt on dsc.DoiTuong = dt.MADT
left join (Select MaKhoa,TenKhoa from Quantri..DM_KHOA) Kngoaitru on dsc.MaNoiChiDinh= Kngoaitru.MaKhoa                                
left join (Select idKhoa,TenKhoa from QLNOITRU..DM_Khoa) Knoitru on dsc.MaNoiChiDinh=convert(nvarchar,Knoitru.idKhoa)
where dsc.SuDung = 0 and dsc.Huy = 0 and "+ khoanhom_Query + " and ngay between '" + tungay + "' and '" + denngay + "'";
                return db.excuteQueryStringJson();
            }
            else
                return JsonConvert.SerializeObject(new { status = "error", message = "Hết phiên làm việc!" });
        }

        #endregion
    }
}