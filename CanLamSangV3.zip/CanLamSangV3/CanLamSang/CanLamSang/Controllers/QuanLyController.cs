﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CanLamSang.Controllers
{
    public class QuanLyController : Controller
    {
        // GET: QuanLy
        public ActionResult QuanTri()
        {
            return View();
        }
        public ActionResult CauHinhQuyenCLS()
        {
            return PartialView();
        }
        public ActionResult CauHinhKhoa()
        {
            return PartialView();
        }
        //-------------------------SQL Select-------------------------//
        //----------------------------Cấu hình quyền--------------------------------//
        #region Cấu hình Quyền SQL Select
        [HttpPost]
        public string LoadChiTietNhomQuyen(string ID)
        {
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"select distinct IDProfile,ten,hienthi from CanLamSang..VQuanTriQuyen where IDProfile = '"+ ID + "'";
            return db.excuteQueryStringJson();
        }
        [HttpPost]
        public string LoadQuyen(string ID)
        {
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"select IDProfile_ChiTiet,IDTenQuyen,MaQuyen,TenQuyen  from CanLamSang..VQuanTriQuyen where IDProfile = '" + ID + "'";
            return db.excuteQueryStringJson();
        }
        [HttpPost]
        public string AutoCompleteMaQuyen()
        {
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"select Ten,MaQuyen from CanLamSang..CFG_MaQuyen_CLS";
            return db.excuteQueryStringJson();
        }
        #endregion

        #region Cấu hình Quyền SQL StoreProcduce
        [HttpPost]
        public string CheckHienThi(string ID,string hienthi) //Update lại hiện thị của profile 
        {
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"sp_CLS_QuanLyProfile_UpHienThi";
            db.addParameter("ID", SqlDbType.VarChar, ID);
            db.addParameter("HienThi", SqlDbType.VarChar, hienthi);
            return db.excuteStoreStringJson();
        }
        [HttpPost]
        public string ThemNhomQuyen(string MaNhom, string TenNhom,string IDProfile)  
        {
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"sp_CLS_QuanLy_NhomQuyen_Them";
            db.addParameter("MaNhom", SqlDbType.VarChar, MaNhom);
            db.addParameter("TenNhom", SqlDbType.NVarChar, TenNhom);
            db.addParameter("IDProfile", SqlDbType.VarChar, IDProfile);
            return db.excuteStoreStringJson();
        }
        [HttpPost]
        public string XoaQuyen(string IDPCT, string IDTQ)//Delete Quyền trong profile chi tiết và TenQuuyen
        {
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"sp_CLS_QuanLyProfile_XoaQuyen";
            db.addParameter("IDPCT", SqlDbType.VarChar, IDPCT);
            db.addParameter("IDTQ", SqlDbType.VarChar, IDTQ);
            return db.excuteStoreStringJson();
        }
        #endregion
        //------------------------------------------------------------//

        [HttpPost]
        public string ProSelect(string loaiselect)
        {
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"sp_CLS_QuanLy_Select";
            db.addParameter("loaiselect", SqlDbType.VarChar, loaiselect);
            return db.excuteStoreStringJson();
        }
    }
}