﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CanLamSang.Controllers
{
    public class TuTrucController : Controller
    {
        // GET: TuTruc
        public ActionResult CLSTuTruc()
        {
            return View();
        }
    }
}