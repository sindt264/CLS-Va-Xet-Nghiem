﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CanLamSang.Models;
using Newtonsoft.Json;

namespace CanLamSang.Controllers
{
    public class KetQuaController : Controller
    {
        // GET: KetQua
        public ActionResult NoiSoiSieuAm()
        {
            ClearSessionBN();//khi trang kết quả được load lại thì xóa session bệnh nhân đang lưu
            return View();
        }

        public ActionResult ChanDoanHinhAnhChupHinh()
        {
            return View();
        }

        public ActionResult ChanDoanHinhAnhDocGhiKQ()
        {
            return View();
        }

        public ActionResult ChupHinhWebRTC()
        {
            return View();
        }

        public ActionResult DienTamDo()
        {
            return View();
        }

        public ActionResult TraKetQuaChung()
        {
            return View();
        }

        private void ClearSessionBN()
        {
            Session[cSessionName.bn_mabn] = null;
            Session[cSessionName.bn_macd] = null;
            Session[cSessionName.bn_maphieuCLS] = null;
            Session[cSessionName.bn_mavp] = null;
            Session[cSessionName.bn_mavp_chitiet] = null;
        }

        #region upload file
        public ActionResult UploadIMG()
        {
            string fName = "";
            string _status = "done";
            string _message = "upload thành công!";
            try
            {
                foreach (string fileName in Request.Files)
                {
                    HttpPostedFileBase file = Request.Files[fileName];
                    fName = file.FileName;
                    if (file != null && file.ContentLength > 0)
                    {
                        string pathString = Session[cSessionName.ChuyenKhoa].ToString() + Session[cSessionName.NhomDichVu].ToString() + "/" +
                            DateTime.Now.ToString("yyyy") + "/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("dd") + "/" +
                            Session[cSessionName.ChuyenKhoa].ToString() + "_" + Session[cSessionName.bn_mavp].ToString() + "_" + Session[cSessionName.bn_mavp_chitiet].ToString() + "/";


                        string name = Session[cSessionName.bn_mabn].ToString().Trim() + "_" + Session[cSessionName.bn_mavp].ToString() + "_" + Session[cSessionName.bn_mavp_chitiet].ToString() + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + "_" + DateTime.Now.ToString("fff") + ".jpeg";

                        if (!Directory.Exists(Session[cSessionName.defaultPath_local].ToString() + pathString))
                            Directory.CreateDirectory(Session[cSessionName.defaultPath_local].ToString() + pathString);

                        Resize(Session[cSessionName.defaultPath_local].ToString() + pathString, name, 2048, file.InputStream);
                        DataTable dt = SaveDataFile(pathString, name, Session[cSessionName.bn_maphieuCLS] == null ? "" : Session[cSessionName.bn_maphieuCLS].ToString(), Session[cSessionName.bn_mavp].ToString(), Session[cSessionName.bn_mavp_chitiet].ToString());
                        _status = dt.Rows[0][0].ToString();
                        _message = fName + " : " + dt.Rows[0][1].ToString();
                    }
                }
                return Json(new
                {
                    status = _status,
                    message = _message
                });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    status = "error",
                    message = "Không thể lưu hình ảnh! Lý do: " + ex.Message
                });
            }
        }

        [HttpPost]
        public string LayDanhSachHinhAnhSauUpload(string list_name_img_curr = "")
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = "sp_CLS_LayDanhSachHinhAnh";
            db.addParameter("mavp", SqlDbType.VarBinary, Session[cSessionName.bn_mavp].ToString());
            db.addParameter("mavp_chitiet", SqlDbType.VarBinary, Session[cSessionName.bn_mavp_chitiet].ToString());
            db.addParameter("listIMG_curr", SqlDbType.VarBinary, list_name_img_curr);
            return db.excuteStoreStringJson();
        }

        //----------------------- private function -------------------------------------//
        private DataTable SaveDataFile(string path, string filename, string maphieu = "", string mavp = "", string mavpct = "")
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = "sp_CLS_LuuFile";
            db.addParameter("pathFolder", SqlDbType.VarChar, Session[cSessionName.defaultPath_local].ToString() + path);
            //db.addParameter("pathLink", SqlDbType.VarChar, Session[cSessionName.defaultPath_online].ToString() + path);
            db.addParameter("pathLink", SqlDbType.VarChar, Session[cSessionName.PathLinkOnline].ToString() + path);
            db.addParameter("filename", SqlDbType.VarChar, filename);
            db.addParameter("maphieu", SqlDbType.VarChar, maphieu);
            db.addParameter("mavp", SqlDbType.VarChar, mavp);
            db.addParameter("mavpct", SqlDbType.VarChar, mavpct);

            return db.excuteProcDatatable();
        }

        private void Resize(string ImageSavePath, string fileName, int MaxWidthSideSize, Stream Buffer)
        {
            int intNewWidth;
            int intNewHeight;
            Image imgInput = Image.FromStream(Buffer);
            ImageCodecInfo myImageCodecInfo;
            myImageCodecInfo = GetEncoderInfo("image/jpeg");

            Encoder myEncoder = Encoder.Quality;
            EncoderParameters myEncoderParameters = new EncoderParameters(1);
            EncoderParameter myEncoderParameter;
            //Giá trị width và height nguyên thủy của ảnh;
            int intOldWidth = imgInput.Width;
            int intOldHeight = imgInput.Height;

            //Kiểm tra xem ảnh ngang hay dọc;
            int intMaxSide;
            /*if (intOldWidth >= intOldHeight)
            {
            intMaxSide = intOldWidth;
            }
            else
            {
            intMaxSide = intOldHeight;
            }*/
            //Để xác định xử lý ảnh theo width hay height thì bạn bỏ note phần trên;
            //Ở đây mình chỉ sử dụng theo width nên gán luôn intMaxSide= intOldWidth; ^^;
            intMaxSide = intOldWidth;
            if (intMaxSide > MaxWidthSideSize)
            {
                //Gán width và height mới.
                double dblCoef = MaxWidthSideSize / (double)intMaxSide;
                intNewWidth = Convert.ToInt32(dblCoef * intOldWidth);
                intNewHeight = Convert.ToInt32(dblCoef * intOldHeight);
            }
            else
            {
                //Nếu kích thước width/height (intMaxSide) cũ ảnh nhỏ hơn MaxWidthSideSize thì giữ nguyên //kích thước cũ;
                intNewWidth = intOldWidth;
                intNewHeight = intOldHeight;
            }

            //Tạo một ảnh bitmap mới;
            Bitmap bmpResized = new Bitmap(imgInput, intNewWidth, intNewHeight);
            //Phần EncoderParameter cho phép bạn chỉnh chất lượng hình ảnh ở đây mình để chất lượng tốt //nhất là 100L;
            myEncoderParameter = new EncoderParameter(myEncoder, 70L);
            myEncoderParameters.Param[0] = myEncoderParameter;
            //Lưu ảnh;
            bmpResized.Save(Path.Combine(ImageSavePath, fileName), myImageCodecInfo, myEncoderParameters);

            //Giải phóng tài nguyên;
            imgInput.Dispose();
            bmpResized.Dispose();
        }

        private ImageCodecInfo GetEncoderInfo(String mimeType)
        {
            int j;
            ImageCodecInfo[] encoders;
            encoders = ImageCodecInfo.GetImageEncoders();
            for (j = 0; j < encoders.Length; ++j)
            {
                if (encoders[j].MimeType == mimeType)
                    return encoders[j];
            }
            return null;

        }
        #endregion

        [HttpPost]
        public string LayDanhSachHinhAnh(string listIMG_curr)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = "sp_CLS_LayDanhSachHinhAnh";
            if (listIMG_curr != "")
                db.addParameter("listIMG_curr", SqlDbType.VarChar, listIMG_curr);
            if (Session[cSessionName.bn_maphieuCLS] != null)
                db.addParameter("maphieucls", SqlDbType.VarChar, Session[cSessionName.bn_maphieuCLS].ToString());
            if (Session[cSessionName.bn_mavp] != null)
            {
                db.addParameter("mavp", SqlDbType.VarChar, Session[cSessionName.bn_mavp].ToString());
                db.addParameter("mavp_chitiet", SqlDbType.VarChar, Session[cSessionName.bn_mavp_chitiet].ToString());
            }
            return db.excuteStoreStringJson();
        }

        //Hieu
        //Get thông tin bệnh nhân 
        [HttpPost]
        public string dbGetThongTinBenhNhan(string maBN, string maCD, string maVP, string maVP_ChiTiet, string MaPhieu,string LinkOnline)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"CanLamSang..sp_CLS_GetThongBenhNhan";
            db.addParameter("mabn", SqlDbType.NVarChar, maBN);
            db.addParameter("macd", SqlDbType.NVarChar, maCD);
            db.addParameter("MaPhieu", SqlDbType.NVarChar, MaPhieu);
            DataTable dt = db.excuteProcDatatable();
            if (dt.Rows.Count > 0)
            {
                Session[cSessionName.bn_mabn] = dt.Rows[0]["MaBN"].ToString().Trim();
                Session[cSessionName.bn_macd] = dt.Rows[0]["MaChiDinh"].ToString().Trim();
                Session[cSessionName.bn_mavp] = maVP.Trim();
                Session[cSessionName.bn_mavp_chitiet] = maVP_ChiTiet.Trim();
                Session[cSessionName.PathLinkOnline] = LinkOnline;
                return JsonConvert.SerializeObject(dt, Formatting.Indented);
            }
            else
                return "{'status':'error', 'message':'Không tìm thấy thông tin bệnh nhân!'}";
        }
        //Lưu Kết Qủa
        [HttpPost]
        public string dbLuuKQ(string xml, string MaPhieu, string MaVP, string xmlVTYT, string MaVPCT, string xmlTT, string xmlTB, string xmlHinh, string VungKhaoSat, string MoTa, string KetLuan, string DeNghi, string MaBN, string TinhTrang,string MaKetNoi)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"CanLamSang..sp_CLS_LuuKQ";
            db.addParameter("xmlThongTin", SqlDbType.Xml, xml.Replace("'", "''"));
            db.addParameter("MaPhieu", SqlDbType.NVarChar, MaPhieu);
            db.addParameter("MaBN", SqlDbType.NVarChar, MaBN);
            db.addParameter("MaVP", SqlDbType.NVarChar, MaVP);
            db.addParameter("MaVPCT", SqlDbType.NVarChar, MaVPCT);// Mã Viện Phí Chi Tiết
            db.addParameter("xmlThuThuat", SqlDbType.Xml, xmlTT);// Xml Thủ thuật
            db.addParameter("xmlTaiBien", SqlDbType.Xml, xmlTB);// Xml Tai Biến
            db.addParameter("xmlVTYT", SqlDbType.Xml, xmlVTYT);// Xml VTYT
            db.addParameter("xmlHinh", SqlDbType.Xml, xmlHinh);
            db.addParameter("NhomChuyenKhoa", SqlDbType.NVarChar, Session[cSessionName.NhomChuyenKhoa].ToString());
            db.addParameter("ChuyenKhoa", SqlDbType.NVarChar, Session[cSessionName.ChuyenKhoa].ToString());
            db.addParameter("NhomDichVu", SqlDbType.NVarChar, Session[cSessionName.NhomDichVu].ToString());
            db.addParameter("MaUser", SqlDbType.NVarChar, Session[cSessionName.username].ToString());
            db.addParameter("TenUser", SqlDbType.NVarChar, Session[cSessionName.hoten].ToString());
            db.addParameter("VungKhaoSat", SqlDbType.NVarChar, VungKhaoSat);
            db.addParameter("MoTa", SqlDbType.NVarChar, MoTa);
            db.addParameter("KetLuan", SqlDbType.NVarChar, KetLuan);
            db.addParameter("DeNghi", SqlDbType.NVarChar, DeNghi);
            db.addParameter("TinhTrangPhieu", SqlDbType.Int, TinhTrang);
            db.addParameter("MaKetNoi", SqlDbType.NVarChar, MaKetNoi);
            return db.excuteStoreStringJson();
        }
        //[HttpPost]
        //public string dbTaoMaKetNoi(string MaKetNoi)
        //{
        //    cDBAccess db = new cDBAccess();
        //    db.sqlQuery = @"CanLamSang..sp_CLS_TaoMaLienKet";
        //    db.addParameter("MaLienKet", SqlDbType.NVarChar, MaKetNoi);
        //    return db.excuteStoreStringJson();
        //}
    }
}