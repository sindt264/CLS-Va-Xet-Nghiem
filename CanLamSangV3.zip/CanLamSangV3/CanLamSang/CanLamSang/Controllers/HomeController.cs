﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CanLamSang.Models;
using Newtonsoft.Json;

namespace CanLamSang.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            //test thử lần thứ 2
            return View();
        }

        #region api
        [HttpPost]
        public string CheckSession(string makhoa, string manhom)
        {
            if (Session[cSessionName.username] == null)
                return JsonConvert.SerializeObject(new { status = "error", message = "Phiên làm việc hết hạn!" }, Formatting.Indented);
            else
            {
                if (makhoa != Session[cSessionName.ChuyenKhoa].ToString() || manhom != Session[cSessionName.NhomDichVu].ToString())
                {
                    Session.Abandon();
                    return JsonConvert.SerializeObject(new { status = "error", message = "Bạn đang đăng nhập 2 khoa Cân Lâm Sàng cùng một phiên làm việc, điều này không được phép!" }, Formatting.Indented);
                }
                else
                    return JsonConvert.SerializeObject(new { status = "done" }, Formatting.Indented);
            }
        }

        public string SessionAbandon()
        {
            Session.Abandon();
            return JsonConvert.SerializeObject(new { status = "done", message = "Phiên làm việc hết hạn!" }, Formatting.Indented);
        }


        [HttpPost]
        public string GetKhoaCLS()
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = "sp_CLS_layDanhMucKhoa";
            return db.excuteStoreStringJson();
        }

        public string DangNhap(string username = "", string password = "", string idkhoacls = "")
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"sp_CLS_DangNhap";
            db.addParameter("username", SqlDbType.VarChar, username);
            db.addParameter("password", SqlDbType.VarChar, password);
            db.addParameter("idkhoacls", SqlDbType.Int, idkhoacls);
            DataTable dt = db.excuteProcDatatable();
            if (dt.Rows.Count > 0)
            {
                switch (dt.Rows[0]["status"].ToString())
                {
                    case "error":
                        return JsonConvert.SerializeObject(dt, Formatting.Indented);
                    default:
                        Session[cSessionName.url] = dt.Rows[0]["Menu"].ToString();
                        Session[cSessionName.NhomChuyenKhoa] = dt.Rows[0]["NhomChuyenKhoa"].ToString();
                        Session[cSessionName.ChuyenKhoa] = dt.Rows[0]["ChuyenKhoa"].ToString();
                        Session[cSessionName.NhomDichVu] = dt.Rows[0]["NhomDichVu"].ToString();
                        Session[cSessionName.TenKhoa] = dt.Rows[0]["TenKhoa"].ToString();
                        Session[cSessionName.hoten] = dt.Rows[0]["HoTen"].ToString();
                        Session[cSessionName.username] = username;
                        Session[cSessionName.defaultPath_local] = dt.Rows[0]["localPath"].ToString();
                        //Session[cSessionName.defaultPath_online] = dt.Rows[0]["onlinePath"].ToString();
                        //Session[cSessionName.NhomPhanQuyen] = dt.Rows[0]["NhomPhanQuyen"].ToString();

                        return JsonConvert.SerializeObject(dt, Formatting.Indented);
                }
            }
            else
                return "{'status':'error', 'message':'Đăng nhập không thành công!'}";

        }
        #endregion

        [HttpPost]
        public string ChangePassword(string MatKhauCu, string MatKhauMoi)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"sp_CLS_ChangePassword";
            db.addParameter("TenDangNhap", SqlDbType.VarChar, Session[cSessionName.username].ToString());
            db.addParameter("MaKhauCu", SqlDbType.VarChar, MatKhauCu);
            db.addParameter("MaKhauMoi", SqlDbType.VarChar, MatKhauMoi);
            return db.excuteStoreStringJson();
        }
    }
}