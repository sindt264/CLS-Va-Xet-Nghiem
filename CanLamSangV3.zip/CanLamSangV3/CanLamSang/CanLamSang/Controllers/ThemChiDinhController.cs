﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CanLamSang.Models;
using Newtonsoft.Json;

namespace CanLamSang.Controllers
{
    public class ThemChiDinhController : Controller
    {
        // GET: ThemChiDinh
        public ActionResult ChiDinh()
        {
            return View();
        }
        public ActionResult DSPhieuKetQua()
        {
            return PartialView();
        }

        [HttpPost]
        public string dbGetDanhSachKQ(string TuNgay, string DenNgay)
        {

            string khoanhom_Query = "";
            if (Session[cSessionName.NhomDichVu].ToString() == "")
            {
                khoanhom_Query = " KQ.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and KQ.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + " '";
            }
            else
            {
                khoanhom_Query = " KQ.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and KQ.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and KQ.NhomDichVu ='" + Session[cSessionName.NhomDichVu].ToString() + "'";
            }

            string User_Query = " and KQ.MaBSCDHA='" + Session[cSessionName.username] + "' ";
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"set dateformat dmy
	select 
		KQ.MaPhieu,
		KQ.HoTen,
		KQ.GioiTinh ,
		KQ.TenDV
	from CanLamSang..Ketqua_CLS KQ
where " + khoanhom_Query + " and KQ.Ngay between '" + TuNgay + " 00:00:00' and '" + DenNgay + " 23:59:59' and (KQ.TinhTrang = 2 or KQ.TinhTrang = 4) " + User_Query + " " +
" order by KQ.Ngay desc ";
            return db.excuteQueryStringJson();
        }
        
        [HttpPost]
        public string dbLoadPhieu(string MaPhieu)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"select * from CanLamSang..Ketqua_CLS where MaPhieu ='" + MaPhieu + "'";
            return db.excuteQueryStringJson();
        }

        [HttpPost]
        public string dbLoadDSPhieuLienKet(string MaPhieu)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"select MaPhieu, format(Ngay, 'dd/MM/yyyy HH:mm') NgayKQ, Khoa.Ten TenKhoa, KQ.TenDV,KQ.BacSiCDHA FROM CanLamSang..Ketqua_CLS KQ
INNER JOIN (SELECT ChuyenKhoa, NhomChuyenKhoa, NhomDichVu, Ten FROM CanLamSang..CFG_Khoa_CLS) Khoa on KQ.ChuyenKhoa = Khoa.ChuyenKhoa and KQ.NhomChuyenKhoa = Khoa.NhomChuyenKhoa and KQ.NhomDichVu = Khoa.NhomDichVu where KQ.MaKetNoi ='"+ MaPhieu + "'";
            return db.excuteQueryStringJson();
        }
    }
}