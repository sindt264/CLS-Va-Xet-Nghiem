﻿using CanLamSang.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CanLamSang.Controllers
{
    public class PhieuInController : Controller
    {
        // GET: PhieuIn
        public ActionResult PhieuYKhoa()
        {
            return View();
        }
        public ActionResult PhieuYKhoa2()
        {
            return View();
        }
        public ActionResult PhieuYKhoaLayMau()
        {
            return View();
        }

        [HttpPost]
        public string dbGetThongTinBV()
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"Select CQChuQuan,TenBV,DiaChi as DiaChiBV,DienThoai as DienThoaiBV,TenTinh from QuanTri..ThongTinBenhVien";
            return db.excuteQueryStringJson();
        }
        [HttpPost]
        public string dbGetThongTinBenhNhan(string MaPhieu)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"select KQ.*, isnull(DeNghi,'') checkDeNghi,
(select Ten from CanLamSang..CFG_Khoa_CLS kh where ISNULL(kh.ChuyenKhoa,'') = ISNULL(kq.ChuyenKhoa, '') and ISNULL(kh.NhomDichVu, '') = ISNULL(kq.NhomDichVu, '')) Ten,
(select NhomPhanQuyen from CanLamSang..CFG_Khoa_CLS kh where ISNULL(kh.ChuyenKhoa,'') = ISNULL(kq.ChuyenKhoa, '') and ISNULL(kh.NhomDichVu, '') = ISNULL(kq.NhomDichVu, '')) NhomPhanQuyen,
UPPER((select Ten from CanLamSang..CFG_Khoa_CLS kh where ISNULL(kh.ChuyenKhoa,'') = ISNULL(kq.ChuyenKhoa, '') and ISNULL(kh.NhomDichVu, '') = ISNULL(kq.NhomDichVu, ''))) TenKhoa,
UPPER(KQ.BacSiCDHA) AS BacSiCDHAChuKy, 
format(KQ.Ngay,'dd/MM/yyyy HH:mm') as NgayKQ from CanLamSang..Ketqua_CLS KQ
 WHERE KQ.MaPhieu = '" + MaPhieu + "'";
            return db.excuteQueryStringJson();
        }

        [HttpPost]
        public string dbGetHinh(string MaPhieu)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @" select TenFile,OnlinePath,GhiChu from CanLamSang..Ketqua_CLS_HinhAnh where MaPhieu = '" + MaPhieu + "' and isPrint = 1 and isDelete = 0  order by PrintOrder asc";
            return db.excuteQueryStringJson();
        }

    }
}