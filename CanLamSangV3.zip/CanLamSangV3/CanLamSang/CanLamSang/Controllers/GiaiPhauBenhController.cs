﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CanLamSang.Models;
using Newtonsoft.Json;

namespace CanLamSang.Controllers
{
    public class GiaiPhauBenhController : Controller
    {
        // GET: GiaiPhauBenh
        public ActionResult LayMau()
        {
            return View();
        }
        public ActionResult TiepNhanMau()
        {
            return View();
        }
        public ActionResult KetQuaGiaiPhauBenh()
        {
            return View();
        }
        public ActionResult ThongTinBenhNhan()
        {
            return PartialView();
        }
        public ActionResult ThongTinKetQua()
        {
            return PartialView();
        }
        //------------------------------------------------------------------------//
        [HttpPost]
        public string LoadMauAuto()
        {
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"select * from CanLamSang..CLS_MauGiaiPhauBenh where NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and NhomDichVu = '" + Session[cSessionName.NhomDichVu].ToString() + "' order by ID asc ";
            return db.excuteQueryStringJson();
        }
        //------------------------------------------------------------------------//
        [HttpPost]
        public string LoadChatBaoQuan()
        {
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"select * from CanLamSang..CLS_VatTuYTe where  NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and NhomDichVu = '" + Session[cSessionName.NhomDichVu].ToString() + "' order by id asc";
            return db.excuteQueryStringJson();
        }
        //------------------------------------------------------------------------//
        [HttpPost]
        public string dbLuuKQGPB(string xml, string MaPhieu, string MaVP, string MaVPCT, string MaBN, string MaKetNoi, string ChatBaoQuan, string MauThu, string noigui)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"CanLamSang..sp_LayMau_GPB";
            db.addParameter("xmlThongTin", SqlDbType.Xml, xml.Replace("'", "''"));
            db.addParameter("MaPhieu", SqlDbType.NVarChar, MaPhieu);
            db.addParameter("MaBN", SqlDbType.NVarChar, MaBN);
            db.addParameter("MaVP", SqlDbType.NVarChar, MaVP);
            db.addParameter("MaVPCT", SqlDbType.NVarChar, MaVPCT);// Mã Viện Phí Chi Tiết
            db.addParameter("NhomChuyenKhoa", SqlDbType.NVarChar, Session[cSessionName.NhomChuyenKhoa].ToString());
            db.addParameter("ChuyenKhoa", SqlDbType.NVarChar, Session[cSessionName.ChuyenKhoa].ToString());
            db.addParameter("NhomDichVu", SqlDbType.NVarChar, Session[cSessionName.NhomDichVu].ToString());
            db.addParameter("MaUser", SqlDbType.NVarChar, Session[cSessionName.username].ToString());
            db.addParameter("TenUser", SqlDbType.NVarChar, Session[cSessionName.hoten].ToString());
            db.addParameter("MaKetNoi", SqlDbType.NVarChar, MaKetNoi);
            db.addParameter("MauThu", SqlDbType.NVarChar, MauThu);
            db.addParameter("ChatBaoQuan", SqlDbType.NVarChar, ChatBaoQuan);
            db.addParameter("DCNOIGUI", SqlDbType.NVarChar, noigui);
            return db.excuteStoreStringJson();
        }
        //------------------------------------------------------------------------//
        [HttpPost]
        public string dbLuuTNM(string MaPhieu, string TinhTrangMau, string TinhTrang)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"CanLamSang..sp_TNM_GPB";
            db.addParameter("TinhTrangMau", SqlDbType.NVarChar, TinhTrangMau);
            db.addParameter("MaPhieu", SqlDbType.NVarChar, MaPhieu);
            db.addParameter("TinhTrangPhieu", SqlDbType.Int, TinhTrang);
            db.addParameter("MaUser", SqlDbType.NVarChar, Session[cSessionName.username].ToString());
            db.addParameter("TenUser", SqlDbType.NVarChar, Session[cSessionName.hoten].ToString());
            return db.excuteStoreStringJson();
        }

         [HttpPost]
        public string dbLuuKQ_GPB(string MaPhieu, string MaVP, string MaVPCT, string xmlHinh, string VungKhaoSat, string MoTa, string KetLuan, string MaBN, string TinhTrang)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"CanLamSang..sp_GPB_KetQua";
            db.addParameter("MaPhieu", SqlDbType.NVarChar, MaPhieu);
            db.addParameter("MaBN", SqlDbType.NVarChar, MaBN);
            db.addParameter("MaVP", SqlDbType.NVarChar, MaVP);
            db.addParameter("MaVPCT", SqlDbType.NVarChar, MaVPCT);// Mã Viện Phí Chi Tiết
            db.addParameter("xmlHinh", SqlDbType.Xml, xmlHinh);
            db.addParameter("MaUser", SqlDbType.NVarChar, Session[cSessionName.username].ToString());
            db.addParameter("TenUser", SqlDbType.NVarChar, Session[cSessionName.hoten].ToString());
            db.addParameter("VungKhaoSat", SqlDbType.NVarChar, VungKhaoSat);
            db.addParameter("MoTa", SqlDbType.NVarChar, MoTa);
            db.addParameter("KetLuan", SqlDbType.NVarChar, KetLuan);
            db.addParameter("TinhTrangPhieu", SqlDbType.Int, TinhTrang);
            return db.excuteStoreStringJson();
        }
        //------------------------------------------------------------------------//
        [HttpPost]
        public string dbDSKetQua_LayMau(string TuNgay, string DenNgay, bool Khoa, bool Huy, bool MacDinh, bool Sua, string LoaiMau)
        {
            string htmltong = "";
            if (MacDinh == false)
            {
                if (Khoa == true)
                {
                    htmltong = " and KQ.Block = 1 ";
                }
                if (Huy == true)
                {
                    htmltong = " and KQ.TinhTrang = 0 and KQ.Block = 0 ";
                }
                if (Sua == true)
                {
                    if (LoaiMau == "LM")
                    {
                        htmltong = " and KQ.TinhTrang = 8 and KQ.Block = 0 ";
                    }
                    else if (LoaiMau == "TNM")
                    {
                        htmltong = " and KQ.TinhTrang = 5 and KQ.Block = 0 ";
                    }
                    else
                    {
                        htmltong = " and KQ.TinhTrang = 4 and KQ.Block = 0 ";
                    }

                }
            }
            else
            {
                if (LoaiMau == "LM")
                {
                    htmltong = " and (KQ.TinhTrang = 6 or KQ.TinhTrang  = 8) and KQ.Block = 0 ";
                }
                else if (LoaiMau == "TNM")
                {
                    htmltong = " and (KQ.TinhTrang = 5 or KQ.TinhTrang  = 7) and KQ.Block = 0 ";
                }
                else
                {
                    htmltong = " and (KQ.TinhTrang = 4 or KQ.TinhTrang  = 2) and KQ.Block = 0 ";
                }

            }
            ///--------------------------------------------------------
            string sqlNgay = "";
            if (LoaiMau == "LM")
            {
                sqlNgay = " KQ.NgayLayMau";
            }
            else if (LoaiMau == "TNM")
            {
                sqlNgay = " KQ.NgayChupHinh";
            }
            else
            {
                sqlNgay = " KQ.Ngay";
            }

            //-------------------------------------------------------------
            string khoanhom_Query = "";
            if (Session[cSessionName.NhomDichVu].ToString() == "")
            {
                khoanhom_Query = " KQ.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and KQ.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + " '";
            }
            else
            {
                khoanhom_Query = " KQ.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and KQ.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and KQ.NhomDichVu ='" + Session[cSessionName.NhomDichVu].ToString() + "'";
            }

            string User_Query = " and KQ.MaNguoiLayMau='" + Session[cSessionName.username] + "' ";
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"set dateformat dmy
	select 
		KQ.MaPhieu,
		KQ.MaChiDinh,
		format(" + sqlNgay + ",'dd/MM/yyyy HH:mm') as Ngay, " +
        "KQ.MaBN," +
        "KQ.HoTen," +
        "KQ.GioiTinh ," +
        "KQ.TenDV," +
        "KQ.MaChiDinh," +
        "KQ.TinhTrang," +
        "TT.TenTinhTrang," +
        "KQ.Block," +
        "isNull((select top 1 lydo from CanLamSang..CLS_LOG_KetQua log where log.maphieu=KQ.MaPhieu order by ngaythaydoi desc),'') as LyDo," +
        "KQ.MaVP," +
        "KQ.MaVP_ChiTiet," +
        "case when KQ.DoiTuong Like N'%Bảo Hiểm%' then '1'else '0' end as BH" +
    " from CanLamSang..Ketqua_CLS KQ" +
    " left join (select ID,TenTinhTrang from CanLamSang..TinhTrang_KQ_CLS) TT on TT.ID = KQ.TinhTrang" +
    " where " + khoanhom_Query + htmltong + " " + User_Query + " and " + sqlNgay + " between '" + TuNgay + " 00:00:00' and '" + DenNgay + " 23:59:59' " +
    " order by " + sqlNgay + " desc ";
            return db.excuteQueryStringJson();
        }

        //------------------------------------------------------------------------//
        [HttpPost]
        public string dbDSChoKham(string TuNgay, string DenNgay, string LoaiMau)
        {
            string sqlNgay = "";
            string htmltong = "";
            if (LoaiMau == "LM")
            {
                htmltong = " and (KQ.TinhTrang = 6 or KQ.TinhTrang = 8) and KQ.Block = 0 ";
                sqlNgay = " KQ.NgayLayMau";
            }
            else
            {
                htmltong = " and (KQ.TinhTrang = 7 or KQ.TinhTrang = 5) and KQ.Block = 0 ";
                sqlNgay = " KQ.NgayChupHinh";
            }

            string khoanhom_Query = "";
            if (Session[cSessionName.NhomDichVu].ToString() == "")
            {
                khoanhom_Query = " KQ.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and KQ.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + " '";
            }
            else
            {
                khoanhom_Query = " KQ.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and KQ.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and KQ.NhomDichVu ='" + Session[cSessionName.NhomDichVu].ToString() + "'";
            }

            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"set dateformat dmy
	select 
		KQ.MaPhieu,
		KQ.MaChiDinh,
		format(" + sqlNgay + ",'dd/MM/yyyy HH:mm') as Ngay, " +
        "KQ.MaBN," +
        "KQ.HoTen," +
        "KQ.GioiTinh ," +
        "KQ.TenDV," +
        "KQ.MaChiDinh," +
        "KQ.TinhTrang," +
        "TT.TenTinhTrang," +
        "KQ.Block," +
        "isNull((select top 1 lydo from CanLamSang..CLS_LOG_KetQua log where log.maphieu=KQ.MaPhieu order by ngaythaydoi desc),'') as LyDo," +
        "KQ.MaVP," +
        "KQ.MaVP_ChiTiet," +
        "case when KQ.DoiTuong Like N'%Bảo Hiểm%' then '1'else '0' end as BH" +
    " from CanLamSang..Ketqua_CLS KQ" +
    " left join (select ID,TenTinhTrang from CanLamSang..TinhTrang_KQ_CLS) TT on TT.ID = KQ.TinhTrang" +
    " where " + khoanhom_Query + htmltong + " and " + sqlNgay + " between '" + TuNgay + " 00:00:00' and '" + DenNgay + " 23:59:59' " +
    " order by " + sqlNgay + " desc ";
            return db.excuteQueryStringJson();
        }
    }
}