﻿using CanLamSang.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CanLamSang.Controllers
{
    public class PartialViewController : Controller
    {
        // GET: PartialView
        public ActionResult ThongTinHanhChanh()
        {
            return PartialView();
        }

        public ActionResult VungMoTa()
        {
            return PartialView();
        }

        public ActionResult HinhAnhIn()
        {
            return PartialView();
        }

        public ActionResult DanhSachHinhAnh()
        {
            return PartialView();
        }

        public ActionResult MenuKetQua()
        {
            return PartialView();
        }

        public ActionResult Menu_KQ_DanhSachBenhNhanCho()
        {
            return PartialView();
        }

        public ActionResult Menu_KQ_UploadFile()
        {
            return PartialView();
        }
        public ActionResult Menu_KQ_DanhSachKQ()
        {
            return PartialView();
        }
        public ActionResult Menu_KQ_DanhSachKQ_GPB()
        {
            return PartialView();
        }
        public ActionResult Menu_KQ_DanhSachCho_GPB()
        {
            return PartialView();
        }
        public ActionResult PhieuInYkhoa()
        {
            return PartialView();
        }

        public ActionResult ThongTinPhienBan()
        {
            return PartialView();
        }
        public ActionResult VungMoTaOrder()
        {
            return PartialView();
        }
        public ActionResult EditGhiChu()
        {
            return PartialView();
        }
        public ActionResult PhieuLayMau()
        {
            return PartialView();
        }

        [HttpPost]
        public string dbGetDScho(string TuNgay, string DenNgay, bool DaSuDung, bool Huy, bool UuTien, bool MacDinh, bool CapCuu)
        {
            string tungay = TuNgay + " 00:00:00";
            string denngay = DenNgay + " 23:59:59";
            string htmldasudung = "";
            string htmlhuy = "";
            string htmlUutien = "";
            string htmlCapCuu = "";
            string htmlTong = "";
            if (MacDinh == false)
            {
                if (DaSuDung == true)
                {
                    htmldasudung = " ds.SuDung = 1 and ds.Huy = 0 ";
                };
                if (Huy == true)
                {
                    htmlhuy = " ds.Huy = 1 ";
                };
                if (UuTien == true)
                {
                    htmlUutien = " ds.UuTien = 1  and ds.Huy = 0 and ds.SuDung = 0 ";
                };
                if (CapCuu == true)
                {
                    htmlCapCuu = " ds.CapCuu = 1 and ds.Huy = 0 and ds.SuDung = 0 ";
                };

                string[] check = new string[] { htmldasudung, htmlhuy, htmlUutien, htmlCapCuu };
                bool flag = false;
                foreach (string item in check)
                {
                    if (item != "")
                    {
                        if (flag == false)
                        {
                            htmlTong += item;
                            flag = true;
                        }
                        else
                            htmlTong += " or " + item;
                    }
                }
                if (htmlTong != "")
                    htmlTong = " and (" + htmlTong + ")";
            }
            else // Mặc định chi load tất cả không sử dụng or Hủy và có Cấp Cứu , Ưu Tiên
            {
                htmlTong = " and ds.Huy = 0 and ds.SuDung = 0 ";
            }
            string khoanhom_Query = "";
            if (Session[cSessionName.NhomDichVu].ToString() == "")
            {
                khoanhom_Query = " ds.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and ds.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + " '";
            }
            else
            {
                khoanhom_Query = " ds.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and ds.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and ds.NhomDichVu ='" + Session[cSessionName.NhomDichVu].ToString() + "'";
            }
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"set dateformat dmy select ds.Hoten,ds.MaBN,
	                            case ds.GioiTinh when '1' then 'Nam' else  N'Nữ' end as GioiTinh,
	                            ds.MaChiDinh,
	                            format(ds.Ngay,'dd/MM/yyyy HH:mm') as ThoiGianChiDinh,
	                            ds.MaDV,
	                            ds.TenDichVu,
	                            ds.MaNoiChiDinh,
	                            ds.Huy,
	                            isnull(ds.Uutien,'0') as UuTien,
	                            ds.CapCuu,
	                            ds.MaPhieu as MaVP,
                                ds.SuDung,
isnull(ds.TenBSCD,'') as TenBSCD,
ds.DoiTuong,
isnull(ds.MaBA,'') as MaBA,
isnull(ds.Madotkham,'') as Madotkham,
bh.TenDT,
ds.IDcoso,
	                            ds.IDCT as MaVPChiTiet,
	                            case when isnull(Kngoaitru.TenKhoa,'')!='' then isnull(Kngoaitru.TenKhoa,'') else isnull(Knoitru.TenKhoa,'') end as NoiChiDinh,
                                case when bh.TenDT Like N'%Bảo Hiểm%' then '1'else '0' end as BH
                            from CanLamSang..DS_ChoCLS ds
                            left join (SELECT TenKhoa,MaKhoa FROM Quantri..DM_KHOA) Kngoaitru on ds.MaNoiChiDinh= Kngoaitru.MaKhoa                                
                            left join  (select idKhoa,TenKhoa from QLNOITRU..DM_Khoa) Knoitru on ds.MaNoiChiDinh=convert(nvarchar,Knoitru.idKhoa)
                            left join (select TenDT,MADT from Quantri..DM_DoiTuong_BN) bh on ds.DoiTuong = bh.MADT
                            where " + khoanhom_Query + htmlTong +
                            " and ds.Ngay between '" + tungay + "' and '" + denngay + "' order by ds.Ngay asc";
            return db.excuteQueryStringJson();
        }

        [HttpPost]
        public string dbGetDanhSachKQ(string TuNgay, string DenNgay, bool Khoa, bool Huy, bool MacDinh, bool Sua,string CheckTT, string loaiDS)
        {
            string htmltong = "";
            if (MacDinh == false)
            {
                if (Khoa == true)
                {
                    htmltong = " and KQ.Block = 1 ";
                }
                if (Huy == true)
                {
                    htmltong = " and KQ.TinhTrang = 0 and KQ.Block = 0 ";
                }
                if (Sua == true)
                {
                    if (CheckTT != "1")
                    {
                        htmltong = " and KQ.TinhTrang = 4 and KQ.Block = 0 ";
                    }
                    else
                    {
                        htmltong = " and KQ.TinhTrang = 5 and KQ.Block = 0 ";
                    }
                }
            }
            else
            {
                if (CheckTT != "1") {
                    if (loaiDS != "Cho")
                    {
                        htmltong = " and (KQ.TinhTrang = 2 or KQ.TinhTrang  = 4 or KQ.TinhTrang = 1 or KQ.TinhTrang = 5) and KQ.Block = 0 ";
                    }
                    else
                    {
                        htmltong = " and (KQ.TinhTrang = 1 or KQ.TinhTrang = 5) and KQ.Block = 0 ";
                    }
                }else
                {
                    htmltong = " and (KQ.TinhTrang = 1 or KQ.TinhTrang = 5) and KQ.Block = 0 ";
                }
            }
            ///--------------------------------------------------------
            string sqlNgay = "";
            if (CheckTT != "1") // Tình trạng là 1 thì DSKQ sẽ tìm kiếm theo ngày chup hình ,nếu không phải là 1 thì tìm theo điều kiện ở dưới
            {
                if (loaiDS != "Cho") // LoaiDS là Cho thì DSKQ sẽ tìm kiếm theo ngày chup hình ,nếu không phải là KQ thì tìm theo ngày kết quả
                {
                    sqlNgay = " KQ.Ngay";
                }
                else
                {
                    sqlNgay = " KQ.NgayChupHinh";
                }
            }
            else
            {
                sqlNgay = " KQ.NgayChupHinh";
            }
            //-------------------------------------------------------------
            string khoanhom_Query = "";
            if (Session[cSessionName.NhomDichVu].ToString() == "")
            {
                khoanhom_Query = " KQ.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and KQ.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + " '";
            }
            else
            {
                khoanhom_Query = " KQ.NhomChuyenKhoa = '" + Session[cSessionName.NhomChuyenKhoa].ToString() + "' and KQ.ChuyenKhoa = '" + Session[cSessionName.ChuyenKhoa].ToString() + "' and KQ.NhomDichVu ='" + Session[cSessionName.NhomDichVu].ToString() + "'";
            }
           
            string User_Query = "";
            if (loaiDS == "KQ") {
                if (CheckTT == "1")
                {
                   
                    User_Query = " and KQ.MaKTVChupHinh='" + Session[cSessionName.username] + "' ";
                }
                else
                {
                    User_Query = " and KQ.MaBSCDHA='" + Session[cSessionName.username] + "' ";
                }
            }
            else
            {
                User_Query = "";
            }
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"set dateformat dmy
	select 
		KQ.MaPhieu,
		KQ.MaChiDinh,
		format(KQ.Ngay,'dd/MM/yyyy HH:mm') as Ngay, 
		KQ.MaBN,
		KQ.HoTen,
		KQ.GioiTinh ,
		KQ.TenDV,
        KQ.MaChiDinh,
		KQ.TinhTrang,
		TT.TenTinhTrang,
        KQ.Block,
		isNull((select top 1 lydo from CanLamSang..CLS_LOG_KetQua log where log.maphieu=KQ.MaPhieu order by ngaythaydoi desc),'') as LyDo,
		KQ.MaVP,
		KQ.MaVP_ChiTiet,
case when KQ.DoiTuong Like N'%Bảo Hiểm%' then '1'else '0' end as BH
	from CanLamSang..Ketqua_CLS KQ
	left join (select ID,TenTinhTrang from CanLamSang..TinhTrang_KQ_CLS) TT on TT.ID = KQ.TinhTrang
where " + khoanhom_Query + htmltong + " "+ User_Query + " and "+ sqlNgay + " between '" + TuNgay + " 00:00:00' and '" + DenNgay + " 23:59:59' " +
" order by "+ sqlNgay + " desc ";
            return db.excuteQueryStringJson();
        }

        [HttpPost]
        public string dbXoaPhieuKQ(string MaPhieu, string LyDo, string MaVP, string MaVP_CT,string MaChiDinh)
        {
            cDBAccess db = new cDBAccess();
            db.sqlQuery = @"CanLamSang..sp_CLS_HuyKQ";
            db.addParameter("MaPhieu", SqlDbType.NVarChar, MaPhieu);
            db.addParameter("NguoiThayDoi", SqlDbType.NVarChar, Session[cSessionName.username].ToString());
            db.addParameter("LyDo", SqlDbType.NVarChar, LyDo);
            db.addParameter("MaVP", SqlDbType.NVarChar, MaVP);
            db.addParameter("MaVP_CT", SqlDbType.NVarChar, MaVP_CT);
            db.addParameter("MaCD", SqlDbType.NVarChar, MaChiDinh);
            return db.excuteStoreStringJson();
        }
    }
}

