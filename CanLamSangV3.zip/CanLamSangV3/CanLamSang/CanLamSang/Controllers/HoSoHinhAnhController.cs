﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
namespace CanLamSang.Controllers
{
    public class HoSoHinhAnhController : Controller
    {
        // GET: HoSoHinhAnh
        public ActionResult HoSoHinhAnh()
        {
            return View();
        }
        public ActionResult HetSessionHSHA()
        {
            return View();
        }

        public ActionResult ShowThongTinHSHA()
        {
            return View();
        }
        public ActionResult TimKiemHinhAnh()
        {
            return View();
        }
        public ActionResult ShowHinhAnhvaEditGhiChu()
        {
            return View();
        }
        [HttpPost]
        public string LoadTenKhoa()
        {
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"select distinct Ten,ChuyenKhoa,NhomDichVu from CanLamSang..vSearchIMG ";
            return db.excuteQueryStringJson();
        }

        [HttpPost]
        public string GetAutoComplete(string Ten, bool CD, bool DV)
        {
            string strquery = "";
            if (CD == true)
            {
                strquery = " ChanDoan ";
            }
            else
            {
                strquery = " TenDV ";
            }

            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"select  distinct top 10 " + strquery + " as Ten from CanLamSang..vSearchIMG where " + strquery + " like N'%" + Ten + "%'";
            return db.excuteQueryStringJson();
        }

        [HttpPost]
        public string GetHinhBenhNhan(string Ten, bool CD, bool DV, string TuNgay,string DenNgay,int TuoiTu, int TuoiDen,string Khoa)
        {
            string strquery = "";
            if (CD == true)
            {
                strquery = " ChanDoan ";
            }
            else
            {
                strquery = " TenDV ";
            }
            string strKhoa = "";
            if (Khoa == "")
            {
                strKhoa = "";
            }
            else
            {
                strKhoa = " and ChuyenKhoa ='"+ Khoa + "' ";
            }

            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"set dateformat dmy select LinkHinhAnh,TenHinhAnh,MaPhieu,GhiChu from CanLamSang..vSearchIMG where " + strquery + " =  N'" + Ten + "' "+ strKhoa + " and NgayKQ between  '" + TuNgay + " 00:00:00' and '" + DenNgay + " 23:59:59' and (Convert(int ,Tuoi) >= " + TuoiTu+" and Convert(int ,Tuoi) <= "+TuoiDen+ ") order by NgayKQ desc ";
            return db.excuteQueryStringJson();
        }
        [HttpPost]
        public string GetThongTinShow(string HinhAnh, string MaPhieu)
        {
            string html = "";
            string htmlTenHinhAnh = "";
            if (HinhAnh == "")
            {
                html = "top 1.";
                htmlTenHinhAnh = "";
            }
            else
            {
                html = "";
                htmlTenHinhAnh = "and TenHinhAnh='" + HinhAnh + "'";
            }
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"select "+html+"* from CanLamSang..vSearchIMG where MaPhieu = '"+MaPhieu+"' "+htmlTenHinhAnh+"";
            return db.excuteQueryStringJson();
        }
        [HttpPost]
        public string GetThongTinHinhAnhBN(string MaPhieu)
        {
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @"select LinkHinhAnh,TenHinhAnh,GhiChu from CanLamSang..vSearchIMG where MaPhieu = '" + MaPhieu + "'";
            return db.excuteQueryStringJson();
        }
        [HttpPost]
        public string GetAutoCompleTaiBienThuThuat(string loai,string ChuyenKhoa)
        {
            string html = "";
            string sqlChuyenKhoa = "";
            if(ChuyenKhoa == "")
            {
                sqlChuyenKhoa = "";
            }
            else
            {
                sqlChuyenKhoa = "where ChuyenKhoa = '" + ChuyenKhoa + "'";
            }
            if (loai == "TT")
            {
                html = "select Ten,id from CanLamSang..CLS_CacLoaiTaiBien "+ sqlChuyenKhoa + "";
            }
            else
            {
                html = "select Ten,id from CanLamSang..CLS_ThuThuat " + sqlChuyenKhoa + "";
            }
            
            Models.cDBAccess db = new Models.cDBAccess();
            db.sqlQuery = @""+html+"";
            return db.excuteQueryStringJson();
        }
    }
}