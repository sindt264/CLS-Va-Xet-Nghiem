﻿using System.Web;
using System.Web.Optimization;

namespace CanLamSang.App_Start
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new StyleBundle("~/bundles/cssCore").Include(
                        "~/Public/lib/foundation-6.4.2-complete/css/foundation.css",
                        "~/Public/css/custom.css",
                        "~/Public/css/loading-css.css",
                        "~/Public/lib/Hover-master/css/hover-min.css",
                        "~/Public/lib/DataTables/datatables.min.css",
                        "~/Public/lib/datetimepicker/jquery.datetimepicker.css")
            //.Include("~/Public/lib/fontawesome-free-5.1.0-web/css/all-server.css", new CssRewriteUrlTransform()));
            .Include("~/Public/lib/fontawesome-free-5.1.0-web/css/all-local.css", new CssRewriteUrlTransform()));

            bundles.Add(new ScriptBundle("~/bundles/jsCore").Include(
                        "~/Public/lib/foundation-6.4.2-complete/js/vendor/jquery.js",
                        "~/Public/lib/foundation-6.4.2-complete/js/vendor/what-input.js",
                        "~/Public/lib/foundation-6.4.2-complete/js/vendor/foundation.min.js",
                        "~/Public/lib/DataTables/datatables.min.js",
                        "~/Public/lib/datetimepicker/jquery.datetimepicker.js",
                        "~/Public/js/Layout.js"));
            BundleTable.EnableOptimizations = true;
        }
    }
}
