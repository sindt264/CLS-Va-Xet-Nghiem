﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace CanLamSang.Models
{
    public class cDBAccess
    {
        //Anova
        //private string sConnection = @"server= '45.119.213.19,57066'; uid=sa;pwd=!@#321;database=CanLamSang";

        //Kiên Giang
        private string sConnection = "";

        public string sqlQuery = "";
        private List<SqlParameter> sqlParameters = new List<SqlParameter>();

        //Khởi tạo
        public cDBAccess()
        {
            sConnection = @""+System.Configuration.ConfigurationManager.AppSettings["Location"];
            //switch (System.Configuration.ConfigurationManager.AppSettings["Location"])
            //{
            //    case "YkhoanetKG":
            //        sConnection = @"server= '192.168.1.6,6433'; uid=sa;pwd=ykn@TT@2018;database=CanLamSang";
            //        break;
            //    case "YkhoanetKG": //KienGiang
            //        sConnection = @"server= '.\YKHOANEW'; uid=sa;pwd=ykn@TT@2018;database=CanLamSang";
            //        break;
            //    case "Anova":
            //        sConnection = @"server= '45.119.213.19,57066'; uid=sa;pwd=!@#321;database=CanLamSang";
            //        break;
            //}
        }

        // <summary>
        /// Hàm excute query trả về chuỗi duy nhất
        /// </summary>
        /// <returns></returns>
        public string excuteQueryStringReturnOneValue()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sConnection))
                {
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        con.Open();
                        DataTable dt = new DataTable();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                            return dt.Rows[0][0].ToString();
                        else
                            return "error";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Hàm excute query trả về obj {status: '', message: ''}
        /// </summary>
        /// <returns></returns>
        public string excuteQueryStringReturnStatus(string doneMessage, string errorMessage)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sConnection))
                {
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        con.Open();
                        int rs = cmd.ExecuteNonQuery();
                        if (rs > 0)
                            return JsonConvert.SerializeObject(new { status = "done", message = doneMessage }, Formatting.Indented);
                        else
                            return JsonConvert.SerializeObject(new { status = "done", message = errorMessage }, Formatting.Indented);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// truyền vào sql query trả về chuỗi JSON kết quả của query
        /// </summary>
        /// <returns></returns>
        public string excuteQueryStringJson()
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(sConnection))
                {
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        con.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dt);

                        return JsonConvert.SerializeObject(dt, Formatting.Indented);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Thực hiện procedure trả về datatable result
        /// </summary>
        /// <returns></returns>
        public DataTable excuteProcDatatable()
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(sConnection))
                {
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        //cmd.CommandText = sqlQuery;
                        //cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        foreach (SqlParameter para in sqlParameters)
                        {
                            cmd.Parameters.Add(para);
                        }

                        da.Fill(dt);
                        return dt;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Hàm excute Store có tự động add Parameter
        /// </summary>
        /// <returns></returns>
        public string excuteStoreStringJson()
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(sConnection))
                {
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        //cmd.CommandText = sqlQuery;
                        //cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        foreach (SqlParameter para in sqlParameters)
                        {
                            cmd.Parameters.Add(para);
                        }

                        da.Fill(dt);

                        return JsonConvert.SerializeObject(dt, Formatting.Indented);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Hàm truyền vào parameter cho store
        /// </summary>
        /// <param name="paraName">Tên parameter</param>
        /// <param name="type">Kiểu dữ liệu</param>
        /// <param name="value">Giá trị</param>
        public void addParameter(string paraName, SqlDbType type, string value)
        {
            SqlParameter para = new SqlParameter();
            para.SqlDbType = type;
            para.ParameterName = paraName;
            switch (type)
            {
                case SqlDbType.Bit:
                    para.Value = value == "1" ? true : false;
                    break;
                default:
                    para.Value = value;
                    break;
            }
            sqlParameters.Add(para);
        }
    }
}