﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CanLamSang.Models
{
    public class cSessionName
    {
        public static string hoten { set; get; } = "HoTen";
        public static string username { set; get; } = "UserName";
        public static string chucvu { set; get; } = "ChucVu";

        public static string NhomChuyenKhoa { set; get; } = "NhomChuyenKhoa";
        public static string ChuyenKhoa { set; get; } = "ChuyenKhoa";
        public static string NhomDichVu { set; get; } = "NhomDichVu";
        public static string TenKhoa { set; get; } = "TenKhoa";

        public static string NhomPhanQuyen { set; get; } = "NhomPhanQuyen";

        public static string url { set; get; } = "URL";

        public static string defaultPath_local { set; get; } = "d_pathFolder_local";
        //public static string defaultPath_online { set; get; } = "d_pathFolder_online";

        public static string bn_maphieuCLS { set; get; } = "MaPhieuCLS";
        public static string bn_mavp { set; get; } = "MaVP";
        public static string bn_mavp_chitiet { set; get; } = "MaVP_ChiTiet";
        public static string bn_mabn { set; get; } = "MaBN";
        public static string bn_macd { set; get; } = "MaCD";

        public static string PathLinkOnline { set; get; } = "PathLinkOnline";

    }
}