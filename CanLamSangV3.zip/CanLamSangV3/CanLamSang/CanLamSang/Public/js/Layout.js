﻿//-----------------------------------------------//
//Loại bỏ ký tự đặt biệt(sử dụng khi lưu dữ liệu tránh phát sinh lỗi
String.prototype.escapeSpecialChars = function () {
    return this.replace(/\\n/g, "\\n")
        .replace(/\\'/g, "\\'")
        .replace(/\\"/g, '\\"')
        .replace(/\\&/g, "\\&")
        .replace(/\\r/g, "\\r")
        .replace(/\\t/g, "\\t")
        .replace(/\\b/g, "\\b")
        .replace(/\\f/g, "\\f");
};

_language = { sProcessing: "Đang xử lý...", sLengthMenu: "Xem _MENU_ mục", sZeroRecords: "Không có dữ liệu", sInfo: "Đang xem _START_ đến _END_ (Tổng số: _TOTAL_)", sInfoEmpty: "Đang xem 0 đến 0 trong tổng số 0 mục", sInfoFiltered: "(được lọc từ _MAX_ mục)", sInfoPostFix: "", sSearch: "Tìm:", sUrl: "", oPaginate: { sFirst: "Đầu", sPrevious: "Trước", sNext: "Tiếp", sLast: "Cuối" }, select: { rows: "Đã chọn: %d" } }
$.extend(true, $.fn.dataTable.defaults, {
    "language": _language
});

$.ajaxSetup({
    type: "POST",
    timeout: 10000,
    error: (xhr, status, error) => {
        fnShowErrorAjax(xhr);
    },
    dataType: "json",
    contentType: "application/json",
    beforeSend: (xhr, settings) => {
        if (settings.url.indexOf("CanLamSang") === -1) {
            settings.url = "/CanLamSang" + settings.url;
        }

        fnShowLoading();
        if (!fnCheckSession()) {
            xhr.abort();
            fnShowPopupLogin();
        }
    },
    complete: () => {
        setTimeout(function () {
            fnCloseLoading();
        }, 500);
    }
});

//document ready
$(() => {
    $(document).foundation();
    fnSetEventLogin();
    $('.submenu').removeClass('hide');

    $('#modalLoginForm').on('open.zf.reveal', function () {
        var modal = $(this);
        modal.find('#txtUserName').focus();
    });

    if (!fnCheckSession()) fnShowPopupLogin();
    //addEvents();
    fnHighLight();
});

/**Hàm check session có tồn tại hay không 
 * @returns {bool} bool
 */
function fnCheckSession() {
    var bool = false;
    $.ajax({
        url: '/CanLamSang/Home/CheckSession',
        data: JSON.stringify({ makhoa: _sessionMaKhoa, manhom: _sessionMaNhom }),
        beforeSend: (xhr) => {
            //fnShowLoading();
        },
        async: false,
        success: (rs) => {
            if (rs.status === 'done')
                bool = true;
            else
                $('#modalLogin_message').text(rs.message);
        }
    });
    return bool;
}

//Huân rèm 10/09/2018
//function addEvents() {
//    document.addEventListener('focus', fnFocus_BlurHandler);
//}

//var _flag_lost_session = false;
//function fnFocus_BlurHandler() {
//    if (_flag_lost_session)
//        return;
//    if (!fnCheckSession()) {
//        _flag_lost_session = true;
//        fnShowPopupLogin();
//    }
//}

/**Hàm khởi tạo event login khi trang vừa load */
function fnSetEventLogin() {
    $.ajax({
        url: '/CanLamSang/Home/GetKhoaCLS',
        async: false,
        beforeSend: (xhr) => {
            //fnShowLoading();
        },
        success: function (rs) {
            $('#slKhoa').html(rs[0].DMKhoa);
        }
    });

    $('#txtPassWord').keypress((e) => {
        if (e.keyCode === 13)
            $('#btnLogin').click();
    });
    $('#btnLogin').click(() => {
        var _data = {
            username: $('#txtUserName').val(),
            password: $('#txtPassWord').val(),
            idkhoacls: $('#slKhoa').val()
        };
        $.ajax({
            url: '/CanLamSang/Home/DangNhap',
            data: JSON.stringify(_data),
            beforeSend: (xhr) => { fnShowLoading(); },
            success: (rs) => {
                fnShowPopupMessage(rs);
                if (rs[0].status === "done")
                    setTimeout(function () {
                        window.location.reload();
                    }, 500);
            }
        });
    });
}

/**Hàm đăng xuất */
function fnLogout() {
    $.ajax({
        url: '/CanLamSang/Home/SessionAbandon',
        success: function (rs) {
            if (rs.status === 'done')
                fnShowPopupLogin();
            else
                fnShowPopupMessage({ status: 'error', message: 'Lỗi! Không thể thoát phiên làm việc! Kết nối với Server có lỗi! Vui lòng liên hệ IT.' });
        }
    });
}

/**Hàm set menu link highlight */
function fnHighLight() {
    if (document.location.pathname.toLowerCase() === "/canlamsang/" || document.location.pathname.toLowerCase() === "/canlamsang")
        return;
    var link = document.location.pathname;
    var _a = $('a[href="' + link + '"]');
    if (_a.length > 0) {
        $(_a[0]).addClass('active');
    }
    else {
        window.location.href = '/CanLamSang/';
    }
}

/**Hàm hiển thị popup login */
function fnShowPopupLogin() {
    $('#modalLoginForm').foundation('open');
    fnSetZindex('#modalLoginForm');
}

/**
 * Hàm hiển thị popup thông báo
 * @param {object} rs object [{status:'', message:''}] hoặc {status:'', message:''}
 * @param {function} callBack hàm callback chạy sau khi popup message đóng 
 */
function fnShowPopupMessage(rs, callBack) {
    if (rs.length !== undefined) {
        if (rs[0].status === 'error')
            $('#titleModal').html('<i style="color: orangered;" class="fas fa-exclamation-circle"></i>Lỗi');
        else
            $('#titleModal').html('Thông báo');
        $('#Message').html(rs[0].message);
    }
    else {
        if (rs.status === 'error')
            $('#titleModal').html('<i style="color: orangered;" class="fas fa-exclamation-circle"></i>Lỗi');
        else
            $('#titleModal').html('Thông báo');
        $('#Message').html(rs.message);
    }
    $('#modalMessageTiny').foundation('open').on('closed.zf.reveal', function () {
        if (callBack !== undefined && typeof callBack === 'function') {
            try {
                callBack();
            }
            catch (error) {
                alert(error.message);
                console.log(error);
            }
        }
    });
    fnSetZindex($('#modalMessageTiny'));
}

/**
 * Hàm hiển thị loading
 * @param {string} _text chuỗi text hiển thị khi loading
 */
function fnShowLoading(_text) {
    $('#divLoading').foundation('open');
    if (_text !== undefined) {
        $('#textLoading').text(_text);
    }
    else {
        $('#textLoading').text("Đang tải, vui lòng chờ ... ");
    }
    fnSetZindex($('#modalConfirm'));
}
function fnCloseLoading() {
    $('#divLoading').foundation('close');
}

/**
 * Hàm hiển thị popup confirm
 * @param {any} message chuỗi thông báo
 * @param {any} callBack hàm callback
 */
function fnShowConfirm(message, callBack) {
    $("#btnConfirm").off("click");
    $('#MessageConfirm').text(message);
    $('#modalConfirm').foundation('open');
    $('#btnConfirm').click(function (event) {
        event.preventDefault();
        try {
            $('#modalConfirm').foundation('close');
            callBack();
        }
        catch (error) {
            alert(error.message);
            console.log(error);
        }
    });
    fnSetZindex($('#modalConfirm'));
}

/**
 * Hàm set zindex cho popup
 * @param {JQuery} obj DOM jquery muốn set z-index
 */
function fnSetZindex(obj) {
    var maxZindex = 0;
    $('.reveal-overlay').each(function () {
        if ($(this).css('display') === 'block') {
            var temp = parseInt($(this).css('z-index'));
            if (temp > maxZindex)
                maxZindex = temp;
        }
    });
    $(obj).closest('.reveal-overlay').css('z-index', (maxZindex + 10));
}

/**
 * Hàm replace chuỗi string null hoặc undefined thành chuỗi rỗng
 * @param {string} string chuỗi string cần kiểm tra
 * @returns {string} string return
 */
function fnReplaceNullString(string) {
    if (string === 'null' || string === undefined)
        return '';
    else
        return string;
}

/**
 * Hàm hiển thị popup thông báo lỗi từ Ajax
 * @param {JQueryXHR} xhr jquery XHR
 */
function fnShowErrorAjax(xhr) {
    $('#containerHtmlError').html(xhr.responseText);
    $('#ErrorModalAjax').foundation('open');
    fnSetZindex('#ErrorModalAjax');
}
/**
* Thay đổi mật khẩu
*/
function fnShowpopupchangePass() {
    fnlammoichange();
    $('#modalChangePassword').foundation('open');
}
function fnlammoichange() {
    $('#MaKhauCu').val('');
    $('#MaKhauMoi').val('');
    $('#NhapLaiMaKhau').val('');
}
function fnbatloi() {
    if ($('#MaKhauCu').val() === "") {
        fnShowPopupMessage({ status: 'error', message: 'Xin vui lòng nhập mật khẩu hiện tại!' });
        return false;
    }
    if ($('#MaKhauMoi').val() === "") {
        fnShowPopupMessage({ status: 'error', message: 'Xin vui lòng không bỏ trống mật khẩu mới' });
        return false;
    }
    if ($('#MaKhauMoi').val() !== $('#NhapLaiMaKhau').val()) {
        $('#MaKhauMoi').val('');
        $('#NhapLaiMaKhau').val('');
        fnShowPopupMessage({ status: 'error', message: 'Mật khẩu nhập lại không giống mật khẩu mới' });
        return false;
    }
    return true;
}
function fnSetChangePass() {
    if (fnbatloi() === false)
        return;
    var _data = {
        MatKhauCu: $('#MaKhauCu').val(),
        MatKhauMoi: $('#MaKhauMoi').val()
    };
    $.ajax({
        url: '/Home/ChangePassword',
        data: JSON.stringify(_data),
        success: (rs) => {
            fnShowPopupMessage(rs);
            if (rs[0].status !== 'error') {
                fnlammoichange();
                $('#modalChangePassword').foundation('close');
            }
        }
    })
    
}

