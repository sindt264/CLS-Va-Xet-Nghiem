﻿String.prototype.escapeSpecialChars = function () {
    return this.replace(/\\n/g, "\\n")
        .replace(/\\'/g, "\\'")
        .replace(/\\"/g, '\\"')
        .replace(/\\&/g, "\\&")
        .replace(/\\r/g, "\\r")
        .replace(/\\t/g, "\\t")
        .replace(/\\b/g, "\\b")
        .replace(/\\f/g, "\\f");
};
$(() => {
    $(document).foundation();
});

function fnShowLoading(_text) {
    $('#divLoading').foundation('open');
    if (_text != undefined) {
        $('#textLoading').text(_text);
    }
    else {
        $('#textLoading').text("Đang tải, vui lòng chờ ... ");
    }
    fnSetZindex($('#modalConfirm'));
}
function fnCloseLoading() {
    $('#divLoading').foundation('close');
}
function fnShowPopupMessage(rs, callBack) {
    /// <summary>Hiển thị popup</summary>
    /// <param name="radiusParam" type="object">Object message</param> 
    ///  <returns type="void"></returns>  
    if (rs.length != undefined) {
        if (rs[0].status == 'error')
            $('#titleModal').html('<i style="color: orangered;" class="fas fa-exclamation-circle"></i>Lỗi');
        else
            $('#titleModal').html('Thông báo');
        $('#Message').html(rs[0].message);
    }
    else {
        if (rs.status == 'error')
            $('#titleModal').html('<i style="color: orangered;" class="fas fa-exclamation-circle"></i>Lỗi');
        else
            $('#titleModal').html('Thông báo');
        $('#Message').html(rs.message);
    }
    $('#modalMessageTiny').foundation('open').on('closed.zf.reveal', function () {
        if (callBack != undefined && typeof callBack == 'function') {
            try {
                callBack();
            }
            catch (error) {
                alert(error.message);
                console.log(error);
            }
        }
    });
    fnSetZindex($('#modalMessageTiny'));
}
function fnSetZindex(obj) {
    var maxZindex = 0;
    $('.reveal-overlay').each(function () {
        if ($(this).css('display') == 'block') {
            var temp = parseInt($(this).css('z-index'));
            if (temp > maxZindex)
                maxZindex = temp;
        }
    });
    $(obj).closest('.reveal-overlay').css('z-index', (maxZindex + 10));
}
/**
 * Hàm hiển thị popup confirm
 * @param {any} message chuỗi thông báo
 * @param {any} callBack hàm callback
 */
function fnShowConfirm(message, callBack) {
    $("#btnConfirm").off("click");
    $('#MessageConfirm').text(message);
    $('#modalConfirm').foundation('open');
    $('#btnConfirm').click(function (event) {
        event.preventDefault();
        try {
            $('#modalConfirm').foundation('close');
            callBack();
        }
        catch (error) {
            alert(error.message);
            console.log(error);
        }
    });
    fnSetZindex($('#modalConfirm'));
}