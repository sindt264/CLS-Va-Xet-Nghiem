﻿
//******** SELECT **********//
/**
 * Load ID Cuối Cùng */
function fnIDCuoiCung() {
    var data = {
        loaiselect: 'IDCuoiCung'
    }
    $.ajax({
        url: "/QuanLy/ProSelect",
        data: JSON.stringify(data),
        success: function (rs) {
            $('span[name=IDCuoiCung]').text(rs[0].id);
            $('#NhomQuyen_IDProfile').val((rs[0].id + 1));
        }
    });
}
/**
 * Load List tree nhóm quyền */
function fnListNhomQuyen() {
    var data = {
        loaiselect: 'ListTreeNhomQuyen'
    }
    $.ajax({
        url: "/QuanLy/ProSelect",
        data: JSON.stringify(data),
        success: function (rs) {
            $('#listNhomQuyen').html('');
            $('#listButtonMinus').html('');
            var html = "";
            var htmlButtonMius = "";
            $(rs).each(function (i, item) {
                html += "<li data-jstree='{\"icon\":\"fa fa-caret-right\"}'  value='" + item.IDProfile + "'>" + item.MaNhom + "</li>";
                htmlButtonMius +=
                    "<div class='cell large-12' style='height:24px;text-align:center'>" +
                    "<i class='far fa-minus-square' style ='color:red;font-size:24px;' onclick=fnEventMinus('" + item.IDNhomQuyen + "','" + item.IDProfile + "','" + item.MaNhom + "')></i>" +
                    "</div>";
            });
            html = "<ul>" + html + "</ul>";
            $('#listNhomQuyen').append(html);
            $('#listButtonMinus').append(htmlButtonMius);
            $('#listNhomQuyen').on('changed.jstree', function (e, data) {
                loadEventchonnhomquyen(data.node.li_attr.value);
                $('#txtNhomQuyen').text(data.node.text);
            }).jstree();
        }
    });
}
/**
 * Load Table Profile*/
function fnLoadProfileTable() {
    var data = {
        loaiselect: 'LoadDSProfile'
    }
    $.ajax({
        url: "/QuanLy/ProSelect",
        data: JSON.stringify(data),
        success: function (rs) {
            if ($.fn.DataTable.isDataTable('#tableprofile')) {
                $('#tableprofile').DataTable().destroy();
            }
            var html = "";
            var htmlcb = "";
            $(rs).each(function (i, item) {
                if (item.hienthi == true) {
                    htmlcb = "<i class='far fa-check-square icheck' onclick=fnCbtable('" + item.id + "','1')></i>";
                } else {
                    htmlcb = "<i class='far fa-check-square inocheck' onclick=fnCbtable('" + item.id + "','0')></i>";
                }
                html += "<tr>" +
                    "<td style='text-align:center;'>" + (i + 1) + "</td>" +
                    "<td style='text-align:center;'>" + item.id + "</td>" +
                    "<td>" + item.ten + "</td>" +
                    "<td style='text-align:center;'>" + htmlcb + "</td>" +
                    "</tr>";
            });
            $('#tableprofile tbody').html(html);
            $('#tableprofile').DataTable({
                "bPaginate": false,
                orderCellsTop: true,
                "scrollY": ($('#divprofile').height() - 88) + "px",
                scrollCollapse: true,
                paging: false,
                "order": [0, 'asc']
            });
        }
    });
}
//-------------------------//
function fnThemNhomQuyen() {
    var data = {
        MaNhom: $('#NhomQuyen_MaNhom').val(),
        TenNhom: $('#NhomQuyen_TenNhom').val(),
        IDProfile: $('#NhomQuyen_IDProfile').val()
    }
    $.ajax({
        url: "/QuanLy/ThemNhomQuyen",
        data: JSON.stringify(data),
        success: function (rs) {
            console.log(rs);
            if (rs[0].status == "done") {
                alert(rs[0].message);
                fnListNhomQuyen();
                fnLoadTableNhomQuyen();
                fnLoadProfileTable();
                $('#NhomQuyen_IDProfile').val('');
                $('#NhomQuyen_TenNhom').val('');
                $('#NhomQuyen_MaNhom').val('');
            } else {
                alert(rs[0].message);
            }
        }
    });
}
function fnLoadTableNhomQuyen() {
    $.ajax({
        url: "/QuanLy/ListNhomQuyenCLS",
        success: function (rs) {
            if ($.fn.DataTable.isDataTable('#tbNhomQuyen')) {
                $('#tbNhomQuyen').DataTable().destroy();
            }
            var html = "";
            $(rs).each(function (i, item) {
                html += "<tr>" +
                    "<td style='text-align:center;'>" + item.MaNhom + "</td>" +
                    "<td>" + item.TenNhom + "</td>" +
                    "<td style='text-align:center;'>" + item.IDProfile + "</td>" +
                    "<td></td>" +
                    "</tr>";
            });
            $('#tbNhomQuyen tbody').html(html);
            $('#tbNhomQuyen').DataTable({
                "bPaginate": false,
                orderCellsTop: true,
                "scrollY": ($('#divprofile').height() - 60) + "px",
                scrollCollapse: true,
                paging: false,
                "order": [0, 'asc']
            });
        }
    });
}
//Chưa
function fnEventMinus(IDNhomQuyen, IDProfile, MaNhom) {

}
function fnEventOnChangeCheckBox() {
    if ($('#hienthi').val() == '1') {
        $('#cbhienthi').attr('style', 'font-size:24px;color:gray;');
        $('#hienthi').val('0');
    } else {
        $('#cbhienthi').attr('style', 'font-size:24px;color:#365899;');
        $('#hienthi').val('1');
    }
}

function fnCbtable(ID, hienthi) {
    var txthienthi = 0;
    if (hienthi == 1) {
        txthienthi = 0;
    } else {
        txthienthi = 1;
    }
    var _data = {
        ID: ID,
        hienthi: txthienthi
    };
    if (confirm('Bạn có chắc tiếp tục không?')) {
        $.ajax({
            url: "/QuanLy/CheckHienThi",
            data: JSON.stringify(_data),
            success: function (rs) {
                if (rs[0].status == "done") {
                    fnLoadProfileTable();
                } else {
                    alert(rs[0].message);
                }
            }
        });
    }
}
function loadEventchonnhomquyen(IDProfile) {
    var _data = {
        ID: IDProfile
    }
    $.ajax({
        url: "/QuanLy/LoadChiTietNhomQuyen",
        data: JSON.stringify(_data),
        success: function (rs) {
            $('#IDProfile').val(rs[0].IDProfile);
            $('#ten').val(rs[0].ten);
            if (rs[0].hienthi == 1) {
                $('#cbhienthi').attr('style', 'font-size:24px;color:#365899;');
                $('#hienthi').val('1');
            } else {
                $('#cbhienthi').attr('style', 'font-size:24px;color:gray;');
                $('#hienthi').val('0');
            }
            loadQuyen(rs[0].IDProfile);
        }
    });
}
function AutoComplete() {
    $('#txtTenQuyen').autocomplete(
        {
            showHeader: true,
            columns: [
                {
                    name: 'Mã Quyền',
                    width: '100px',
                    valueField: 'ID'
                },
                {
                    name: 'Tên Quyền',
                    width: '200px',
                    valueField: 'label'
                }
            ],
            source: function (request, response) {
                $.ajax({
                    url: "/QuanLy/AutoCompleteMaQuyen",
                    success: function (rs) {
                        response($.map(rs, function (item) {
                            return {
                                ID: item.MaQuyen,
                                label: item.Ten,
                                value: item.Ten
                            };
                        }));
                    }
                });
            },
            max: 0,
            highlight: false,
            scroll: true,
            minLength: 0,
            cacheLength: 10,
            scrollHeight: 5,
            select: function (event, ui) {
                var index = $(this).parents("tr").index() + 1;
                $(this).attr('data-text', ui.item.label);
                $(this).val(ui.item.label);
                $('#txtMaQuyen').val(ui.item.ID);
                return false;
            }
        });
    $('#txtTenQuyen').blur(function () {
        var $this = $(this);
        if ($.trim($this.val()) != $this.attr('data-text')) {
            if ($.trim($this.val()) == '') {
                $(this).attr('data-text', '');
            }
            else {
                $this.val($this.attr('data-text'));
            }
        }
    });
}
function RemoveRow(e) {
    var tr = $(e).closest('tr');
    var tbody = $(e).closest('tbody');
    $(tr).remove();
    $('tr', tbody).each(function (index, element) {
        $(element).find('td').eq(0).text(index + 1);
    });

    return false;
}
function clickAdd() {
    if ($('#txtTenQuyen').val() != "") {
        var objtr = "<tr id='row" + $("#profileChiTiet tbody tr").length + "'>" +
            "<td style='text-align: center;'>" + ($("#profileChiTiet tbody tr").length + 1) + "</td>" +
            "<td><input type=text name='MaQuyen' disabled value='" + $("#txtMaQuyen").val() + "' style='text-align: center;' /></td>" +
            "<td><input type=text name='TenQuyen' disabled value='" + $("#txtTenQuyen").val() + "' style='text-align: center;' /></td>" +
            "<td style='text-align: center;'><input type='button' id='btnxoa' style='background-color:red;color:white;border:red' value='-' onclick='RemoveRow(this)' class='btnadd' /></td>" +
            "</tr>";
        $("#profileChiTiet tbody").append(objtr);
        $("#txtMaQuyen").val('');
        $("#txtTenQuyen").val('');
    } else {
        alert('Chọn tên quyền!');
    }
}
/**
 * Load bảng quyền của nhóm khoa
 * @@param {string} IDProfile :IDProfile
 */
function loadQuyen(IDProfile) {
    var _data = {
        ID: IDProfile
    }
    $.ajax({
        url: "/QuanLy/LoadQuyen",
        data: JSON.stringify(_data),
        success: function (rs) {
            if ($.fn.DataTable.isDataTable('#tbBangQuyen')) {
                $('#tbBangQuyen').DataTable().destroy();
            }
            var html = "";
            $(rs).each(function (i, item) {
                html += "<tr>" +
                    "<td style='text-align:center;'>" + item.MaQuyen + "</td>" +
                    "<td>" + item.TenQuyen + "</td>" +
                    "<td style='text-align:center;'><i class='far fa-minus-square' style ='color:red;font-size:24px;' onclick=fnxoaQuyen('" + item.IDProfile_ChiTiet + "','" + item.IDTenQuyen + "','" + IDProfile + "')></i></td>" +
                    "</tr>";
            });
            $('#tbBangQuyen tbody').html(html);
            $('#tbBangQuyen').DataTable({
                "bPaginate": false,
                orderCellsTop: true,
                "scrollY": ($('#divprofile').height() - 88) + "px",
                scrollCollapse: true,
                paging: false,
                "order": [0, 'asc']
            });
        }
    });
}
/**
 * Xóa Quyền trên Bảng quyền
 * @@param {string} IDPCT :ID profile chi tiết;
 * @@param {string} IDTQ  :ID Tên quyền
 */
function fnxoaQuyen(IDPCT, IDTQ, IDProfile) {
    var data = {
        IDPCT: IDPCT,
        IDTQ: IDTQ
    }
    $.ajax({
        url: "/QuanLy/XoaQuyen",
        data: JSON.stringify(data),
        success: function (rs) {
            if (rs[0].status == 'done') {
                loadQuyen(IDProfile);
                alert(rs[0].message);
            } else {
                alert(rs[0].message);
            }
        }
    });
}