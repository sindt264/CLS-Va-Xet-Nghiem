﻿(function ($) {
    "use strict";

    // Collapse Navbar
    var navbarCollapse = function () {
        if ($(window).scrollTop() > 90) {
            $("#menu-KQ-top").addClass("fixed-top-menu-kq");
            $('#container_HinhAnhIn').addClass("fixed-position");
        } else {
            $("#menu-KQ-top").removeClass("fixed-top-menu-kq");
            $('#container_HinhAnhIn').removeClass("fixed-position");
        }
    };
    // Collapse now if page is not at top
    navbarCollapse();
    // Collapse the navbar when page is scrolled
    $(window).scroll(navbarCollapse);
})(jQuery);
//---------------------------------------------------------------//
//Khai báo biến, hàm toàn cục
var fnLayTinhTrang;
var fnSetMoTa;
var fnGetMoTa;
var fnClearMoTa;
var _arr_vks = [];

//----------------------------------------------------------------//
//Load danh muc
function fnLoadDanhMuc(_loai) {
    $.ajax({
        url: '/DanhMuc/dbLoadDM',
        data: JSON.stringify({ loai: _loai }),
        success: function (rs) {
            var _html = '';
            switch (_loai) {
                case 'VT':
                    $(rs).each(function (i, item) {
                        dmmagotat.push(item.MaVietTat);
                        dmndgotat.push(item.NoiDung);
                    });
                    if ($('#MoTa').length > 0) {
                        $('#MoTa').on('keypress', function (e) {
                            var key = e.charCode || e.keyCode;
                            //console.log('keypress');
                            if (key === 10 || key === 32 || key === 0) {
                                var sel = window.getSelection();
                                var range = sel.getRangeAt(0);
                                var dom = range.startContainer.parentNode;
                                gotat_EditorMoTa(dom, key);
                            }
                        });
                    }
                    $('#container_KetLuan, #container_DeNghi, #container_MoTa input[type=text]').each(function (i, item) {
                        $(this).on('keypress', function (e) {
                            gotat_input_area(this, e);
                        });
                    });

                    break;
                case 'VKS':
                    $(rs).each(function (i, item) {
                        _arr_vks.push({ MoTa: item.MoTa, KetLuan: item.KetLuan });
                        _html += "<option value='" + i + "'>" + item.TenVungKhaoSat + "</option>";
                    });
                    $('#slVungKhaoSat').html(_html);
                    $('#slVungKhaoSat').change(function () {
                        var index = $(this).val();
                        fnSetMoTa(_arr_vks[index].MoTa);
                        $('#container_KetLuan').val(_arr_vks[index].KetLuan);
                    });
                    $('#slVungKhaoSat option:eq(0)').attr('selected', 'selected').trigger('change');
                    break;
                default:
                    $(rs).each(function (i, item) {
                        _html += '<label for="ck_' + _loai + item.id + '"><input type="checkbox" id="ck_' + _loai + item.id + '" />' + item.Ten + '</label>';
                    });
                    $('#tab' + _loai).html(_html);
                    break;
            }
        }
    });
}
function loadVTYT() {
    $.ajax({
        url: '/DanhMuc/dbLoadVTYT',
        success: function (rs) {
            console.log(rs);
            if ($.fn.DataTable.isDataTable('#tbVTVT')) {
                $('#tbVTVT').DataTable().destroy();
            }
            var html = "";
            $(rs).each(function (i, item) {
                i = i + 1;
                html += "<tr>" +
                    "<td>" + i + "</td>" +
                    "<td class='hide'>" + item.id + "</td>" +
                    "<td>" + item.Ten + "</td>" +
                    "<td>" + item.TenDM + "</td>" +
                    "<td><input type='text' id='txtch" + item.id + "' style='text-align: right;width:80px' autoComplete='off' maxlength='10' onkeypress='isNumberInput(event)' onpaste='return false' onCopy='return false' onCut='return false' onDrag='return false' onDrop='return false' value='" + item.Sluong + "' /></td>" +
                    "<td  style='text-align: center'>" + item.DonVi + "</td>" +
                    "<td style='text-align: center'><input type='checkbox' id='ch" + item.id + "' style='margin-top:45%' /></td>" +
                    "</tr>";
            });
            $('#tbVTVT tbody').html(html);
            $('#tbVTVT').DataTable({
                "bPaginate": false,
                orderCellsTop: true,
                scrollCollapse: true,
                paging: false,
                "order": [0, 'asc']
            });
        }
    });
}
function isNumberInput(evt) {
    var ch = String.fromCharCode(evt.which);
    if (!(/[0-9]/.test(ch) || /[.]/.test(ch))) {
        evt.preventDefault();
    };
};

//hàm cấu hình mặc định sử dụng tinyMCE editor cho mô tả, gọi hàm này nếu trang trả kết quả dùng đến
function fnSetDefaultMoTa() {
    tinymce.init({
        selector: '#MoTa',
        inline: true,
        plugins: "advlist lists charmap print preview textcolor",
        menubar: false
    });

    fnSetMoTa = function (data) {
        tinyMCE.editors["MoTa"].setContent(data);
    };
    fnGetMoTa = function () {
        return tinyMCE.editors["MoTa"].getContent({ format: 'raw' }).replace(/ contenteditable=\"true\"/g, "");
    };
    fnClearMoTa = function () {
        fnSetMoTa("");
    };
}
//--------------Hình Ảnh-------------------------//

function fnIMGCheck(obj) {
    if ($(obj).attr('in') === 'kq') {// checkbox in KQ
        var _src = $('img[title="' + $(obj).attr('tenfile') + '"]').attr('src');
        if ($(obj).is(':checked')) {
            if ($('img[name="imgPrint"][src="/CanLamSang/Public/img/noimg.png"]').length > 0) {
                $('img[name="imgPrint"][src="/CanLamSang/Public/img/noimg.png"]')[0].src = _src;
            }
            else {
                fnShowPopupMessage({ status: 'error', message: 'Chỉ có thể chọn tối đa 4 hình để in vào kết quả bệnh nhân!' });
                obj.checked = false;
            }
        }
        else {
            if ($('img[src="' + _src + '"][name="imgPrint"]').length > 0)
                $('img[src="' + _src + '"][name="imgPrint"]')[0].src = "/CanLamSang/Public/img/noimg.png";
        }
    }
    else {//checkbox in BH
        if ($(obj).is(':checked')) {
            if ($('input[type=checkbox][in="bh"]:checked').length > 2) {
                fnShowPopupMessage({ status: 'error', message: 'Chỉ chọn 2 hình để in BH 1 lần!' });
                obj.checked = false;
            }
        }
    }
}

function fnDeleteIMG(obj) {
    var id = $(obj).attr('tenfile');

    fnShowConfirm('Bạn có chắc muốn xóa hình: ' + id, function () {
        var _img_curr = $('img[title="' + id + '"]')[0];
        var _img_in = $('img[name="imgPrint"][src="' + _img_curr.src + '"]')[0];
        if (_img_in !== undefined)
            _img_in.src = "/CanLamSang/Public/img/noimg.png";
        $('input[in="delete"][tenfile="' + id + '"]')[0].checked = true;
        $(_img_curr).parent('.thumbnail').parent('.cell').addClass('hide');
    });
}

function fnGetXMLHinhAnh() {
    var xml = '';
    $('#divDanhSachHinh > .cell').each(function () {
        var _id = $(this).find('img').attr('title');
        xml += '<row><TenFile>' + _id + '</TenFile>';
        $(this).find('input[type=checkbox]').each(function (i, ck) {
            switch ($(ck).attr('in')) {
                case 'kq':
                    if ($(ck).is(':checked')) {
                        xml += '<isPrint>1</isPrint>';
                        var src = $('img[title="' + _id + '"]')[0].src;
                        var index = $($('img[name="imgPrint"][src="' + src + '"]')[0]).attr('index');
                        xml += '<PrintOrder>' + (typeof index === 'undefined' ? 0 : index) + '</PrintOrder>';
                    }
                    else {
                        xml += '<isPrint>0</isPrint>';
                        xml += '<PrintOrder>0</PrintOrder>';
                    }
                    break;
                case 'delete':
                    if ($(ck).is(':checked'))
                        xml += '<isDelete>1</isDelete>';
                    else
                        xml += '<isDelete>0</isDelete>';
                    break;
            }
        });
        $(this).find('textarea').each(function (i, ck) {
            var GhiChu = "";
            if ($(this).text() == "") {
                GhiChu = "Không";
            } else {
                GhiChu = $(this).text();
            }
            xml += '<GhiChu>' + GhiChu + '</GhiChu></row>';
        });

    });
    return xml;
}

function fnLoadIMG() {
    if ($('#MaBN').val()) {
        var _list_name_img_curr = '';
        $('#divDanhSachHinh img').each(function () {
            _list_name_img_curr += $(this).attr('title') + ';';
        });
        var _data = {
            listIMG_curr: _list_name_img_curr
        };
        $.ajax({
            url: '/KetQua/LayDanhSachHinhAnh',
            data: JSON.stringify(_data),
            success: function (rs) {
                var _html = '';
                //<label for="ck_INBH_img_' + item.TenFile + '"><i class="far fa-square"></i>In BH</label><input type=checkbox inbh=1 onclick=fnIMGCheck(this) tenfile="' + item.TenFile + '" id=ck_INBH_img_' + item.TenFile + ' />
                $(rs).each(function (i, item) {
                    i = i + 0;
                    var _ck_inKQ = '<label class="container-checkbox">In KQ' +
                        '<input tenfile="' + item.TenFile + '" in="kq" ' + (item.isPrint === true ? 'checked' : '') + ' onchange="fnIMGCheck(this)" id="ck_INKQ_' + item.TenFile + '" type="checkbox">' +
                        '<span class="checkmark"></span>' +
                        '</label>';
                    var _ck_inBH = '<label class="container-checkbox">In BH' +
                        '<input tenfile="' + item.TenFile + '" in="bh" onchange="fnIMGCheck(this)" id="ck_INBH_' + item.TenFile + '" type="checkbox">' +
                        '<span class="checkmark"></span>' +
                        '</label >';
                    if ($('#container_HinhAnhIn').length === 0) {
                        _ck_inKQ = "";
                        _ck_inBH = "";
                    }
                    _html += '<div tenfile="' + item.TenFile + '" class="cell large-4">' +
                        '<div class="thumbnail">' +
                        '<div class="grid-x" style="padding:2px 0 4px 0">' +
                        '<div class="cell large-3">' +
                        _ck_inKQ +
                        '</div>' +
                        '<div class="cell large-3">' +
                        _ck_inBH +
                        '</div>' +
                        '<div class="cell large-6"><i tenfile="' + item.TenFile + '" onclick="fnDeleteIMG(this)" class="far fa-trash-alt" style="font-size: 12pt;padding-top: 7px;float: right; color: rgba(59, 91, 152, 0.9); cursor: pointer"></i>' +
                        '<input type="checkbox" hidden tenfile="' + item.TenFile + '" in="delete" />' +
                        '</div>' +
                        '</div>' +
                        '<img title="' + item.TenFile + '" src="' + item.OnlinePath + '" onclick="fnClickHinh(\'' + item.OnlinePath + '\',\'' + 'lbGhiChu' + i + '\')"/> ' +
                        '<div></div>' +
                        '<div>' +
                        '<p><textarea id="lbGhiChu' + i + '"  rows="2" maxlength="200" disabled="disabled" style="resize:none">' + item.GhiChu + '</textarea></p>' +
                        '</div>' +
                        '</div>' +
                        '</div>';

                    if (item.isPrint == 1 || item.isPrint == true) {
                        $('img[index=' + item.PrintOrder + ']')[0].src = item.OnlinePath;
                    }
                });
                $('#divDanhSachHinh').append(_html);
            }
        });
    }
}

function fnClickHinh(Link, TenFile) {
    var GhiChu = "";
    $('#divDanhSachHinh div p textarea#' + TenFile).each(function () {
        GhiChu = $(this).text();
    });
    $('#idShowThongTinBN').foundation('open');
    document.getElementById('ifrShowThongTin').src = '/CanLamSang/HoSoHinhAnh/ShowHinhAnhvaEditGhiChu?Link=' + Link + '&GhiChu=' + GhiChu + '&Ten=' + TenFile;
}
function fnAddGhiChu(Ten, GhiChu) {
    $('#divDanhSachHinh > .cell').each(function () {
        $(this).find('textarea#' + Ten).text(GhiChu);
    });
    $('#idShowThongTinBN').foundation('close');
}
//--------------Chup hinh -----------------------//
function fnShowChupHinh() {
    newwindow = window.open('../KetQua/ChupHinhWebRTC', 'Chụp hình', 'height=700,width=1200');
    if (window.focus) { newwindow.focus(); }
    return false;
}


//--------------upload file ---------------------//
function fnShowUploadFile() {
    if ($('#MaBN').val()) {
        $('#fileUploader').val('');
        _arrUploadFile = [];
        $('#divFiles').empty();
        $('#modalUpLoadFile').foundation('open');
        $('#btnUpload').prop('disabled', false);
        $('#btnUpload i').remove();
        $('#upload_form').height($('#upload_form').parent('.cell').height());

    }
    else {
        fnShowPopupMessage({ status: 'error', message: 'Vui lòng chọn bệnh nhân!' });
    }
}
var _arrUploadFile = [];
function fnSetEventInputUpload() {
    $('input[type=file]').change(function () {
        $('#btnUpload').show();
        for (var i = 0; i < this.files.length; i++) { //Progress bar and status label's for each file genarate dynamically
            _arrUploadFile.push(this.files[i]);
            $("#divFiles").append('<div class="cell large-3">' +
                '<div class= "card">' +
                '<div class="card-divider">' +
                '<h7>' + this.files[i].name + '</h7>' +
                '<a onclick="fnDeleteFileUpload(this)"><i class="far fa-trash-alt" style="color:white"></i></a>' +
                '</div>' +
                '<div class="card-section">' +
                '<img src="' + URL.createObjectURL(this.files[i]) + '" id="img_upl_' + i + '" class="thumbnail" />' +
                '<div class="progress" role="progressbar" tabindex="0" aria-valuenow="0" aria-valuemin="0" aria-valuetext="0 percent" aria-valuemax="100">' +
                '<span id="span_progress_' + i + '" class="progress-meter" style="width: 0%">' +
                '<label id="label_progress_' + i + '" class="progress-meter-text">0%</label>' +
                '</span>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>');
        }
        $('#fileUploader').val('');
    });
    $('#count_number_upload').change(function () {
        var curr = parseInt($(this).val());
        if (curr === 0) {
            $('#modalUpLoadFile').foundation('close');
            fnLoadIMG();
        }
    });
}
function fnDeleteFileUpload(obj) {
    try {
        var filename = $(obj).closest('h7').text().trim();
        var index = function () {
            _arrUploadFile.forEach(function (file, i) {
                if (file.name.matches(filename))
                    return i;
            });
        };
        _arrUploadFile.splice(index, 1);
        $(obj).parent('.card-divider').parent('.card').parent('.cell.large-3').remove();
    }
    catch (err) {
        fnShowPopupMessage({ status: 'error', message: err.message });
        console.log(err);
    }
}
function uploadFiles() {
    if (_arrUploadFile.length === 0) {
        fnShowPopupMessage({ status: "error", message: "Không có hình ảnh để upload!" });
        return;
    }
    $('#btnUpload').prop('disabled', true);
    $('#btnUpload').prepend('<i class="fa fa-circle-notch fa-spin"></i>');
    $('#count_number_upload').val(_arrUploadFile.length);
    $(_arrUploadFile).each(function (i, file) {
        uploadSingleFile(file, i);
    });
    _arrUploadFile = [];
}
function uploadSingleFile(file, i) {
    var fileId = i;
    var ajax = new XMLHttpRequest();

    //Progress Listener
    ajax.upload.addEventListener("progress", function (e) {
        var percent = (e.loaded / e.total) * 100;
        $("#label_progress_" + fileId).text(Math.round(percent) + "%");
        $('#span_progress_' + fileId).css("width", percent + "%");
    }, false);

    //Load Listener
    ajax.addEventListener("load", function (e) {
        var rs = JSON.parse(e.target.responseText);
        var html_message = "";
        if (rs.status === 'done') {
            html_message = '<span class="label success">' + rs.message + '</span>';
            setTimeout(function () {
                $('#count_number_upload').val(parseInt($('#count_number_upload').val()) - 1).trigger('change');
            }, 500);
        }
        else
            html_message = '<span class="label alert">' + rs.message + '</span>';

        $("#label_progress_" + fileId).text('100%');
        $('#span_progress_' + fileId).css("width", "100%");
        $("#span_progress_" + fileId).parent('.progress').parent('.card-section').append(html_message);

    }, false);

    //Error Listener
    ajax.addEventListener("error", function (e) {
        $("#label_progress_" + fileId).text(e.target.responseText);
    }, false);

    //Abort Listener
    ajax.addEventListener("abort", function (e) {
        $("#status_" + fileId).text("Upload Aborted");
    }, false);

    ajax.open("POST", "/CanLamSang/KetQua/UploadIMG"); // Your API .net, php

    var uploaderForm = new FormData(); // Create new FormData
    uploaderForm.append("file", file); // append the next file for upload
    ajax.send(uploaderForm);
}



//Hieu
//---------------------------------Danh sách Chờ--------------------------------------------//
function MacDichDanhSach() {
    fnEventKeyCode();
    //ds cho
    $('#txtTuNgay').datetimepicker({ format: 'd/m/Y', timepicker: false, lang: 'vi', closeOnDateSelect: true });
    $('#txtDenNgay').datetimepicker({ format: 'd/m/Y', timepicker: false, lang: 'vi', closeOnDateSelect: true });
    $('#macdinh').prop("checked", "checked");
    //ds kq
    $('#txtTuNgayKQ').datetimepicker({ format: 'd/m/Y', timepicker: false, lang: 'vi', closeOnDateSelect: true });
    $('#txtDenNgayKQ').datetimepicker({ format: 'd/m/Y', timepicker: false, lang: 'vi', closeOnDateSelect: true });
    $('#macdinhKQ').prop("checked", "checked");
}
function fnShowLoadDSCho() {
    $('#divTongDSChoBN').foundation('open');
    fnLoadTim();
}
function fnLoadTim() {
    var _data = {
        TuNgay: $('#txtTuNgay').val(),
        DenNgay: $('#txtDenNgay').val(),
        MacDinh: $('#macdinh').is(':checked'),
        DaSuDung: $('#sudung').is(':checked'),
        Huy: $('#huy').is(':checked'),
        UuTien: $('#uutien').is(':checked'),
        CapCuu: $('#capcuu').is(':checked')
    };
    GetDscho(_data);

}
function GetDscho(_data) {
    $.ajax({
        url: "/PartialView/dbGetDScho",
        data: JSON.stringify(_data),
        success: function (rs) {
            if ($.fn.DataTable.isDataTable('#tbDSBN')) {
                $('#tbDSBN').DataTable().destroy();
            }

            var html = "";
            $.each(rs, function (i, item) {
                var htmlTT = "";
                var htmlBH = "";
                switch (item.Huy) {
                    case false:
                        switch (item.CapCuu) {
                            case false:
                                if (item.UuTien)
                                    htmlTT = "<span class='label primary'>Ưu tiên</span>";
                                break;
                            case true:
                                htmlTT = "<span class='label alert'>Cấp cứu</span>";
                                break;
                        }
                        break;
                    case true:
                        htmlTT = "<span class='label alert'>Hủy</span>";
                        break;
                };
                if (item.SuDung == 1 && item.Huy == 0) {
                    htmlTT = "<span class='label secondary'>Đã sử dụng</span>";
                }
                if (item.BH === '1') {
                    htmlBH = "<i class='fas fa-check-circle' style='color:rgba(59, 91, 152, 0.9)'></i>";
                } else {
                    htmlBH = "";
                }
                html += "<tr >" +
                    "<td>" + htmlTT + "</td>" +
                    "<td style='text-align: center'>" + item.MaBN + "</td>" +
                    "<td >" + item.Hoten + "</td>" +
                    "<td>" + item.GioiTinh + "</td>" +
                    "<td style='text-align: center'>" + item.MaChiDinh + "</td>" +
                    "<td>" + item.ThoiGianChiDinh + "</td>" +
                    "<td>" + item.TenDichVu + "</td>" +
                    "<td>" + item.NoiChiDinh + "</td>" +
                    "<td style='text-align: center'>" + htmlBH + "</td>" +
                    "<td class='td_hidden'>" + item.MaVP + "</td>" +
                    "<td class='td_hidden'>" + item.MaVPChiTiet + "</td>" +
                    "<td class='td_hidden'>" + item.TenBSCD + "</td>" +
                    "<td class='td_hidden'>" + item.MaDV + "</td>" +
                    "<td class='td_hidden'>" + item.MaChiDinh + "</td>" +
                    "<td class='td_hidden'>" + item.BH + "</td>" +
                    "<td class='td_hidden'>" + item.MaBA + "</td>" +
                    "<td class='td_hidden'>" + item.Madotkham + "</td>" +
                    "<td class='td_hidden'>" + item.IDcoso + "</td>" +
                    "<td class='td_hidden'>" + item.TenDT + "</td>" +
                    "<td class='td_hidden'>" + item.ThoiGianChiDinh + "</td>" +
                    "</tr > ";
            });
            $('#tbDSBN tbody').html(html);
            fnSetEventGrid();
            $('#tbDSBN').DataTable({
                "bPaginate": false,
                orderCellsTop: true,
                "scrollY": ($('#divTongDSChoBN .grid-y').height() - 130) + "px",
                scrollCollapse: true,
                paging: false,
                "order": [0, 'asc']
            });
        }
    });
}
// Sự kiện click table
function fnSetEventGrid() {
    $('#tbDSBN tbody tr td').click(function () {
        if ($('#huy').is(':checked') === true) {
            fnShowPopupMessage({ status: 'error', message: 'Dịch vụ này đã hủy!' });
            return;
        }
        if ($('#sudung').is(':checked') === true) {
            fnShowPopupMessage({ status: 'error', message: 'Dịch vụ này đã sử dụng!' });
            return;
        }
        fnlammoi();
        //truyền vào input hidden
        $('#BacSiChiDinh').val($(this).parent('tr').find('td:eq(11)').text());
        $('#NoiChiDinh').val($(this).parent('tr').find('td:eq(7)').text());
        $('#TenDV').val($(this).parent('tr').find('td:eq(6)').text());
        $('#MaDV').val($(this).parent('tr').find('td:eq(12)').text());
        $('#MaChiDinh').val($(this).parent('tr').find('td:eq(13)').text());
        $('#NgayChiDinh').val($(this).parent('tr').find('td:eq(19)').text());
        if ($(this).parent('tr').find('td:eq(14)').text() === '1') {
            $('#DoiTuong').val('Bảo Hiểm');
        } else {
            $('#DoiTuong').val('Thu Phí');
        }
        $('#MaBA').val($(this).parent('tr').find('td:eq(15)').text());
        $('#MaDotKham').val($(this).parent('tr').find('td:eq(16)').text());
        $('#idcoso').val($(this).parent('tr').find('td:eq(17)').text());
        //Lấy thông tin bn còn lại
        fngetthongtinbenh($(this).parent('tr').find('td:eq(1)').text(),
            $(this).parent('tr').find('td:eq(4)').text(),
            //MaVP
            $(this).parent('tr').find('td:eq(9)').text(),
            //MaVPCT
            $(this).parent('tr').find('td:eq(10)').text(), ''//MaPhieu rỗng
        );

    });
}
function mocuasohoso() {
    var rootlink = "http://" + document.location.hostname.toString() + ":" + document.location.port + "/toathuoc/tracuuhoso.aspx?mabn=" + $('#MaBN').val() + "&maba=" + $('#MaBA').val() + "";
    window.open(rootlink);
}

//---------------------------------Lưu kết quả--------------------------------------------//
// Function Lấy thông tin bệnh nhân và kiểm tra lấy ở danh sách chờ hay danh sách kết quả
function fngetthongtinbenh(maBN, maCD, maVP, maVP_ChiTiet, MaPhieu) {
    $("#MaVP").val(maVP);
    $("#MaVP_ChiTiet").val(maVP_ChiTiet);
    var _data = {
        maBN: maBN,
        maCD: maCD,
        maVP: maVP,
        maVP_ChiTiet: maVP_ChiTiet,
        MaPhieu: MaPhieu,
        LinkOnline: "http://" + document.location.hostname.toString() + ":" + document.location.port + "/YKHOA_IMAGES/"
    };
    if (MaPhieu === '') {
        fnGetThongTinBNCho(_data);
    } else {
        fnGetThongTinKQ(_data);
    }
}
//Function get thông tin bệnh nhân chờ lên trang
function fnGetThongTinBNCho(_data) {
    $.ajax({
        url: "/KetQua/dbGetThongTinBenhNhan",
        data: JSON.stringify(_data),
        success: function (rs) {
            try {
                $('#divTongDSChoBN').foundation('close');
                var arr_id = Object.keys(rs[0]);
                $(arr_id).each(function (i, item) {
                    $('#' + item).val(rs[0][item]);
                });
                trrigerChange();
                if ($('#divDanhSachHinh').length !== undefined) {
                    fnLoadIMG();
                };
            } catch (err) {
                fnShowPopupMessage({ status: 'error', message: err });
            }
        }
    });
}
//Function lưu kết quả bệnh nhân 
function fnLuuKQ(loailuu) {
    if ($("#MaBN").val() === "") {
        fnShowPopupMessage({ status: 'error', message: 'Vui lòng nhập chọn bệnh nhân!' });
        return;
    }
    if (typeof fnGetMoTa !== "undefined") {
        if (fnGetMoTa() === "") {
            if (editorMoTa.getData().trim() === "<p>&nbsp;</p>") {
                fnShowPopupMessage({ status: 'error', message: 'Vui lòng nhập mô tả!' });
                return;
            }
        }
    }
    if (typeof $('#container_KetLuan').val() !== "undefined") {
        if ($('#container_KetLuan').val() === "") {
            fnShowPopupMessage({ status: 'error', message: 'Vui lòng nhập kết luận!' });
            return;
        }
    }
    //Get Thong tin Hành chánh thành xml
    var xml = "";
    var x2js = new X2JS();
    $('#container_ThongTinHanhChanh input[name]').each(function () {
        var obj = {
            row: {
                key: $(this).attr('name'),
                value: ""
            }
        };
        switch ($(this).attr('type')) {
            case "checkbox":
                obj.row.value = $(this).is(":checked") === true ? 1 : 0;
                break;
            default:
                obj.row.value = $(this).val().trim();
                break;
        }
        xml += x2js.json2xml_str(obj);
    });
    $('#container_ThongTinHanhChanh textarea').each(function () {
        var obj = {
            row: {
                key: $(this).attr('name'),
                value: $(this).val().trim()
            }
        };
        xml += x2js.json2xml_str(obj);
    });
    //--------------------------------------------------------------//
    var _data = {
        xml: xml.replace(/&/g, "&amp;"),
        MaBN: $('#MaBN').val().trim(),
        MaPhieu: $('#MaPhieu').val(),
        MaVPCT: $('#MaVP_ChiTiet').val(),
        MaVP: $('#MaVP').val(),
        xmlTT: fnGetXML_Checkbox_Obj('tabTT'),
        xmlTB: fnGetXML_Checkbox_Obj('tabTB'),
        xmlHinh: fnGetXMLHinhAnh(),
        xmlVTYT: fngetXML_CheckBox_VTYT(),
        VungKhaoSat: checkVKS(),
        Mota: typeof fnGetMoTa === 'undefined' ? '' : fnGetMoTa(),
        KetLuan: checkKetLuanDeNghi('#container_KetLuan'),
        DeNghi: checkKetLuanDeNghi('#container_DeNghi'),
        TinhTrang: fnLayTinhTrang(),
        MaKetNoi: $('#MaKetNoi').val()
    };
    $.ajax({
        url: "/KetQua/dbLuuKQ",
        data: JSON.stringify(_data),
        success: function (rs) {
            if (rs[0].status === 'done') {
                fnlammoi();
                fnShowPopupMessage(rs);
                trrigerChange();
                if (loailuu === 'in') {
                    inphieu(rs[0].MaPhieu.trim());
                   
                }
                fnShowLoadDSCho();
                XoaCacheImage(rs[0].MaVP, rs[0].MaVPCT);
            } else {
                fnShowPopupMessage(rs);
            }
        }
    });
}
function XoaCacheImage(MaVP, MaVPCT) {
    localStorage.removeItem(MaVP.trim() + MaVPCT.trim());
}
function trrigerChange() {
    $('#slVungKhaoSat option:eq(0)').attr('selected', 'selected').trigger('change');
}

function checkKetLuanDeNghi(tenInput) {
    if (typeof $(tenInput).val() === "undefined") {
        return '';
    } else {
        return $(tenInput).val();
    };
}

function checkVKS() {
    if (typeof $('#slVungKhaoSat option:selected').text() === "undefined") {
        return '';
    } else {
        return $('#slVungKhaoSat option:selected').text().trim();
    }
}
//----------------------------------------------------------------------------------//
//-------------------------------------Lấy Vtyt lưu---------------------------------//
function fngetXML_CheckBox_VTYT() {
    var xml = '';
    $('#tbVTVT tbody tr input[type="checkbox"]:checked').each(function () {
        xml += "<row>" +
            "<key>" + $(this).attr("id") + "</key>" +
            "<ten>" + $(this).closest('tr').find('td:eq(2)').text() + "</ten>" +
            "<sl>" + $(this).closest('tr').find('input#txt' + $(this).attr("id") + '').val() + "</sl>" +
            "<dv>" + $(this).closest('tr').find('td:eq(5)').text() + "</dv>" +
            "</row>";
    });
    if (xml != '')
        return '<root>' + xml + '</root>';
    else
        return '';
}
//------------------------------------------------------------------------//
function fnGetXML_Checkbox_Obj(id) {
    var xml = '';
    $('#' + id + ' input[type="checkbox"]:checked').each(function () {
        xml += "<row>" +
            "<key>" + $(this).attr("id") + "</key>" +
            "<value>" + $('label[for="' + $(this).attr("id") + '"]').text() + "</value>" +
            "</row>";
    });
    if (xml != '')
        return '<root>' + xml + '</root>';
    else
        return '';
}
//Function làm mới trang
function fnlammoi() {
    $('#count_number_upload').val('');
    $('#tbThongTinHanhChanh input[name]').each(function () {
        if ($(this).attr('type') === 'checkbox') {
            this.checked = false;
        } else {
            if ($(this).attr('clear') !== '0')
                $(this).val('');
        }
    });
    if (typeof $('#NguoiLayMau').val() !== "undefined") {
        $('#NguoiLayMau').val("");
        $('#MaNguoiLayMau').val("");
        $('#NgayChupHinh').val("");
        $('#TinhTrangMau').val("");
        $('#TenKTVChupHinh').val("");
        $('#NgayLayMauGPB').val("");
        $('#NgayTiepNhan_GPB').val("");
        $('#MaKTVChupHinh').val("");
        fnMauAuto();
        fnChatBaoQuan();
    }
    $('#container_ThongTinHanhChanh textarea').each(function () {
        $(this).val('');
    });
    $('#tabTT input[type="checkbox"]').each(function () {
        this.checked = false;
    });
    $('#tabTB input[type="checkbox"]').each(function () {
        this.checked = false;
    });
    if (typeof fnClearMoTa !== "undefined")
        fnClearMoTa();

    if (typeof $('#container_KetLuan').val() !== "undefined") {
        $('#container_KetLuan').val("");
    }
    if (typeof $('#container_DeNghi').val() !== "undefined") {
        $('#container_DeNghi').val("");
    }
    $('#MaPhieu').val("Auto");

    $('#NgayKQ').val($('#ngay').val());
    fnLamMoiHinhAnh();
    loadVTYT();
}
//Làm mới hình ảnh
function fnLamMoiHinhAnh() {
    $('#divDanhSachHinh').empty();
    $('img[name="imgPrint"]').each(function () {
        this.src = '/CanLamSang/Public/img/noimg.png';
    });
}
//---------------------------------DS kết quả--------------------------------------------//
//Loại DS có 2 trường hợp KQ và Cho
//KQ show danh sách kết quả
//Cho show danh sách kết quả chụp hình chờ chẩn đoán dành cho CDHA bên đọc ghi kết quả
function fnShowLoadDSKQ() {
    $('#divTongDSKQ').foundation('open');
    if ($('#LoaiDS').val() === 'KQ') {
        $('#titleDSKQ').text('DANH SÁCH KẾT QUẢ BỆNH NHÂN');
        $('#spTenLoaiPhieu').text('Phiếu kết quả bệnh nhân');
        $('#spTenPhieuSua').text('Phiếu kết quả đã sửa');
    } else {
        $('#titleDSKQ').text('DANH SÁCH CHỜ CHẨN ĐOÁN HÌNH ẢNH');
        $('#spTenLoaiPhieu').text('Bệnh nhân chờ đọc ghi kết quả');
        $('#spTenPhieuSua').text('Phiếu KTV đã sửa');
    }
    GetDSKQ();
}

//Hàm lấy thông tin BN dưới DATABASE
function GetDSKQ() {
    var _data = {
        TuNgay: $('#txtTuNgayKQ').val(),
        DenNgay: $('#txtDenNgayKQ').val(),
        MacDinh: $('#macdinhKQ').is(':checked'),
        Khoa: $('#KhoaKQ').is(':checked'),
        Huy: $('#HuyKQ').is(':checked'),
        Sua: $('#SuaKQ').is(':checked'),
        CheckTT: $('#checkTT').val(),
        loaiDS: $('#LoaiDS').val()
    };
    $.ajax({
        url: "/PartialView/dbGetDanhSachKQ",
        data: JSON.stringify(_data),
        success: function (rs) {
            if ($.fn.DataTable.isDataTable('#tbDSKQ')) {
                $('#tbDSKQ').DataTable().destroy();
            }

            var html = "";
            $.each(rs, function (i, item) {
                var htmlTT = "";
                var htmlBH = "";
                if (item.Block != true) {
                    switch (item.TinhTrang) {
                        case 0:
                            htmlTT = "<span class='label alert'>" + item.TenTinhTrang + "</span>";
                            break;
                        case 2:
                            break;
                        case 4:
                            htmlTT = "<span class='label primary'>" + item.TenTinhTrang + "</span>";
                            break;
                        case 5:
                            htmlTT = "<span class='label primary'>" + item.TenTinhTrang + "</span>";
                            break;
                    };
                } else {
                    htmlTT = "<span class='label secondary'>Khóa</span>";
                }
                if (item.BH == '1') {
                    htmlBH = "<i class='fas fa-check-circle' style='color:rgba(59, 91, 152, 0.9)'></i>";
                } else {
                    htmlBH = "";
                }
                html += "<tr tinhtrang='" + item.TinhTrang + "'>" +
                    "<td>" + htmlTT + "</td>" +
                    "<td>" + item.MaPhieu + "</td>" +
                    "<td>" + item.MaChiDinh + "</td>" +
                    "<td>" + item.Ngay + "</td>" +
                    "<td>" + item.MaBN + "</td>" +
                    "<td>" + item.HoTen + "</td>" +
                    "<td>" + item.GioiTinh + "</td>" +
                    "<td>" + item.TenDV + "</td>" +
                    "<td>" + item.LyDo + "</td>" +
                    "<td class='td_hidden'>" + item.MaVP + "</td>" +
                    "<td class='td_hidden'>" + item.MaVP_ChiTiet + "</td>" +
                    "<td style='text-align:center' >" + htmlBH + "</td>" +
                    "<td style='text-align: center' id='tdinphieu'><i class='fas fa-print' style='color: #365899; font-size: 16pt' onclick='checkinphieu(\"" + item.MaPhieu + "\")'></i></td > " +
                    "<td style='text-align: center' id='huyphieu'><i class='fas fa-backspace' style='color: #ff6434; font-size: 16pt' onclick='xoaphieuKQ(\"" + item.MaPhieu + "\",\"" + item.MaVP + "\",\"" + item.MaVP_ChiTiet + "\",\"" + item.MaChiDinh + "\")'></i></td > " +
                    "</tr > ";
            });
            $('#tbDSKQ tbody').html(html);
            fnSetEventGridDSKQ();
            anInPhieuKiThuatVien($('#LoaiDS').val());
            $('#tbDSKQ').DataTable({
                "bPaginate": false,
                orderCellsTop: true,
                "scrollY": ($('#divTongDSChoBN .grid-y').height() - 130) + "px",
                scrollCollapse: true,
                paging: false,
                "order": [0, 'asc']
            });
        }
    });
}
// Function ẩn nút in và xóa 
function anInPhieuKiThuatVien(loaiDS) {
    if (($('#checkTT').val() === '1' && loaiDS === "KQ") || loaiDS === "Cho") {
        $('#tbDSKQ tbody tr td#tdinphieu').each(function () {
            $(this).hide();
        });
        $('#tbDSKQ thead tr th#theadinphieu').each(function () {
            $(this).hide();
        });
    } else {
        $('#tbDSKQ tbody tr td#tdinphieu').each(function () {
            $(this).show();
        });
        $('#tbDSKQ thead tr th#theadinphieu').each(function () {
            $(this).show();
        });
    }
    if (loaiDS === "Cho" && $('#checkTT').val() === '2') {
        $('#tbDSKQ thead tr th#huyphieu').each(function () {
            $(this).hide();
        });
        $('#tbDSKQ tbody tr td#huyphieu').each(function () {
            $(this).hide();
        });
    } else {
        $('#tbDSKQ thead tr th#huyphieu').each(function () {
            $(this).show();
        });
        $('#tbDSKQ tbody tr td#huyphieu').each(function () {
            $(this).show();
        });
    }
}
//Event click Danh Sách Kết quả
function fnSetEventGridDSKQ() {
    $('#tbDSKQ tbody tr').each(function () {
        $(this).find('td:not(:last-child):not(:eq(12))').click(function () {
            if ($('#HuyKQ').is(':checked') === true) {
                fnShowPopupMessage({ status: 'error', message: 'Phiếu kêt quả này đã hủy!' });
                return;
            }
            if ($('#KhoaKQ').is(':checked') === true) {
                fnShowPopupMessage({ status: 'error', message: 'Hồ sơ bệnh nhân đã đóng!' });
                return;
            }
            fnlammoi();
            $('#TinhTrang').val($(this).parent('tr').attr('tinhtrang'));
            fngetthongtinbenh($(this).parent('tr').find('td:eq(4)').text(),
                $(this).parent('tr').find('td:eq(2)').text(),
                $(this).parent('tr').find('td:eq(9)').text(),
                $(this).parent('tr').find('td:eq(10)').text(),
                $(this).parent('tr').find('td:eq(1)').text());
        });
    });
}
/**
 * Check kiểm tra trước khi in phiếu
 * @@param {string} MaPhieu
 */
function checkinphieu(MaPhieu) {
    if ($('#HuyKQ').is(':checked') === true) {
        fnShowPopupMessage({ status: 'error', message: 'Phiếu kêt quả này đã hủy không thể in phiếu!' });
        return;
    };
    inphieu(MaPhieu);
}
/**
 * Function in phiếu
 * @@param {any} MaPhieu
 */
function inphieu(MaPhieu) {
    fnShowLoading("Đang tải phiếu in, vui lòng chờ trong giây lát ...");
    document.getElementById('ifrPhieuIn').src = '/CanLamSang/PhieuIn/PhieuYKhoa?MaPhieu=' + MaPhieu + '&AutoPrint=1';
}
/**
 * Load iframe in phiếu nhưng ẩn 
 * */
function loadInPhieu() {
    var iframe = document.getElementById('ifrPhieuIn').contentWindow;
    iframe.focus();
    fnCloseLoading();
    iframe.print();
}
/**
 * Hủy kết quả đã có
 * @@param {string} MaPhieu ;
 * @@param {string} MaVP ;
 * @@param {string} MaVP_CT ;
 */
function xoaphieuKQ(MaPhieu, MaVP, MaVP_CT, MaChiDinh) {
    if ($('#HuyKQ').is(':checked') === true) {
        fnShowPopupMessage({ status: 'error', message: 'Phiếu kêt quả này đã hủy!' });
        return;
    };
    if ($('#KhoaKQ').is(':checked') === true) {
        fnShowPopupMessage({ status: 'error', message: 'Hồ sơ bệnh nhân đã đóng!' });
        return;
    };
    var lydo = prompt("Vui lòng cung cấp lý do hủy phiếu kết quả " + MaPhieu, "");
    if (lydo != null) {
        var _data = {
            MaPhieu: MaPhieu,
            MaVP: MaVP,
            MaVP_CT: MaVP_CT,
            LyDo: lydo,
            MaChiDinh: MaChiDinh
        };
        $.ajax({
            url: "/PartialView/dbXoaPhieuKQ",
            data: JSON.stringify(_data),
            success: function (rs) {
                fnShowPopupMessage(rs);
                GetDSKQ();
            }
        });
    } else {
        return false;
    }
}

/**
 * Lấy tất cả thông tin kết quả của 1 bệnh nhân lên 
 * @@param {string} _data: 
 */
function fnGetThongTinKQ(_data) {
    $.ajax({
        url: "/KetQua/dbGetThongTinBenhNhan",
        data: JSON.stringify(_data),
        success: function (rs) {
            try {
                $('#divTongDSKQ').foundation('close');
                var arr_id = Object.keys(rs[0]);
                $(arr_id).each(function (i, item) {
                    $('#' + item).val(rs[0][item]);
                });
                $('#TaiGiuong').prop('checked', rs[0].TaiGiuong);
                if (typeof $('#slVungKhaoSat option').val() !== "undefined") {
                    $('#slVungKhaoSat option').each(function () {
                        if ($(this).text() === rs[0].VungKhaoSat) {
                            $(this).attr('selected', 'selected');
                        }
                        else
                            $(this).removeAttr('selected');
                    });
                }
                if (typeof fnSetMoTa !== 'undefined') {
                    fnSetMoTa(rs[0].MoTa === null || rs[0].MoTa === undefined ? "" : rs[0].MoTa);
                }
                if (typeof $('#container_DeNghi').val() !== "undefined") {
                    $('#container_DeNghi').val(rs[0].DeNghi);
                }
                if (typeof $('#container_KetLuan').val() !== "undefined") {
                    $('#container_KetLuan').val(rs[0].KetLuan);
                }
                if (rs[0].MoTa === "" || rs[0].MoTa === null) { trrigerChange(); }
                fnSetCheckedCheckbox(rs[0].ThuThuat);
                fnSetCheckedCheckbox(rs[0].TaiBien);
                fnSetVTYT(rs[0].VTYT);
                if ($('#divDanhSachHinh').length !== undefined)
                    fnLoadIMG();
            }
            catch (err) {
                fnShowPopupMessage({ status: 'error', message: err });
            }
        }
    });
}
function fnSetVTYT(xml) {
    if (xml === '') {
        return;
    }
    var _root = $.parseXML(xml);
    var _row = $(_root).find('row');
    $(_row).each(function (i, item) {
        document.getElementById($(item).find('key').text()).checked = true;
        $('input#txt' + $(item).find('key').text() + '').val($(item).find('sl').text());
    });
}
function fnSetCheckedCheckbox(xml) {
    if (xml === '')
        return;
    var _root = $.parseXML(xml);
    var _row = $(_root).find('row');
    $(_row).each(function (i, item) {
        document.getElementById($(item).find('key').text()).checked = true;
    });
}

function fnSetValueInput(xml) {
    if (xml === '')
        return;
    var _root = $.parseXML(xml);
    var _row = $(_root).find('row');
    $(_row).each(function (i, item) {
        document.getElementById($(item).find('key').text()).value = $(item).find('value').text();
    });
}

function fnEventKeyCode() {
    arrKeyCode = [{ Ten: 'Bấm nút F1', KeyCode: 112 },
    { Ten: 'Bấm nút F2', KeyCode: 113 },
    { Ten: 'Bấm nút F3', KeyCode: 114 },
    { Ten: 'Bấm nút F4', KeyCode: 115 },
    { Ten: 'Bấm nút F5', KeyCode: 116 },
    { Ten: 'Bấm nút F6', KeyCode: 117 },
    { Ten: 'Bấm nút F7', KeyCode: 118 }];

    $('#menu-KQ-top a').each(function (i, item) {
        if ($(this).attr('style') !== "display: none;") {
            $('#' + item['id']).attr('title', '' + arrKeyCode[i].Ten);
            SetKeyCodeForButton(arrKeyCode[i].KeyCode, item['id']);
        }
    });
}

function SetKeyCodeForButton(KeyCode, ID) {
    document.addEventListener("keydown", function (event) {
        if (event.keyCode === KeyCode) {
            event.preventDefault();
            $('#' + ID).click();
        }
    });
}


//Sổ tay gõ tắt - Huân
//Thay đổi code cho phù hợp tinyMCE - Huân 22/09/2018 10:05AM

var dmmagotat = [];
var dmndgotat = [];

function rplWith(s, c) { //Việt viết lại hàm này
    for (i = 0; i < dmmagotat.length; i++)
        if (dmmagotat[i] === s) return dmndgotat[i] + String.fromCharCode(c);
    return s;
}

function ReturnWord(text, caretPos) { //Việt viết lại hàm này
    var preText = text.substring(0, caretPos);
    var tempText = preText.replace(/\n/g, ' ');
    if (tempText.indexOf(" ") > 0) {
        var words = tempText.split(" ");
        return words[words.length - 1]; //return last word
    }
    else {
        return preText;
    }
}

function gotat_EditorMoTa(t, key) { //Việt viết lại hàm này 15/2/17
    t.contentEditable = "true";
    var idx = $(t).caret('pos'); //$(t).caret() + 1;   //Lấy vị trí con trỏ (ký tự thứ idx)

    var giatri = $(t).text().substring(0, idx).replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, ''); //Lấy xâu từ đầu đến vị trí idx

    //var word = giatri.match(/\w+$/)[0]; // Lấy word cuối cùng của xâu (tương đương tại vị trí con trỏ đã xác định ở trên)
    var word = $.trim(ReturnWord(giatri, idx));

    var dau = giatri.substring(0, giatri.lastIndexOf(word)); // Giữ lại đoạn đầu của xâu cho đến word cuối cùng

    var newword = rplWith(word, key); // Thay thế word bằng nội dung gõ tắt. Nếu ko có thì trả lại giá trị cũ của word
    if (newword !== word) {
        $(t).text(dau + newword + $(t).text().substring(idx)); // Ghép lại xâu ban đầu

        $(t).caret('pos', (dau + newword).length); // Đặt lại con trỏ ngay sau word vừa thay thế
    }
    return false;

}

function gotat_input_area(t, e) { //Việt viết lại hàm này 15/2/17
    e = e || window.event;
    var key = e.charCode || e.keyCode;

    if (key === 10 || key === 32 || key === 0) {
        var idx = $(t).caret('pos'); //$(t).caret() + 1;   //Lấy vị trí con trỏ (ký tự thứ idx)
        var giatri = $(t).val().substring(0, idx).replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, ''); //Lấy xâu từ đầu đến vị trí idx

        //var word = giatri.match(/\w+$/)[0]; // Lấy word cuối cùng của xâu (tương đương tại vị trí con trỏ đã xác định ở trên)
        var word = $.trim(ReturnWord(giatri, idx /*GetCaretPosition(t)*/));

        var dau = giatri.substring(0, giatri.lastIndexOf(word)); // Giữ lại đoạn đầu của xâu cho đến word cuối cùng
        //console.log(word);
        var newword = rplWith(word, key); // Thay thế word bằng nội dung gõ tắt. Nếu ko có thì trả lại giá trị cũ của word
        //console.log(newword);
        if (newword !== word) {
            $(t).val(dau + newword + $(t).val().substring(idx)); // Ghép lại xâu ban đầu
            $(t).caret((dau + newword).length); // Đặt lại con trỏ ngay sau word vừa thay thế
        }
        return false;
    }
}
//-----------------------------------------------------------------------------------------------------------------------//
function isNumberInput(evt) {
    var ch = String.fromCharCode(evt.which);
    if (!(/[0-9]/.test(ch)) && !(/[.]/.test(ch))) {
        evt.preventDefault();
    };
};


// -------------------------------------------------GIẢI PHẪU BỆNH------------------------------------------------------------------//

//-------------------------------------------
function xoaphieuKQGPB(MaPhieu, MaVP, MaVP_CT, MaChiDinh) {
    if ($('#HuyKQ').is(':checked') === true) {
        fnShowPopupMessage({ status: 'error', message: 'Phiếu này đã hủy!' });
        return;
    };
    if ($('#KhoaKQ').is(':checked') === true) {
        fnShowPopupMessage({ status: 'error', message: 'Hồ sơ bệnh nhân đã đóng!' });
        return;
    };
    var lydo = prompt("Vui lòng cung cấp lý do hủy phiếu " + MaPhieu, "");
    if (lydo != null) {
        var _data = {
            MaPhieu: MaPhieu,
            MaVP: MaVP,
            MaVP_CT: MaVP_CT,
            LyDo: lydo,
            MaChiDinh: MaChiDinh
        };
        $.ajax({
            url: "/PartialView/dbXoaPhieuKQ",
            data: JSON.stringify(_data),
            success: function (rs) {
                fnShowPopupMessage(rs);
                GetDSDSlayMau();
            }
        });
    } else {
        return false;
    }
}
//-------------------------------------------
function fnMauAuto() {
    $.ajax({
        url: "/GiaiPhauBenh/LoadMauAuto",
        success: function (rs) {
            $('#slMauThu').html('');
            var html = "";
            $(rs).each(function (i, item) {
                html += "<option value='" + item.ID + "'>" + item.Ten + "</option>";
            });
            $('#slMauThu').html(html);
        }
    });
}
//-------------------------------------------
function fnChatBaoQuan() {
    $.ajax({
        url: "/GiaiPhauBenh/LoadChatBaoQuan",

        success: function (rs) {
            $('#slVTYT').html('');
            var html = "";
            $(rs).each(function (i, item) {
                html += "<option value='" + item.id + "'>" + item.Ten + "</option>";
            });
            $('#slVTYT').html(html);
        }
    });
}
//----------------------lẤY mẪU-----------------------//
//----------------------------------------------------------
function checkChatBaoQuan() {
    if (typeof $('#slVTYT option:selected').text() === "undefined") {
        return '';
    } else {
        return $('#slVTYT option:selected').text().trim();
    }
}
//----------------------------------------------------------
function checkMauThu() {
    if (typeof $('#slMauThu option:selected').text() === "undefined") {
        return '';
    } else {
        return $('#slMauThu option:selected').text().trim();
    }
}
//----------------------------------------------------------
function LoaiDS() {
    if ($('#LoaiGPB').val() == "LM") {
        $('#titleDSKQ').text('DANH SÁCH ĐÃ LẤY MẪU');
        $('#thNgayDS').text('Ngày Lấy mẫu');
        $('#spTenLoaiPhieu').text('Phiếu Lấy mẫu');
        $('#spTenPhieuHuy').text('Phiếu Lấy mẫu đã hủy');
        $('#spTenPhieuSua').text('Phiếu kết quả đã sửa');
        $('#spTenPhieuKhoa').text('Phiếu Lấy mẫu đã khóa');
        $('#thNgayDS').text('Ngày Lấy Mẫu');
    } else if ($('#LoaiGPB').val() == "TNM") {
        $('#titleDSKQ').text('DANH SÁCH ĐÃ TIẾP NHÂN MẪU');
        $('#thNgayDS').text('Ngày đã tiếp nhân');
        $('#spTenLoaiPhieu').text('Phiếu đã tiếp nhân');
        $('#spTenPhieuHuy').text('Phiếu đã hủy');
        $('#spTenPhieuSua').text('Phiếu tiếp nhân đã sửa');
        $('#spTenPhieuKhoa').text('Phiếu đã khóa');
        $('#thNgayDS').text('Ngày tiếp nhân');
    } else {
        $('#titleDSKQ').text('DANH SÁCH KẾT QUẢ');
        $('#thNgayDS').text('Ngày kết quả');
        $('#spTenLoaiPhieu').text('Phiếu kết quả');
        $('#spTenPhieuHuy').text('Phiếu đã hủy');
        $('#spTenPhieuSua').text('Phiếu kết quả đã sửa');
        $('#spTenPhieuKhoa').text('Phiếu đã khóa');
        $('#thNgayDS').text('Ngày kết quả');
    }
}
//----------------------------------------------------------
function GetDSDSlayMau() {
    $('#divTongDSKQ').foundation('open');
    LoaiDS();
    switch ($('#LoaiGPB').val()) {
        case 'LM':
            DSLaymau();
            break;
        case 'TNM':
            GetDSkQ_TiepNhan_KetQua('TNM');
            break;
        case 'KQ':
            GetDSkQ_TiepNhan_KetQua('KQ');
            break;
    };
}

//----------------------------------------------------------
function fnSetEventGridDSKQ_LayMau() {
    $('#tbDSKQ tbody tr').each(function () {
        $(this).find('td:not(:last-child):not(:eq(12))').click(function () {
            if ($('#HuyKQ').is(':checked') === true) {
                fnShowPopupMessage({ status: 'error', message: 'Phiếu kêt quả này đã hủy!' });
                return;
            }
            if ($('#KhoaKQ').is(':checked') === true) {
                fnShowPopupMessage({ status: 'error', message: 'Hồ sơ bệnh nhân đã đóng!' });
                return;
            }
            fnlammoi();
            GetThongTin_LayMau($(this).parent('tr').find('td:eq(4)').text(),
                $(this).parent('tr').find('td:eq(2)').text(),
                $(this).parent('tr').find('td:eq(9)').text(),
                $(this).parent('tr').find('td:eq(10)').text(),
                $(this).parent('tr').find('td:eq(1)').text());
        });
    });
}
//---------------------------------------------------------
function fnSetEventGridCho() {
    $('#tbDSCho tbody tr').each(function () {
        $(this).find('td:not(:last-child):not(:eq(12))').click(function () {
            fnlammoi();
            console.log($('#LoaiGPB').val());
            GetThongTin_LayMau($(this).parent('tr').find('td:eq(4)').text(),
                $(this).parent('tr').find('td:eq(2)').text(),
                $(this).parent('tr').find('td:eq(9)').text(),
                $(this).parent('tr').find('td:eq(10)').text(),
                $(this).parent('tr').find('td:eq(1)').text());
        });
    });
}
//----------------------------------------------------------
function GetThongTin_LayMau(maBN, maCD, maVP, maVP_ChiTiet, MaPhieu) {
    $("#MaVP").val(maVP);
    $("#MaVP_ChiTiet").val(maVP_ChiTiet);
    var _data = {
        maBN: maBN,
        maCD: maCD,
        maVP: maVP,
        maVP_ChiTiet: maVP_ChiTiet,
        MaPhieu: MaPhieu,
        LinkOnline: "http://" + document.location.hostname.toString() + ":" + document.location.port + "/YKHOA_IMAGES/"
    };
    $.ajax({
        url: "/KetQua/dbGetThongTinBenhNhan",
        data: JSON.stringify(_data),
        success: function (rs) {
            
            try {
                $('#divTongDSKQ').foundation('close');
                if (typeof $('#divTongDSCho').val() !== "undefined") {
                    $('#divTongDSCho').foundation('close');
                }
                var arr_id = Object.keys(rs[0]);
                $(arr_id).each(function (i, item) {
                    $('#' + item).val(rs[0][item]);
                });
                
                switch ($('#LoaiGPB').val()) {
                    case 'LM':
                        $('#NgayKQua').val(rs[0].NgayLayMauGPB);
                        break;
                    case 'TNM':
                        if (rs[0].TinhTrang == 6 || rs[0].TinhTrang == 8) {
                            $('#NgayKQua').val('');
                            $('#NgayTiepNhan_GPB').val('');
                        } else {
                            $('#NgayKQua').val(rs[0].NgayTiepNhanGPB);
                        }
                        break;
                    case 'KQ':
                            $('#NgayKQua').val(rs[0].NgayKQ);
                        break;
                };
                if (typeof $('#slVungKhaoSat option').val() !== "undefined") {
                    $('#slVungKhaoSat option').each(function () {
                        if ($(this).text() === rs[0].VungKhaoSat) {
                            $(this).attr('selected', 'selected');
                        }
                        else
                            $(this).removeAttr('selected');
                    });
                }
                if (typeof $('#TinhTrangMau').val() !== "undefined") {
                    $('#TinhTrangMau').val(rs[0].TinhTrangMau);
                }
                $('#slVTYT option').each(function () {
                    if ($(this).text() === rs[0].VTYT) {
                        $(this).attr('selected', 'selected');
                    }
                    else
                        $(this).removeAttr('selected');
                });
                $('#slMauThu option').each(function () {
                    if ($(this).text() === rs[0].MauThu) {
                        $(this).attr('selected', 'selected');
                    }
                    else
                        $(this).removeAttr('selected');
                });

                if (typeof fnSetMoTa !== 'undefined') {
                    fnSetMoTa(rs[0].MoTa === null || rs[0].MoTa === undefined ? "" : rs[0].MoTa);
                }
                if (typeof $('#container_DeNghi').val() !== "undefined") {
                    $('#container_DeNghi').val(rs[0].DeNghi);
                }
                if (typeof $('#container_KetLuan').val() !== "undefined") {
                    $('#container_KetLuan').val(rs[0].KetLuan);
                }
                if (rs[0].MoTa === "" || rs[0].MoTa === null) { trrigerChange(); }
                if ($('#divDanhSachHinh').length !== undefined)
                    fnLoadIMG();
            }
            catch (err) {
                fnShowPopupMessage({ status: 'error', message: err });
            }
        }
    });
}
//----------------Tiep Nhan Mau--------------------//

//----------------------------------------------------------
function GetDSCho_TiepNhan_KetQua(Loai) {
    $('#divTongDSCho').foundation('open');
    if (Loai == 'LM') {
        $('#titleDSCho').text('DANH SÁCH CHỜ TIẾP NHÂN');
        $('#thNgayDSCho').text('Ngày Lấy mẫu');
    } else {
        $('#titleDSCho').text('DANH SÁCH CHỜ KẾT QUẢ');
        $('#thNgayDSCho').text('Ngày tiếp nhận');
    }
    var _data = {
        TuNgay: $('#txtTuNgay').val(),
        DenNgay: $('#txtDenNgay').val(),
        LoaiMau: Loai.trim()
    };
    $.ajax({
        url: "/GiaiPhauBenh/dbDSChoKham",
        data: JSON.stringify(_data),
        success: function (rs) {
            if ($.fn.DataTable.isDataTable('#tbDSCho')) {
                $('#tbDSCho').DataTable().destroy();
            }
            var html = "";
            $.each(rs, function (i, item) {
                var htmlBH = "";
                if (item.BH == '1') {
                    htmlBH = "<i class='fas fa-check-circle' style='color:rgba(59, 91, 152, 0.9)'></i>";
                } else {
                    htmlBH = "";
                }
                html += "<tr tinhtrang='" + item.TinhTrang + "'>" +
                    "<td class='td_hidden' style='text-align:center'>" + (i + 1) + "</td>" +
                    "<td style='text-align:center'>" + item.MaPhieu + "</td>" +
                    "<td style='text-align:center'>" + item.MaChiDinh + "</td>" +
                    "<td>" + item.Ngay + "</td>" +
                    "<td style='text-align:center'>" + item.MaBN + "</td>" +
                    "<td>" + item.HoTen + "</td>" +
                    "<td style='text-align:center'>" + item.GioiTinh + "</td>" +
                    "<td>" + item.TenDV + "</td>" +
                    "<td class='td_hidden'>" + item.LyDo + "</td>" +
                    "<td class='td_hidden'>" + item.MaVP + "</td>" +
                    "<td class='td_hidden'>" + item.MaVP_ChiTiet + "</td>" +
                    "<td  style='text-align:center' >" + htmlBH + "</td>" +
                    "<td class='td_hidden' style='text-align: center' id='tdinphieu'><i class='fas fa-print' style='color: #365899; font-size: 16pt' onclick='checkinphieu(\"" + item.MaPhieu + "\")'></i></td > " +
                    "<td class='td_hidden' style='text-align: center' id='huyphieu'><i class='fas fa-backspace' style='color: #ff6434; font-size: 16pt' onclick='xoaphieuKQGPB(\"" + item.MaPhieu + "\",\"" + item.MaVP + "\",\"" + item.MaVP_ChiTiet + "\",\"" + item.MaChiDinh + "\")'></i></td > " +
                    "</tr > ";
            });
            $('#tbDSCho tbody').html(html);
            fnSetEventGridCho();
            $('#tbDSCho').DataTable({
                "bPaginate": false,
                orderCellsTop: true,
                "scrollY": ($('#divTongDSChoBN .grid-y').height() - 130) + "px",
                scrollCollapse: true,
                paging: false,
                "order": [0, 'asc']
            });
        }
    });
}
//----------------------------------------------------------
function GetDSkQ_TiepNhan_KetQua(Loai) {
    var _data = {
        TuNgay: $('#txtTuNgayKQ').val(),
        DenNgay: $('#txtDenNgayKQ').val(),
        MacDinh: $('#macdinhKQ').is(':checked'),
        Khoa: $('#KhoaKQ').is(':checked'),
        Huy: $('#HuyKQ').is(':checked'),
        Sua: $('#SuaKQ').is(':checked'),
        LoaiMau: Loai.trim()
    };
    $.ajax({
        url: "/GiaiPhauBenh/dbDSKetQua_LayMau",
        data: JSON.stringify(_data),
        success: function (rs) {
            if ($.fn.DataTable.isDataTable('#tbDSKQ')) {
                $('#tbDSKQ').DataTable().destroy();
            }

            var html = "";
            $.each(rs, function (i, item) {
                var htmlTT = "";
                var htmlBH = "";
                var htmlinPhieu = "";
                if (item.Block != true) {
                    switch (item.TinhTrang) {
                        case 0:
                            htmlTT = "<span class='label alert'>" + item.TenTinhTrang + "</span>";
                            break;
                        case 7:
                            htmlTT = "";
                            break;
                        case 5:
                            htmlTT = "<span class='label primary'>" + item.TenTinhTrang + "</span>";
                            break;
                        case 2:
                            htmlTT = "";
                            break;
                        case 4:
                            htmlTT = "<span class='label primary'>" + item.TenTinhTrang + "</span>";
                            break;
                    };
                } else {
                    htmlTT = "<span class='label secondary'>Khóa</span>";
                }
                if (item.BH == '1') {
                    htmlBH = "<i class='fas fa-check-circle' style='color:rgba(59, 91, 152, 0.9)'></i>";
                } else {
                    htmlBH = "";
                }
                if (Loai == 'TNM') {
                    htmlinPhieu = "class='td_hidden'";
                } else {
                    htmlinPhieu = "";
                }
                html += "<tr tinhtrang='" + item.TinhTrang + "'>" +
                    "<td>" + htmlTT + "</td>" +
                    "<td>" + item.MaPhieu + "</td>" +
                    "<td>" + item.MaChiDinh + "</td>" +
                    "<td>" + item.Ngay + "</td>" +
                    "<td>" + item.MaBN + "</td>" +
                    "<td>" + item.HoTen + "</td>" +
                    "<td>" + item.GioiTinh + "</td>" +
                    "<td>" + item.TenDV + "</td>" +
                    "<td>" + item.LyDo + "</td>" +
                    "<td class='td_hidden'>" + item.MaVP + "</td>" +
                    "<td class='td_hidden'>" + item.MaVP_ChiTiet + "</td>" +
                    "<td style='text-align:center' >" + htmlBH + "</td>" +
                    "<td " + htmlinPhieu + " style='text-align: center' id='tdinphieu'><i  class='fas fa-print' style='color: #365899; font-size: 16pt' onclick='checkinphieu_GPB(\"" + item.MaPhieu + "\")'></i></td > " +
                    "<td style='text-align: center' id='huyphieu'><i class='fas fa-backspace' style='color: #ff6434; font-size: 16pt' onclick='xoaphieuKQGPB(\"" + item.MaPhieu + "\",\"" + item.MaVP + "\",\"" + item.MaVP_ChiTiet + "\",\"" + item.MaChiDinh + "\")'></i></td > " +
                    "</tr > ";
            });
            $('#tbDSKQ tbody').html(html);
            fnSetEventGridDSKQ_LayMau();
            $('#tbDSKQ').DataTable({
                "bPaginate": false,
                orderCellsTop: true,
                "scrollY": ($('#divTongDSChoBN .grid-y').height() - 130) + "px",
                scrollCollapse: true,
                paging: false,
                "order": [0, 'asc']
            });
        }
    });
}
//----------------------------------------------------------
function checkinphieu_GPB(MaPhieu) {
    if ($('#LoaiGPB').val() === 'TNM') {
        fnShowPopupMessage({ status: 'error', message: 'Tiếp nhận mẫu không thể in phiếu được' });
        return;
    };
    inphieu(MaPhieu);
}